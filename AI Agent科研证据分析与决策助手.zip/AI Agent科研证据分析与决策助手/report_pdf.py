# -*- coding: utf-8 -*-
"""纯标准库生成可嵌入中文字体的 PDF 报告。"""
import struct, zlib, json
from pathlib import Path

DEFAULT_FONT = Path(__file__).resolve().parent / "资源" / "NotoSansSC-Regular.ttf"


def _u16(data, off):
    return struct.unpack_from(">H", data, off)[0]


def _u32(data, off):
    return struct.unpack_from(">I", data, off)[0]


class TrueTypeInfo:
    def __init__(self, path):
        self.path = Path(path)
        self.data = self.path.read_bytes()
        data = self.data
        if data[:4] not in (b"\x00\x01\x00\x00", b"true", b"OTTO"):
            raise ValueError("不是可用的 TrueType 字体")
        num = _u16(data, 4)
        self.tables = {}
        for i in range(num):
            off = 12 + i * 16
            tag = data[off:off + 4].decode("latin1")
            self.tables[tag] = (_u32(data, off + 8), _u32(data, off + 12))
        head = self._table("head")
        self.units = _u16(head, 18)
        self.x_min, self.y_min, self.x_max, self.y_max = struct.unpack_from(">hhhh", head, 36)
        hhea = self._table("hhea")
        self.ascent = struct.unpack_from(">h", hhea, 4)[0]
        self.descent = struct.unpack_from(">h", hhea, 6)[0]
        self.num_hmetrics = _u16(hhea, 34)
        maxp = self._table("maxp")
        self.num_glyphs = _u16(maxp, 4)
        self.cmap = self._read_cmap()
        self.widths = self._read_widths()

    def _table(self, tag):
        off, length = self.tables[tag]
        return self.data[off:off + length]

    def _read_widths(self):
        hmtx = self._table("hmtx")
        widths = []
        for i in range(min(self.num_hmetrics, self.num_glyphs)):
            widths.append(_u16(hmtx, i * 4))
        last = widths[-1] if widths else self.units
        if len(widths) < self.num_glyphs:
            widths.extend([last] * (self.num_glyphs - len(widths)))
        return widths

    def _read_cmap(self):
        cmap = self._table("cmap")
        count = _u16(cmap, 2)
        candidates = []
        for i in range(count):
            off = 4 + i * 8
            platform = _u16(cmap, off)
            encoding = _u16(cmap, off + 2)
            suboff = _u32(cmap, off + 4)
            fmt = _u16(cmap, suboff)
            score = 0
            if (platform, encoding) == (3, 10):
                score = 100
            elif platform == 0:
                score = 90
            elif platform == 3 and encoding == 1:
                score = 80
            if fmt in (4, 12, 13):
                candidates.append((score, suboff, fmt))
        if not candidates:
            raise ValueError("字体缺少 Unicode 字符映射")
        _, suboff, fmt = max(candidates)
        result = {}
        if fmt in (12, 13):
            groups = _u32(cmap, suboff + 12)
            pos = suboff + 16
            for _ in range(groups):
                start, end, gid = struct.unpack_from(">III", cmap, pos)
                pos += 12
                if end - start > 200000:
                    continue
                for cp in range(start, end + 1):
                    result[cp] = gid + cp - start if fmt == 12 else gid
        else:
            seg_count = _u16(cmap, suboff + 6) // 2
            end_pos = suboff + 14
            start_pos = end_pos + seg_count * 2 + 2
            delta_pos = start_pos + seg_count * 2
            range_pos = delta_pos + seg_count * 2
            for i in range(seg_count):
                end = _u16(cmap, end_pos + i * 2)
                start = _u16(cmap, start_pos + i * 2)
                delta = struct.unpack_from(">h", cmap, delta_pos + i * 2)[0]
                ro = _u16(cmap, range_pos + i * 2)
                for cp in range(start, end + 1):
                    if cp == 0xFFFF:
                        continue
                    if ro == 0:
                        gid = (cp + delta) & 0xFFFF
                    else:
                        gpos = range_pos + i * 2 + ro + (cp - start) * 2
                        if gpos + 2 > len(cmap):
                            continue
                        gid = _u16(cmap, gpos)
                        if gid:
                            gid = (gid + delta) & 0xFFFF
                    if gid:
                        result[cp] = gid
        return result

    def glyph(self, ch):
        gid = self.cmap.get(ord(ch))
        if gid is None:
            gid = self.cmap.get(ord("?"), 0)
        return gid

    def width(self, ch):
        gid = self.glyph(ch)
        w = self.widths[gid] if 0 <= gid < len(self.widths) else self.units
        return w / float(self.units)


def _hex_text(info, text, used, used_unicode):
    out = bytearray()
    for ch in text:
        gid = info.glyph(ch)
        used.add(gid)
        used_unicode.setdefault(gid, ch)
        out.extend(struct.pack(">H", gid))
    return "<" + out.hex() + ">"


def _text_width(info, text, size):
    return sum(info.width(ch) * size for ch in text)


def _wrap(info, text, size, max_width):
    text = str(text).replace("\t", "    ")
    if not text:
        return [""]
    lines = []
    for raw in text.splitlines() or [""]:
        if not raw:
            lines.append("")
            continue
        current = ""
        for ch in raw:
            if _text_width(info, current + ch, size) <= max_width:
                current += ch
            else:
                cut = current.rfind(" ")
                if cut >= max(8, len(current) // 3):
                    lines.append(current[:cut])
                    current = current[cut + 1:] + ch
                else:
                    if current:
                        lines.append(current)
                    current = ch
        if current:
            lines.append(current)
    return lines or [""]


def _stream(data, extra=""):
    packed = zlib.compress(data)
    return ("<< /Length %d /Filter /FlateDecode %s>>\nstream\n" % (len(packed), extra)).encode() + packed + b"\nendstream"


def _cmap_stream(used_unicode):
    entries = sorted(used_unicode.items())
    chunks = [entries[i:i + 100] for i in range(0, len(entries), 100)] or [[]]
    parts = [
        "/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n",
        "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n",
        "/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n",
        "1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n",
    ]
    for chunk in chunks:
        parts.append("%d beginbfchar\n" % len(chunk))
        for gid, ch in chunk:
            uni = ch.encode("utf-16-be", "replace").hex().upper()
            parts.append("<%04X> <%s>\n" % (gid, uni))
        parts.append("endbfchar\n")
    parts.append("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n")
    return "".join(parts).encode("ascii")


def build_pdf(title, sections, font_path=None):
    """返回带嵌入中文字体的 PDF 字节。sections 为有序映射。"""
    font_path = Path(font_path or DEFAULT_FONT)
    info = TrueTypeInfo(font_path)
    used, used_unicode = set(), {}
    page_w, page_h = 595, 842
    margin = 46
    content_w = page_w - margin * 2
    pages, current = [], []
    y = 0

    def new_page():
        nonlocal current, y
        if current:
            pages.append(current)
        current = []
        y = page_h - 58

    def add_line(text, size=9.5, color=(0.12, 0.15, 0.17), before=0, after=2, indent=0):
        nonlocal y
        if before and current:
            y -= before
        line_h = size * 1.55
        for line in _wrap(info, text, size, content_w - indent):
            if y - line_h < 48:
                new_page()
            y -= line_h
            current.append((line, size, color, margin + indent, y))

    new_page()
    y -= 4
    for line in _wrap(info, title, 18, content_w):
        y -= 27
        current.append((line, 18, (0.055, 0.35, 0.33), margin, y))
    y -= 12
    current.append(("__RULE__", 1, (0.08, 0.48, 0.45), margin, y))
    y -= 10
    for key, value in sections.items():
        if y < 105:
            new_page()
        add_line(key, size=12.5, color=(0.055, 0.35, 0.33), before=7, after=4)
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2)
        for part in text.splitlines() or [""]:
            add_line(part, size=9.5, color=(0.12, 0.15, 0.17), after=1)
        y -= 3
    if current:
        pages.append(current)
    if not pages:
        pages = [[]]

    objects = [b""] * 7
    objects[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
    page_ids = [8 + idx * 2 for idx in range(len(pages))]
    objects[1] = ("<< /Type /Pages /Count %d /Kids [%s] >>" % (len(pages), " ".join("%d 0 R" % i for i in page_ids))).encode()
    objects[2] = b"<< /Type /Font /Subtype /Type0 /BaseFont /NotoSansSC-Regular /Encoding /Identity-H /DescendantFonts [4 0 R] /ToUnicode 7 0 R >>"
    bbox = [round(v * 1000 / info.units) for v in (info.x_min, info.y_min, info.x_max, info.y_max)]
    objects[4] = ("<< /Type /FontDescriptor /FontName /NotoSansSC-Regular /Flags 4 /FontBBox [%s] /ItalicAngle 0 /Ascent %d /Descent %d /CapHeight %d /StemV 80 /FontFile2 6 0 R >>" % (" ".join(map(str, bbox)), round(info.ascent * 1000 / info.units), round(info.descent * 1000 / info.units), round(info.ascent * 1000 / info.units))).encode()
    objects[5] = _stream(info.data, "/Length1 %d " % len(info.data))

    for idx, lines in enumerate(pages):
        pid = 8 + idx * 2
        cid = pid + 1
        content = ["q", "0.98 0.99 0.99 rg", "0 0 595 842 re f", "Q"]
        if idx > 0:
            content.append("BT /F1 8.5 Tf 0.35 0.42 0.44 rg 46 810 Td %s Tj ET" % _hex_text(info, "科研数据与证据管理报告", used, used_unicode))
            content.append("0.82 0.87 0.87 RG 0.6 w 46 801 m 549 801 l S")
        for text, size, color, x, yy in lines:
            if text == "__RULE__":
                content.append("0.08 0.48 0.45 RG 1.1 w 46 %.1f m 549 %.1f l S" % (yy, yy))
                continue
            if not text:
                continue
            content.append("BT /F1 %.2f Tf %.3f %.3f %.3f rg %.1f %.1f Td %s Tj ET" % (
                size, color[0], color[1], color[2], x, yy, _hex_text(info, text, used, used_unicode)))
        footer = "第 %d / %d 页" % (idx + 1, len(pages))
        content.append("BT /F1 8 Tf 0.45 0.50 0.52 rg 46 28 Td %s Tj ET" % _hex_text(info, footer, used, used_unicode))
        objects.append(("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % cid).encode())
        objects.append(_stream("\n".join(content).encode("ascii")))

    widths = []
    for gid in sorted(used):
        w = info.widths[gid] if gid < len(info.widths) else info.units
        widths.append("%d [%d]" % (gid, round(w * 1000 / info.units)))
    objects[3] = ("<< /Type /Font /Subtype /CIDFontType2 /BaseFont /NotoSansSC-Regular /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor 5 0 R /DW 1000 /W [%s] /CIDToGIDMap /Identity >>" % " ".join(widths)).encode()
    objects[6] = _stream(_cmap_stream(used_unicode))

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for i, obj in enumerate(objects, 1):
        offsets.append(len(out))
        out.extend(("%d 0 obj\n" % i).encode() + obj + b"\nendobj\n")
    start = len(out)
    out.extend(("xref\n0 %d\n0000000000 65535 f \n" % len(offsets)).encode())
    for off in offsets[1:]:
        out.extend(("%010d 00000 n \n" % off).encode())
    out.extend(("trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(offsets), start)).encode())
    return bytes(out)
