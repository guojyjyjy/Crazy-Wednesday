# -*- coding: utf-8 -*-
"""六模块增强服务：认证、真实质检、历史评价、报告及快照。仅依赖标准库。"""
import sys, json, time, threading, hashlib, secrets, hmac, urllib.parse, io, csv, zipfile, html, math, textwrap
from pathlib import Path
from report_pdf import build_pdf
from http.cookies import SimpleCookie
from concurrent.futures import ThreadPoolExecutor
POOL=ThreadPoolExecutor(max_workers=2)
LOCK=threading.RLock()
DIMENSIONS=['来源完整性','数据质量','证据一致性','可追溯性']

def pdf_bytes(title, sections):
    lines=[title,'']
    for k,v in sections.items():
        lines += [k]
        text=v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,indent=2)
        for line in text.splitlines():
            lines.extend(textwrap.wrap(line,45,replace_whitespace=False) or [''])
        lines.append('')
    pages=[lines[i:i+46] for i in range(0,len(lines),46)]
    objects=[b'', b'', b'<< /Type /Font /Subtype /Type0 /BaseFont /STSong-Light /Encoding /UniGB-UCS2-H /DescendantFonts [4 0 R] >>', b'<< /Type /Font /Subtype /CIDFontType0 /BaseFont /STSong-Light /CIDSystemInfo << /Registry (Adobe) /Ordering (GB1) /Supplement 4 >> /DW 1000 >>']
    kids=[]
    for n,page in enumerate(pages):
        pid=len(objects)+1; cid=pid+1; kids.append(f'{pid} 0 R')
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents {cid} 0 R >>'.encode())
        commands=['BT /F1 11 Tf 38 800 Td 16 TL']
        for line in page+[f'第 {n+1} / {len(pages)} 页']:
            commands.append('<'+line.encode('utf-16-be',errors='replace').hex()+'> Tj T*')
        commands.append('ET'); stream='\n'.join(commands).encode()
        objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream')
    objects[0]=b'<< /Type /Catalog /Pages 2 0 R >>'
    objects[1]=f'<< /Type /Pages /Count {len(kids)} /Kids [{" ".join(kids)}] >>'.encode()
    out=bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'); offsets=[0]
    for i,obj in enumerate(objects,1):
        offsets.append(len(out)); out.extend(f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n')
    start=len(out); out.extend(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for off in offsets[1:]:out.extend(f'{off:010} 00000 n \n'.encode())
    out.extend(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF'.encode())
    return bytes(out)

def install(base):
    s=sys.modules[base.__module__]
    def dumps(x):return json.dumps(x,ensure_ascii=False,sort_keys=True)
    def job_result_path(jid):return s.REPORT / ("任务结果_"+str(jid)+".json")
    def write_job_result(jid,result):
        try:
            path=job_result_path(jid)
            if isinstance(result,str):
                try:obj=json.loads(result)
                except Exception:obj={"原始结果":result}
            else:obj=result
            path.write_text(json.dumps({"任务编号":jid,"输出说明":"该文件由工具任务自动生成，包含本次固定的输入版本和派生结果；原始数据未被覆盖。","结果":obj},ensure_ascii=False,indent=2),encoding="utf-8")
            return path
        except Exception:return None
    def revalidate_existing():
        """将旧版本“任意空字段即异常”的记录按当前规则重新校验。"""
        with s.conn() as c:
            for ds in c.execute("SELECT * FROM datasets").fetchall():
                recs=c.execute("SELECT * FROM records WHERE dataset_id=? ORDER BY rowid",(ds["id"],)).fetchall()
                if not recs:continue
                seen=set();valid=invalid=0
                for r in recs:
                    try:meta=json.loads(r["metadata"] or "{}")
                    except Exception:meta={}
                    errors,warnings=s.record_validation(r["record_key"],r["content"],meta,seen);seen.add(r["record_key"])
                    parts=[]
                    if errors:parts.append("错误："+"；".join(errors))
                    if warnings:parts.append("提示："+"；".join(warnings))
                    is_valid=0 if errors else 1
                    valid+=is_valid;invalid+=0 if is_valid else 1
                    c.execute("UPDATE records SET valid=?,issue=? WHERE id=?",(is_valid,"；".join(parts),r["id"]))
                if valid or invalid:
                    c.execute("UPDATE datasets SET valid_count=?,invalid_count=?,notes=? WHERE id=?",(valid,invalid,f"已重新校验：有效 {valid}；异常 {invalid}；空字段仅提示，不影响有效性。",ds["id"]))
    def password(raw):
        salt=secrets.token_hex(16)
        return salt+':'+hashlib.pbkdf2_hmac('sha256',raw.encode(),salt.encode(),200000).hex()
    def verify(raw,stored):
        salt,digest=stored.split(':');return hmac.compare_digest(digest,hashlib.pbkdf2_hmac('sha256',raw.encode(),salt.encode(),200000).hex())
    with s.conn() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,username TEXT,expires REAL);
        CREATE TABLE IF NOT EXISTS reviews(id TEXT PRIMARY KEY,evaluation_id TEXT,username TEXT,status TEXT,notes TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS source_versions(id TEXT PRIMARY KEY,source_id TEXT,payload TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS job_inputs(job_id TEXT PRIMARY KEY,payload TEXT);
        CREATE TABLE IF NOT EXISTS project_members(project_id TEXT,username TEXT,PRIMARY KEY(project_id,username));''')
        for u in c.execute('SELECT * FROM users').fetchall():
            if ':' not in u['password']:c.execute('UPDATE users SET password=? WHERE id=?',(password(u['password']),u['id']))
        c.execute("UPDATE jobs SET status='FAILED',completed_at=?,logs=logs||? WHERE status IN ('RUNNING','QUEUED','PENDING')",(s.now(),'\n服务重新启动，未结束任务已标记失败；可重新运行。'))
        c.execute("UPDATE tools SET name='记录标准化',description='对通用数据字段进行显式映射，保存原始字段和映射结果。' WHERE id='工具-记录标准化'")
    revalidate_existing()
    def project_data(pid):
        project=s.one('SELECT * FROM projects WHERE id=?',(pid,))
        if not project:raise ValueError('项目不存在')
        datasets=s.rows('SELECT * FROM datasets WHERE project_id=?',(pid,))
        records=s.rows('SELECT r.* FROM records r JOIN datasets d ON d.id=r.dataset_id WHERE d.project_id=?',(pid,))
        links=s.rows('SELECT l.* FROM evidence_links l JOIN records r ON r.id=l.record_id JOIN datasets d ON d.id=r.dataset_id WHERE d.project_id=?',(pid,))
        evidence=s.rows('SELECT DISTINCT e.* FROM evidence e JOIN evidence_links l ON l.evidence_id=e.id JOIN records r ON r.id=l.record_id JOIN datasets d ON d.id=r.dataset_id WHERE d.project_id=?',(pid,))
        epitope_runs=s.rows('''SELECT er.*,d.name dataset_name,r.record_key,src.name source_name
                                    FROM epitope_runs er
                                    LEFT JOIN datasets d ON d.id=er.dataset_id
                                    LEFT JOIN records r ON r.id=er.record_id
                                    LEFT JOIN sources src ON src.id=er.source_id
                                    WHERE er.project_id=? ORDER BY er.created_at DESC''',(pid,))
        epitope_candidates=s.rows('''SELECT c.*,er.protein_name,er.accession,er.created_at run_created_at
                                     FROM epitope_candidates c JOIN epitope_runs er ON er.id=c.run_id
                                     WHERE er.project_id=? ORDER BY er.created_at DESC,c.rank''',(pid,))
        for c in epitope_candidates:
            try:c['support_tools']=json.loads(c.get('support_tools') or '[]')
            except Exception:c['support_tools']=[]
            try:c['factors']=json.loads(c.get('factors') or '{}')
            except Exception:c['factors']={}
        epitope_rankings=s.rows('''SELECT rr.*,er.protein_name FROM epitope_rankings rr JOIN epitope_runs er ON er.id=rr.run_id
                                   WHERE er.project_id=? ORDER BY rr.created_at DESC''',(pid,))
        epitope_evidence=s.rows('''SELECT ee.*,src.name source_name FROM epitope_evidence ee
                                   LEFT JOIN sources src ON src.id=ee.source_id ORDER BY ee.confidence DESC,ee.created_at DESC''')
        source_ids={d['source_id'] for d in datasets}|{e['source_id'] for e in evidence}|{r['source_id'] for r in epitope_runs if r.get('source_id')}
        return {'项目基本信息':project,'数据集信息':datasets,'原始记录':records,'数据来源':[x for x in s.rows('SELECT * FROM sources') if x['id'] in source_ids], '关联证据':evidence,'证据关联':links,
        '证据版本':[x for x in s.rows('SELECT * FROM evidence_versions') if x['evidence_id'] in {e['id'] for e in evidence}],
        '数据版本':s.rows('SELECT v.* FROM dataset_versions v JOIN datasets d ON d.id=v.dataset_id WHERE d.project_id=?',(pid,)),
        '任务运行记录':s.rows('SELECT * FROM jobs WHERE project_id=?',(pid,)),
        '结果统计':s.rows('SELECT e.* FROM evaluations e JOIN jobs j ON j.id=e.job_id WHERE j.project_id=?',(pid,)),
        '评价规则说明':s.rows('SELECT * FROM rules'), '数据质量与异常记录':[r for r in records if not r['valid'] or r.get('issue')],
        '人工复核':s.rows('SELECT v.* FROM reviews v JOIN evaluations e ON e.id=v.evaluation_id JOIN jobs j ON j.id=e.job_id WHERE j.project_id=?',(pid,)),
        '报告历史':s.rows('SELECT * FROM reports WHERE project_id=?',(pid,)),
        '抗原运行记录':epitope_runs,'抗原候选结果':epitope_candidates,'抗原排序版本':epitope_rankings,'抗原证据线索':epitope_evidence,
        '局限性声明':'本报告包含抗原候选计算与证据整合结果，但计算分数不产生新的湿实验数据，不构成诊断、疫苗设计或保护性结论；最终候选须经实验验证。', '生成时间及版本信息':{'时间':s.now(),'版本':s.APP_VERSION}}
    def submit(d,parent=None):
        pid=d.get('project_id'); payload=project_data(pid)
        tool=s.one('SELECT * FROM tools WHERE id=?',(d.get('tool_id','工具-基础质检'),))
        if not tool or not tool['enabled']:raise ValueError('工具不存在或已停用')
        params=d.get('params',{})
        if not isinstance(params,dict):raise ValueError('参数必须为 JSON 对象')
        timeout=float(d.get('timeout_seconds',60))
        if not math.isfinite(timeout) or not 0.001<=timeout<=3600:raise ValueError('超时必须在 0.001 到 3600 秒之间')
        snapshot={'数据集':payload['数据集信息'],'记录':payload['原始记录'],'工具':tool,'参数':params}
        if parent:snapshot=json.loads(s.one('SELECT payload FROM job_inputs WHERE job_id=?',(parent,))['payload'])
        key=hashlib.sha256(dumps(snapshot).encode()).hexdigest()
        with LOCK,s.conn() as c:
            old=c.execute("SELECT id FROM jobs WHERE cache_key=? AND status IN ('RUNNING','QUEUED')",(key,)).fetchone()
            if old:return {'id':old['id'],'重复任务':True}
            jid=s.ident('任务'); cache=c.execute('SELECT result FROM job_cache WHERE cache_key=?',(key,)).fetchone() if not parent else None
            c.execute('INSERT INTO jobs(id,project_id,name,tool_id,status,progress,params,logs,result,created_at,completed_at,cancel_requested,timeout_seconds,cache_key,attempt,parent_job_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(jid,pid,d.get('name') or tool['name'],tool['id'],'SUCCESS' if cache else 'QUEUED',100 if cache else 0,dumps(params),'命中同版本输入缓存。' if cache else '任务已进入队列。',cache['result'] if cache else '',s.now(),s.now() if cache else None,0,timeout,key,(s.one('SELECT attempt FROM jobs WHERE id=?',(parent,))['attempt']+1) if parent else 1,parent or ''))
            c.execute('INSERT INTO job_inputs VALUES(?,?)',(jid,dumps(snapshot)))
        if cache:write_job_result(jid,cache['result'])
        else:POOL.submit(worker,jid)
        return {'id':jid,'缓存命中':bool(cache)}
    def worker(jid):
        output=[];start=time.monotonic()
        try:
            j=s.one('SELECT * FROM jobs WHERE id=?',(jid,)); snap=json.loads(s.one('SELECT payload FROM job_inputs WHERE job_id=?',(jid,))['payload'])
            with s.conn() as c:c.execute("UPDATE jobs SET status='RUNNING',logs=logs||? WHERE id=? AND status='QUEUED'",('\n正在处理固定输入版本。',jid))
            seen=set()
            for i,r in enumerate(snap['记录']):
                current=s.one('SELECT * FROM jobs WHERE id=?',(jid,))
                if not current or current['cancel_requested']:return
                if time.monotonic()-start>j['timeout_seconds']:raise TimeoutError('任务超时，已保留部分结果')
                meta=json.loads(r['metadata']); key=(r['dataset_id'],r['record_key']); duplicate=key in seen;seen.add(key)
                if j['tool_id']=='工具-基础质检':
                    output.append({'记录编号':r['id'],'记录标识':r['record_key'],'字段数':len(meta),'缺失字段':[k for k,v in meta.items() if v is None or v==''],'重复标识':duplicate,'有效':bool(r['valid']) and not duplicate,'问题':r['issue']})
                else:
                    mapping=snap['参数'].get('字段映射',{})
                    if not isinstance(mapping,dict):raise ValueError('字段映射必须为对象')
                    normal={mapping.get(k,k):v for k,v in meta.items()}
                    if len(normal)!=len(meta):raise ValueError('映射后的字段名重复')
                    output.append({'记录编号':r['id'],'原始字段':meta,'标准字段':normal,'字段映射':mapping})
                    with s.conn() as c:c.execute('INSERT OR REPLACE INTO normalized_records VALUES(?,?,?,?,?,?)',(s.ident('标准记录'),r['id'],'通用字段',dumps(normal),dumps(mapping),s.now()))
                if i%50==0:
                    with s.conn() as c:c.execute("UPDATE jobs SET progress=?,result=? WHERE id=? AND cancel_requested=0",(int((i+1)*100/max(1,len(snap['记录']))),dumps(output),jid))
            result=dumps({'输入版本':[{'编号':d['id'],'版本':d['version'],'摘要':d['sha256']} for d in snap['数据集']],'工具':snap['工具'],'记录数':len(output),'结果':output})
            with s.conn() as c:
                updated=c.execute("UPDATE jobs SET status='SUCCESS',progress=100,result=?,completed_at=?,logs=logs||? WHERE id=? AND cancel_requested=0",(result,s.now(),'\n真实数据处理完成，输入与结果已归档。',jid)).rowcount
                if updated:
                    c.execute('INSERT OR REPLACE INTO job_cache VALUES(?,?,?)',(j['cache_key'],result,s.now()))
                    write_job_result(jid,result)
        except Exception as e:
            partial=dumps(output)
            with s.conn() as c:c.execute("UPDATE jobs SET status=?,result=?,completed_at=?,logs=logs||? WHERE id=? AND cancel_requested=0",('PARTIAL' if output else 'FAILED',partial,s.now(),'\n'+str(e),jid))
            write_job_result(jid,partial)
    class Handler(base):
        def path_parts(self):
            u=urllib.parse.urlparse(self.path);return urllib.parse.unquote(u.path),urllib.parse.parse_qs(u.query)
        def auth(self):
            path,_=self.path_parts()
            if not path.startswith(('/api/','/download/','/asset/')) or path in ('/api/login','/api/health'):return True
            cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''));token=cookie.get('epi_session')
            session=s.one('SELECT * FROM sessions WHERE token=? AND expires>?',(token.value if token else '',time.time()))
            if not session:self.send_json({'错误':'请先登录'},401);return False
            self.user=session['username'];return True
        def body(self):
            n=int(self.headers.get('Content-Length',0))
            if n<0 or n>26*1024*1024:raise ValueError('请求超过 26 MB 限制')
            return self.rfile.read(n)
        def do_GET(self):
            if not self.auth():return
            path,q=self.path_parts()
            try:
                if path=='/api/results':return self.send_json(s.rows('SELECT e.*,r.record_key,ru.name rule_name,ru.version rule_version,j.project_id FROM evaluations e LEFT JOIN records r ON r.id=e.record_id JOIN rules ru ON ru.id=e.rule_id LEFT JOIN jobs j ON j.id=e.job_id ORDER BY e.created_at DESC'))
                if path=='/api/reviews':return self.send_json(s.rows('SELECT * FROM reviews ORDER BY created_at DESC'))
                if path=='/api/network':return self.send_json({'记录':s.rows('SELECT id,record_key,dataset_id FROM records'),'证据':s.rows('SELECT * FROM evidence'),'关联':s.rows('SELECT * FROM evidence_links')})
                if path=='/api/normalized':return self.send_json(s.rows('SELECT * FROM normalized_records'))
                if path=='/api/me':return self.send_json({'用户名':self.user})
                if path=='/api/snapshots/summary':
                    out=[]
                    for snap in s.rows('SELECT s.*,p.name project_name FROM snapshots s LEFT JOIN projects p ON p.id=s.project_id ORDER BY s.created_at DESC'):
                        try:payload=json.loads(snap.get('payload') or '{}')
                        except Exception:payload={}
                        out.append({'id':snap['id'],'project_id':snap['project_id'],'project_name':snap.get('project_name') or '', 'name':snap['name'],'created_at':snap['created_at'],'summary':{'数据集数':len(payload.get('数据集信息',[])),'记录数':len(payload.get('原始记录',[])),'关联证据数':len(payload.get('关联证据',[])),'证据关联数':len(payload.get('证据关联',[])),'任务数':len(payload.get('任务运行记录',[])),'评价数':len(payload.get('结果统计',[])),'抗原运行数':len(payload.get('抗原运行记录',[])),'抗原候选数':len(payload.get('抗原候选结果',[])),'报告数':len(payload.get('报告历史',[]))}})
                    return self.send_json(out)
                if path.startswith('/api/snapshot/'):
                    sid=path.rsplit('/',1)[1];snap=s.one('SELECT * FROM snapshots WHERE id=?',(sid,))
                    if not snap:return self.send_json({'错误':'快照不存在'},404)
                    try:snap['payload']=json.loads(snap.get('payload') or '{}')
                    except Exception:pass
                    return self.send_json(snap)
                if path.startswith('/api/jobs/') and path.endswith('/result'):
                    parts=path.split('/');jid=parts[3] if len(parts)>3 else ''
                    job=s.one('SELECT * FROM jobs WHERE id=?',(jid,))
                    if not job:return self.send_json({'错误':'任务不存在'},404)
                    if not str(job.get('result') or '').strip():return self.send_json({'错误':'任务尚未生成结果'},409)
                    rp=job_result_path(jid)
                    if not rp.exists():write_job_result(jid,job['result'])
                    data=rp.read_bytes()
                    self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+urllib.parse.quote(rp.name));self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
                if path.startswith('/api/jobs/'):
                    jid=path.rsplit('/',1)[1];job=s.one('SELECT * FROM jobs WHERE id=?',(jid,))
                    if not job:return self.send_json({'错误':'任务不存在'},404)
                    rp=job_result_path(jid)
                    job['结果文件']=str(rp.relative_to(s.BASE)) if rp.is_relative_to(s.BASE) else str(rp)
                    job['结果下载']='/api/jobs/'+urllib.parse.quote(jid,safe='')+'/result'
                    return self.send_json(job)
                if path.startswith('/api/job-input/'):return self.send_json(s.one('SELECT * FROM job_inputs WHERE job_id=?',(path.rsplit('/',1)[1],)))
                return super().do_GET()
            except Exception as e:self.send_json({'错误':str(e)},400)
        def do_PUT(self):
            if self.auth():return super().do_PUT()
        def do_DELETE(self):
            if not self.auth():return
            path,_=self.path_parts()
            try:
                if path.startswith(('/api/projects/','/api/datasets/')):
                    pid=path.rsplit('/',1)[1]
                    if path.startswith('/api/datasets/'):
                        ds=s.one('SELECT * FROM datasets WHERE id=?',(pid,));pid=ds['project_id'] if ds else ''
                    if s.one("SELECT id FROM jobs WHERE project_id=? AND status IN ('RUNNING','QUEUED')",(pid,)):raise ValueError('请先取消或等待该项目中的任务结束')
                result=super().do_DELETE()
                with s.conn() as c:
                    c.execute('DELETE FROM normalized_records WHERE record_id NOT IN (SELECT id FROM records)')
                return result
            except Exception as e:self.send_json({'错误':str(e)},400)
        def do_POST(self):
            if not self.auth():return
            path,_=self.path_parts()
            if path=='/api/upload':return super().do_POST()
            try:
                raw=self.body(); d=json.loads(raw or b'{}')
                if not isinstance(d,dict):raise ValueError('请求必须是 JSON 对象')
                if path=='/api/login':
                    u=s.one('SELECT * FROM users WHERE username=?',(d.get('username'),))
                    if not u or not verify(d.get('password',''),u['password']):return self.send_json({'错误':'用户名或密码错误'},401)
                    token=secrets.token_urlsafe(32)
                    with s.conn() as c:c.execute('INSERT INTO sessions VALUES(?,?,?)',(token,u['username'],time.time()+8*3600))
                    data=dumps({'成功':True,'用户':{'username':u['username'],'role':u['role']}}).encode()
                    self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Set-Cookie',f'epi_session={token}; HttpOnly; SameSite=Strict; Path=/');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
                if path=='/api/logout':
                    cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''))
                    with s.conn() as c:c.execute('DELETE FROM sessions WHERE token=?',(cookie['epi_session'].value,))
                    return self.send_json({'成功':True})
                if path=='/api/password':
                    u=s.one('SELECT * FROM users WHERE username=?',(self.user,))
                    if not verify(d.get('old',''),u['password']):raise ValueError('原密码不正确')
                    if len(d.get('new',''))<8:raise ValueError('新密码至少八位')
                    with s.conn() as c:c.execute('UPDATE users SET password=? WHERE username=?',(password(d['new']),self.user))
                    return self.send_json({'成功':True})
                if path=='/api/jobs':result=submit(d)
                elif path=='/api/jobs/retry':
                    j=s.one('SELECT * FROM jobs WHERE id=?',(d.get('id'),))
                    if not j:raise ValueError('任务不存在')
                    result=submit({'project_id':j['project_id'],'tool_id':j['tool_id'],'name':j['name']+'（重运行）','params':json.loads(j['params']),'timeout_seconds':j['timeout_seconds']},j['id'])
                elif path=='/api/tools':
                    if not d.get('name','').strip() or not d.get('version','').strip():raise ValueError('工具名称和版本不能为空')
                    tid=d.get('id') or s.ident('工具')
                    with s.conn() as c:c.execute('INSERT OR REPLACE INTO tools VALUES(?,?,?,?,?)',(tid,d['name'],d['version'],d.get('description','通用字段标准化适配器'),int(bool(d.get('enabled',True)))))
                    result={'id':tid}
                elif path=='/api/evaluate':result=self.evaluate(d)
                elif path=='/api/review':
                    if not s.one('SELECT id FROM evaluations WHERE id=?',(d.get('evaluation_id'),)):raise ValueError('评价记录不存在')
                    rid=s.ident('复核')
                    with s.conn() as c:c.execute('INSERT INTO reviews VALUES(?,?,?,?,?,?)',(rid,d['evaluation_id'],self.user,d.get('status','待复核'),d.get('notes',''),s.now()))
                    result={'id':rid}
                elif path=='/api/snapshot':
                    payload=project_data(d.get('project_id'));sid=s.ident('快照')
                    with s.conn() as c:c.execute('INSERT INTO snapshots VALUES(?,?,?,?,?)',(sid,d['project_id'],d.get('name','项目快照'),dumps(payload),s.now()))
                    result={'id':sid}
                elif path=='/api/reports':result=self.report(d)
                elif path=='/api/sources/update':
                    old=s.one('SELECT * FROM sources WHERE id=?',(d.get('id'),))
                    if not old:raise ValueError('来源不存在')
                    with s.conn() as c:
                        c.execute('INSERT INTO source_versions VALUES(?,?,?,?)',(s.ident('来源版本'),old['id'],dumps(old),s.now()))
                        c.execute('UPDATE sources SET name=?,source_type=?,source_url=?,description=? WHERE id=?',tuple(d.get(k,old[k]) for k in ['name','source_type','source_url','description'])+(old['id'],))
                    result={'成功':True}
                else:
                    if path in ('/api/projects','/api/sources','/api/report-templates','/api/rules') and not str(d.get('name','')).strip():raise ValueError('名称不能为空')
                    if path=='/api/rules':
                        cfg=d.get('configuration',{}); weights=[float(cfg.get(k,0)) for k in DIMENSIONS]
                        if any(not math.isfinite(x) or x<0 or x>100 for x in weights) or not sum(weights):raise ValueError('权重必须在 0 到 100 之间且不能全部为零')
                    if path=='/api/evidence/link':
                        if not s.one('SELECT id FROM evidence WHERE id=?',(d.get('evidence_id'),)) or not s.one('SELECT id FROM records WHERE id=?',(d.get('record_id'),)):raise ValueError('证据或数据记录不存在')
                    self.rfile=io.BytesIO(raw)
                    return super().do_POST()
                s.audit(self.user,'保存业务操作',path,dumps(d));return self.send_json(result)
            except Exception as e:return self.send_json({'错误':str(e)},400)
        def evaluate(self,d):
            projects=s.rows('SELECT id FROM projects ORDER BY created_at')
            if not projects:raise ValueError('请先创建科研项目并导入数据')
            pid=d.get('project_id') or projects[0]['id']
            if not s.one('SELECT id FROM projects WHERE id=?',(pid,)):raise ValueError('项目不存在')
            rule=s.one('SELECT * FROM rules WHERE id=?',(d['rule_id'],)) if d.get('rule_id') else s.one('SELECT * FROM rules WHERE active=1 ORDER BY created_at DESC LIMIT 1')
            if not rule:raise ValueError('评价规则不存在，请先创建规则版本')
            snap=project_data(pid)
            if not snap['原始记录']:raise ValueError('该项目暂无数据记录，请先导入数据')
            cfg=json.loads(rule['configuration']);jid=s.ident('评价任务');out=[]
            links_by_record={}
            for link in snap['证据关联']:links_by_record.setdefault(link['record_id'],[]).append(link)
            evidence_by_id={e['id']:e for e in snap['关联证据']}
            with s.conn() as c:
                c.execute('INSERT INTO jobs(id,project_id,name,tool_id,status,progress,params,logs,result,created_at,completed_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(jid,pid,'证据完整性评价','规则评价','SUCCESS',100,dumps({'rule_id':rule['id'],'project_id':pid}),'保存规则、输入和证据快照；生成逐条评价。','',s.now(),s.now()))
                c.execute('INSERT INTO job_inputs VALUES(?,?)',(jid,dumps(snap)))
                for r in snap['原始记录']:
                    ls=links_by_record.get(r['id'],[])
                    evidence_ids={l['evidence_id'] for l in ls}
                    es=[evidence_by_id[x] for x in evidence_ids if x in evidence_by_id]
                    complete=sum(bool(e.get('source_id')) and bool(e.get('url') or e.get('identifier')) for e in es)
                    conflicts=[e['id'] for e in es if e.get('status')=='有争议' or e.get('conflict_group')]
                    parts={'来源完整性':round(100*complete/len(es),2) if es else 0,'数据质量':100 if r['valid'] else 0,'证据一致性':0 if conflicts or not es else 100,'可追溯性':100 if es else 0}
                    weight_sum=sum(float(cfg.get(k,0)) for k in DIMENSIONS)
                    score=sum(parts[k]*float(cfg.get(k,0)) for k in DIMENSIONS)/weight_sum
                    eid=s.ident('评价')
                    missing=[] if es else ['缺少关联证据']
                    full={'维度':parts,'权重':cfg,'原始记录':r,'证据':es,'冲突证据':conflicts,'缺失说明':missing,'规则版本':rule['version']}
                    explain={'维度':parts,'权重':cfg,'记录编号':r['id'],'记录标识':r['record_key'],'关联证据数':len(es),'冲突证据数':len(conflicts),'缺失说明':missing,'规则版本':rule['version']}
                    c.execute('INSERT INTO evaluations VALUES(?,?,?,?,?,?,?)',(eid,jid,r['id'],rule['id'],score,dumps(full),s.now()))
                    out.append({'评价编号':eid,'记录':r['record_key'],'记录编号':r['id'],'得分':round(score,2),'维度':parts,'规则':rule['name'],'规则编号':rule['id'],'解释':explain})
                c.execute('UPDATE jobs SET result=? WHERE id=?',(dumps(out),jid))
            write_job_result(jid,out)
            return out
        def report(self,d):
            payload=project_data(d.get('project_id'));fmt=d.get('format','pdf'); template=s.one('SELECT * FROM report_templates WHERE id=?',(d.get('template_id'),))
            sections=json.loads(template['sections']) if template else ['项目基本信息','数据集信息','数据来源','抗原运行记录','抗原候选结果','抗原排序版本','抗原证据线索','关联证据','数据质量与异常记录','人工复核','报告历史']
            if not isinstance(sections,list) or not sections:raise ValueError('模板至少需要一个章节')
            unknown=[x for x in sections if x not in payload]
            if unknown:raise ValueError('未知章节：'+','.join(unknown))
            report={k:payload[k] for k in sections};report['生成时间及版本信息']=payload['生成时间及版本信息'];report['局限性声明']=payload['局限性声明']
            rid=s.ident('报告');name='布病抗原决策报告_'+rid;path=s.REPORT/(name+'.'+fmt)
            readable={}
            for key,value in report.items():
                if key=='项目基本信息':text='项目名称：'+value['name']+'\n项目编号：'+value['id']+'\n项目说明：'+value['description']+'\n负责人：'+value['owner']
                elif key=='数据集信息':text='\n'.join(f"{x['name']}：{x['type']}，版本 {x['version']}，{x['record_count']} 条记录，有效 {x['valid_count']}，异常 {x['invalid_count']}。" for x in value) or '暂无数据集。'
                elif key=='数据来源':text='\n'.join(str(x['name'])+'：'+str(x.get('source_url') or '未填写链接') for x in value) or '尚未登记项目数据来源。'
                elif key=='抗原运行记录':
                    text='\n'.join(
                        f"{x.get('protein_name') or '未命名蛋白'} / {x.get('accession') or '无 Accession'}："
                        f"{ {'SUCCESS':'成功','PARTIAL':'部分成功','FAILED':'失败','RUNNING':'运行中'}.get(x.get('status'),x.get('status')) }；"
                        f"候选 {x.get('candidate_count') or 0} 条；运行编号 {x.get('id')}；"
                        f"项目 {x.get('project_id')}；数据集 {x.get('dataset_name') or '未关联'}；"
                        f"记录 {x.get('record_key') or '未关联'}；来源 {x.get('source_name') or '未关联'}"
                        for x in value[:20]
                    ) or '暂无抗原决策运行。'
                elif key=='抗原候选结果':
                    text='\n\n'.join(
                        f"{i}. {x.get('protein_name') or ''} {x.get('start_pos')}-{x.get('end_pos')}：{x.get('sequence')}\n"
                        f"   共识分 {float(x.get('score') or 0):.2f}；覆盖 {x.get('support_count')}/{x.get('total_tools')}；"
                        f"强度 {float(x.get('strength') or 0):.3f}；证据线索 {float(x.get('evidence') or 0):.3f}；"
                        f"一致性 {float(x.get('consistency') or 0):.3f}；支持工具 {'、'.join(x.get('support_tools') or []) or '无'}"
                        for i,x in enumerate(value[:30],1)
                    ) or '暂无抗原候选结果。'
                elif key=='抗原排序版本':
                    text=f"共保存 {len(value)} 个排序版本。最近版本：" + ('；'.join(f"{x.get('protein_name') or ''} {x.get('created_at')}" for x in value[:10]) or '无')
                    text+='\n每个版本保存权重、候选排序和生成时间，可从 JSON 报告查看完整内容。'
                elif key=='抗原证据线索':
                    text='\n'.join(f"{x.get('title')}：{x.get('relation')}；{x.get('source_name') or x.get('source') or '未关联来源'}；PMID {x.get('pmid') or '无'}" for x in value[:30]) or '暂无抗原证据线索。'
                elif key=='任务运行记录':text='\n'.join(x['name']+'：'+{'SUCCESS':'成功','PARTIAL':'部分成功','FAILED':'失败','CANCELLED':'已取消','QUEUED':'排队','RUNNING':'运行中'}.get(x['status'],x['status'])+'；任务编号 '+x['id'] for x in value) or '暂无任务。'
                elif key=='结果统计':
                    av=sum(float(x['score']) for x in value)/len(value) if value else 0
                    text=f"已归档评价 {len(value)} 条。平均分 {av:.2f}。" + ('\n最低分：'+str(round(min(float(x['score']) for x in value),2))+'；最高分：'+str(round(max(float(x['score']) for x in value),2)) if value else '')
                    text+='\n完整逐条结果可从分析中心或 JSON 报告查看。'
                elif key=='评价规则说明':text='\n'.join(x['name']+'，版本 '+x['version']+'，权重 '+x['configuration']+'。'+x['description'] for x in value)
                elif key=='数据质量与异常记录':
                    invalid=[x for x in value if not x.get('valid')]
                    warned=[x for x in value if x.get('valid') and x.get('issue')]
                    text=f"异常记录 {len(invalid)} 条；含空字段提示 {len(warned)} 条。空字段提示不代表整条记录无效。"
                    preview=invalid[:20] if invalid else warned[:5]
                    if preview:text+='\n'+'\n'.join(str(x['record_key'])+'：'+str(x.get('issue') or '') for x in preview)
                    if len(invalid)+len(warned)>len(preview):text+=f"\n仅列前 {len(preview)} 条，完整内容请查看数据中心或 JSON 报告。"
                elif key=='关联证据':text='\n'.join(str(x['title'])+'：'+str(x['status'])+'；'+str(x.get('url') or '未填写链接')+'；'+str(x.get('notes') or '') for x in value) or '暂无关联证据。'
                elif key=='原始记录':text=f"当前共 {len(value)} 条记录。完整原始内容请使用数据集导出或项目 JSON 报告。"
                elif key in ['证据版本','数据版本','报告历史','证据关联']:text=f"已归档 {len(value)} 条。完整版本内容可从系统历史记录或 JSON 报告查看。"
                elif key=='人工复核':text='\n'.join(x['username']+'：'+x['status']+'；'+x['notes'] for x in value) or '尚无人工复核记录。'
                elif isinstance(value,str):text=value
                else:text=json.dumps(value,ensure_ascii=False)
                readable[key]=text
            if fmt=='pdf':path.write_bytes(build_pdf('布病多表位抗原候选决策报告',readable))
            elif fmt=='json':path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            elif fmt=='html':path.write_text('<!doctype html><meta charset="utf-8"><title>布病多表位抗原候选决策报告</title><style>body{max-width:1000px;margin:40px auto;font:16px sans-serif}pre{white-space:pre-wrap;overflow-wrap:anywhere}h2{color:#166569}</style><h1>布病多表位抗原候选决策报告</h1>'+''.join('<h2>'+html.escape(k)+'</h2><pre>'+html.escape(json.dumps(v,ensure_ascii=False,indent=2))+'</pre>' for k,v in readable.items()),encoding='utf-8')
            elif fmt=='csv':
                with path.open('w',encoding='utf-8-sig',newline='') as f:
                    w=csv.writer(f);w.writerow(['章节','内容']);w.writerows((k,json.dumps(v,ensure_ascii=False)) for k,v in report.items())
            else:raise ValueError('报告格式仅支持 PDF、HTML、JSON、CSV；XLSX 和 FASTA 请从数据集导出')
            with s.conn() as c:c.execute('INSERT INTO reports VALUES(?,?,?,?,?,?)',(rid,d['project_id'],name,fmt,str(path.relative_to(s.BASE)) if path.is_relative_to(s.BASE) else str(path),s.now()))
            return {'id':rid,'download':'/download/'+urllib.parse.quote(path.name)}
    return Handler






