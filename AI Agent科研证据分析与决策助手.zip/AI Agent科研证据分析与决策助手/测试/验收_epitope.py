# -*- coding: utf-8 -*-
"""Brucella-EpiWork 3.1 抗原决策台与跨模块整合隔离验收。"""
import os, sys, json, time, socket, tempfile, subprocess, urllib.request, urllib.error, urllib.parse, http.cookiejar, unittest, uuid
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
BP26 = 'MNTRASNFLAASFSTIMLVGAFSLPAFAQENQMTTQPARIAVTGEGMMTASPDMAILNLSVLRQAKTAREAMTANNEAMTKVLDAMKKAGIEDRDLQTGGINIQPIYVYPDDKNNLKEPTITGYSVSTSLTVRVRELANVGKILDESVTLGVNQGGDLNLVNDNPSAVINEARKRAVANAIAKAKTLADAAGVGLGRVVEISELSRPPMPMPIARGQFRTMLAAAPDNSVPIAAGENSYNVSVNVVFEIK'

class EpiAcceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(dir=ROOT, ignore_cleanup_errors=True)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0)); cls.port = sock.getsockname()[1]
        cls.env = {**os.environ, 'EPIWORK_DATA': cls.tmp.name, 'EPIWORK_PORT': str(cls.port)}
        cls.log = open(Path(cls.tmp.name) / '服务.log', 'w', encoding='utf-8')
        cls.proc = subprocess.Popen([sys.executable, str(ROOT / 'server.py')], cwd=ROOT, env=cls.env, stdout=cls.log, stderr=cls.log)
        cls.client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        for _ in range(120):
            try:
                if cls.call('/api/health')['版本'] == '3.3.0': break
            except Exception:
                time.sleep(0.05)
        else:
            raise RuntimeError('服务启动失败')
        cls.call('/api/login', {'username': '管理员', 'password': 'epiwork123'})

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(timeout=5); cls.log.close(); time.sleep(0.2); cls.tmp.cleanup()

    @classmethod
    def call(cls, path, data=None, binary=False):
        raw = json.dumps(data, ensure_ascii=False).encode() if data is not None else None
        path = urllib.parse.quote(path, safe='/?=&%')
        req = urllib.request.Request(f'http://127.0.0.1:{cls.port}' + path, data=raw,
                                     headers={'Content-Type': 'application/json'} if raw else {})
        with cls.client.open(req, timeout=20) as r:
            body = r.read()
        return body if binary else json.loads(body)

    @classmethod
    def upload(cls, project_id, source_id, name, content):
        boundary = 'b' + uuid.uuid4().hex
        fields = {'project_id': project_id, 'source_id': source_id, 'name': name, 'dataset_id': ''}
        body = b''.join(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k, v in fields.items())
        body += f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}.fasta"\r\nContent-Type: text/plain\r\n\r\n'.encode()
        body += content.encode() + f'\r\n--{boundary}--\r\n'.encode()
        req = urllib.request.Request(f'http://127.0.0.1:{cls.port}/api/upload', data=body,
                                     headers={'Content-Type': 'multipart/form-data; boundary=' + boundary})
        with cls.client.open(req, timeout=20) as r:
            return json.loads(r.read())

    def test_01_meta_and_analysis_fault_tolerance(self):
        meta = self.call('/api/epitope/meta')
        self.assertEqual(meta['version'], '3.3.0')
        self.assertEqual(len(meta['tools']), 7)
        self.assertGreaterEqual(meta['evidence_count'], 4)
        pid = self.call('/api/projects', {'name': '验收项目', 'description': 'EpiWork 3.2', 'owner': '管理员'})['id']
        type(self).pid = pid
        source_id = self.call('/api/sources', {'name': '验收来源', 'source_type': '蛋白质数据库',
                                               'source_url': 'https://www.uniprot.org/uniprotkb/Q6YA76',
                                               'description': '抗原决策台来源验收'})['id']
        dataset = self.upload(pid, source_id, '验收 BP26 序列', '>BP26 Q6YA76\n' + BP26 + '\n')
        record = self.call('/api/datasets/' + dataset['id'] + '/records')[0]
        run = self.call('/api/epitope/analyze', {
            'project_id': pid, 'protein_name': record['record_key'], 'accession': 'Q6YA76',
            'organism': 'Brucella abortus', 'sequence': BP26,
            'tools': ['hydrophilicity', 'flexibility', 'accessibility', 'turn'],
            'weights': {'coverage': 35, 'strength': 30, 'evidence': 20, 'consistency': 15},
            'simulate_failure': 'turn', 'dataset_id': dataset['id'],
            'record_id': record['id'], 'source_id': source_id
        })
        type(self).run_data = run
        self.assertEqual(run['status'], 'PARTIAL')
        self.assertGreater(run['candidate_count'], 0)
        self.assertEqual(next(x for x in run['tool_logs'] if x['id'] == 'turn')['status'], 'FAILED')
        self.assertTrue(all(c['length'] <= 24 for c in run['candidates']))
        self.assertTrue(run['candidates'][0]['evidence_items'])
        self.assertIn('rank', run['candidates'][0])

    def test_02_rerank_selection_export(self):
        run = self.__class__.run_data
        rerank = self.call(f"/api/epitope/runs/{run['id']}/rerank", {'weights': {'coverage': 20, 'strength': 20, 'evidence': 45, 'consistency': 15}})
        self.assertAlmostEqual(rerank['weights']['evidence'], 45)
        ids = [x['id'] for x in rerank['candidates'][:3]]
        saved = self.call('/api/epitope/select', {'run_id': run['id'], 'candidate_ids': ids})
        self.assertEqual(saved['selected_count'], 3)
        detail = self.call(f"/api/epitope/runs/{run['id']}")
        self.assertEqual(sum(1 for c in detail['candidates'] if c['selected']), 3)
        for fmt, magic in [('csv', b'\xef\xbb\xbf'), ('fasta', b'>EpiWork'), ('json', b'{'), ('pdf', b'%PDF')]:
            out = self.call('/api/epitope/export', {'run_id': run['id'], 'candidate_ids': ids, 'format': fmt})
            data = self.call(out['download'], binary=True)
            self.assertTrue(data.startswith(magic), fmt)

    def test_03_evidence_and_validation(self):
        eid = self.call('/api/epitope/evidence', {
            'title': '验收证据', 'protein_pattern': 'BP26|Q6YA76', 'evidence_type': '表位实验研究',
            'relation': '支持候选', 'source': '验收', 'confidence': 0.81,
            'url': 'https://example.org/evidence', 'summary': '隔离验收记录'
        })['id']
        rows = self.call('/api/epitope/evidence?q=验收证据')
        self.assertTrue(any(x['id'] == eid for x in rows))
        with self.assertRaises(urllib.error.HTTPError):
            self.call('/api/epitope/analyze', {'project_id': self.pid, 'protein_name': '坏序列', 'sequence': 'ACD-123', 'tools': ['hydrophilicity']})

    def test_04_provenance_visualization_and_report(self):
        pid = self.__class__.pid
        source_id = self.call('/api/sources', {'name': '验收 UniProt 来源', 'source_type': '蛋白质数据库',
                                               'source_url': 'https://www.uniprot.org/uniprotkb/Q6YA76',
                                               'description': '跨模块来源关联验收'})['id']
        dataset = self.upload(pid, source_id, '验收 BP26 数据集', '>BP26 Q6YA76\n' + BP26 + '\n')
        record = self.call('/api/datasets/' + dataset['id'] + '/records')[0]
        run = self.call('/api/epitope/analyze', {
            'project_id': pid, 'protein_name': 'BP26 来源关联', 'accession': 'Q6YA76',
            'organism': 'Brucella abortus', 'sequence': BP26,
            'tools': ['hydrophilicity', 'flexibility', 'accessibility', 'turn'],
            'weights': {'coverage': 35, 'strength': 30, 'evidence': 20, 'consistency': 15},
            'dataset_id': dataset['id'], 'record_id': record['id'], 'source_id': source_id
        })
        self.assertEqual(run['dataset_name'], '验收 BP26 数据集')
        self.assertEqual(run['record_key'], record['record_key'])
        self.assertEqual(run['source_name'], '验收 UniProt 来源')
        self.assertTrue(run['output_evidence_id'])
        center_evidence = self.call('/api/evidence')
        self.assertTrue(any(x['id'] == run['output_evidence_id'] for x in center_evidence))
        vis = self.call('/api/epitope/visualization/summary?project_id=' + pid)
        self.assertGreaterEqual(vis['kpis']['runs'], 1)
        self.assertTrue(vis['top_candidates'])
        report = self.call('/api/reports', {'project_id': pid, 'format': 'json'})
        payload = json.loads(self.call(report['download'], binary=True))
        self.assertTrue(payload['抗原运行记录'])
        self.assertTrue(payload['抗原候选结果'])
        self.assertTrue(payload['抗原排序版本'])
        self.assertIn('抗原证据线索', payload)

if __name__ == '__main__':
    unittest.main(verbosity=2)








