# -*- coding: utf-8 -*-
"""使用隔离数据目录和真实 HTTP 服务验证六大模块。"""
import os,sys,tempfile,subprocess,time,json,urllib.request,urllib.error,http.cookiejar,socket,zipfile,io,unittest,sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def make_two_row_header_xlsx():
    """生成两行表头的轻量 XLSX，作为导入回归测试样本。"""
    def c(ref,text):
        return f'<c r="{ref}" t="inlineStr"><is><t>{text}</t></is></c>'
    rows=[
        ('1',['Epitope','Epitope','Related Object','Related Object']),
        ('2',['Epitope ID','Name','Object Type','Related Name']),
        ('3',['http://www.iedb.org/epitope/1073','AEMGGHAER','','']),
        ('4',['http://www.iedb.org/epitope/2523','ALFEDYPGC','Linear peptide','Protein A']),
    ]
    sheet=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
    for rn,vals in rows:
        sheet.append(f'<row r="{rn}">')
        for i,v in enumerate(vals):
            sheet.append(c(chr(65+i)+rn,v))
        sheet.append('</row>')
    sheet.append('</sheetData></worksheet>')
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml','<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml',''.join(sheet))
    return buf.getvalue()
class Acceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(dir=ROOT)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0));cls.port=sock.getsockname()[1]
        cls.env={**os.environ,'EPIWORK_DATA':cls.tmp.name,'EPIWORK_PORT':str(cls.port)}
        cls.log=open(Path(cls.tmp.name)/'服务.log','w')
        cls.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env=cls.env,stdout=cls.log,stderr=cls.log)
        cls.client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        for _ in range(100):
            try:cls.call('/api/health');break
            except Exception:time.sleep(.05)
        else:raise RuntimeError('服务启动失败')
    @classmethod
    def tearDownClass(cls):cls.proc.terminate();cls.proc.wait();cls.log.close();cls.tmp.cleanup()
    @classmethod
    def call(cls,path,data=None,method=None,binary=False,headers=None):
        path=urllib.parse.quote(path,safe='/?=&%')
        raw=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode() if data is not None else None
        req=urllib.request.Request(f'http://127.0.0.1:{cls.port}'+path,data=raw,method=method,headers=headers or ({'Content-Type':'application/json'} if raw else {}))
        try: response=cls.client.open(req,timeout=15)
        except urllib.error.HTTPError as e:
            print('接口错误',path,e.code,e.read().decode());raise
        with response as r:
            b=r.read();return b if binary else json.loads(b)
    def upload(self,pid,name,content,did=''):
        boundary='testboundary';fields={'project_id':pid,'name':name,'dataset_id':did}
        body=b''.join(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k,v in fields.items())
        body+=f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()+content+f'\r\n--{boundary}--\r\n'.encode()
        return self.call('/api/upload',body,headers={'Content-Type':f'multipart/form-data; boundary={boundary}'})
    def wait_job(self,jid):
        for _ in range(200):
            j=self.call('/api/jobs/'+jid)
            if j['status'] not in ('QUEUED','RUNNING','PENDING'):return j
            time.sleep(.02)
        self.fail('任务未结束')
    def test_01_认证与项目(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.call('/api/projects')
        self.assertEqual(e.exception.code,401)
        with self.assertRaises(urllib.error.HTTPError):self.call('/api/login',{'username':'管理员','password':'wrong'})
        self.call('/api/login',{'username':'管理员','password':'epiwork123'})
        type(self).pid=self.call('/api/projects',{'name':'验收项目','description':'隔离测试'})['id']
        self.call('/api/projects/'+self.pid,{'name':'验收项目已更新'},method='PUT')
        self.assertTrue(any(p['name']=='验收项目已更新' for p in self.call('/api/projects')))
    def test_02_四格式与校验版本(self):
        for name,content in [('normal.csv',b'id,name\na,Alpha\nb,Beta\n'),('normal.tsv',b'id\tname\na\tAlpha\n'),('normal.json',b'[{"id":"a","name":"Alpha"}]'),('normal.fasta',b'>a\nACGT\n')]:
            d=self.upload(self.pid,name,content);self.assertGreater(d['records'],0)
            if name.endswith('csv'):type(self).did=d['id']
            if name.endswith('fasta'):type(self).fasta=d['id']
        old=self.call('/api/datasets/'+self.did+'/records')[0]['id']
        d=self.upload(self.pid,'updated.csv',b'id,name\na,Alpha\na,\n',self.did)
        self.assertEqual(d['version'],2);self.assertEqual(d['invalid_count'],1);self.assertEqual(d['warning_count'],1)
        self.assertEqual(self.call('/api/datasets/'+self.did+'/records')[0]['id'],old)
        self.assertEqual(len(self.call('/api/datasets/'+self.did+'/versions')),2)
        with self.assertRaises(urllib.error.HTTPError):self.upload(self.pid,'bad.json',b'{')
        self.assertTrue(self.call('/api/datasets/search?项目='+self.pid))
        xpid=self.call('/api/projects',{'name':'XLSX兼容测试'})['id']
        xd=self.upload(xpid,'两行表头测试.xlsx',make_two_row_header_xlsx())
        self.assertEqual(xd['records'],2);self.assertEqual(xd['valid_count'],2);self.assertEqual(xd['invalid_count'],0)
        self.assertTrue(xd['warning_count']>=1)
        xrec=self.call('/api/datasets/'+xd['id']+'/records')[0]
        self.assertEqual(xrec['record_key'],'1073');self.assertIn('Epitope / Name',json.loads(xrec['metadata']))
        self.call('/api/projects/'+xpid,method='DELETE')
        type(self).record=old
    def test_03_证据关联版本追溯(self):
        sid=self.call('/api/sources',{'name':'测试来源','source_url':'https://example.org'})['id']
        eid=self.call('/api/evidence',{'source_id':sid,'title':'测试证据','url':'https://example.org','status':'待核验'})['id']
        self.call('/api/evidence/link',{'evidence_id':eid,'record_id':self.record,'relation':'支持'})
        self.call('/api/evidence/update',{'id':eid,'status':'有争议','conflict_group':'测试冲突','title':'证据新版本'})
        versions=self.call('/api/evidence/versions?evidence_id='+eid)
        self.assertEqual(len(versions),2);self.assertEqual(json.loads(versions[0]['payload'])['status'],'有争议')
        self.assertEqual(self.call('/api/trace-chain?record_id='+self.record)['证据'][0]['id'],eid)
    def test_04_任务质检缓存重运行(self):
        data={'project_id':self.pid,'tool_id':'工具-基础质检','params':{}}
        jid=self.call('/api/jobs',data)['id'];j=self.wait_job(jid)
        self.assertEqual(j['status'],'SUCCESS');self.assertEqual(json.loads(j['result'])['记录数'],5)
        self.assertTrue(self.call('/api/jobs',data)['缓存命中'])
        retry=self.call('/api/jobs/retry',{'id':jid})['id'];self.assertEqual(self.wait_job(retry)['parent_job_id'],jid)
        normal=self.call('/api/jobs',{'project_id':self.pid,'tool_id':'工具-记录标准化','params':{'字段映射':{'name':'名称'}}})['id']
        self.assertEqual(self.wait_job(normal)['status'],'SUCCESS');self.assertTrue(self.call('/api/normalized'))
        self.assertTrue(self.call('/api/job-input/'+jid)['payload'])
        self.assertTrue(self.call('/api/jobs/'+jid+'/result',binary=True))
    def test_05_评价规则复核快照(self):
        result=self.call('/api/evaluate',{'project_id':self.pid});self.assertEqual(len(result),5)
        self.assertEqual(result[0]['维度']['证据一致性'],0)
        self.call('/api/review',{'evaluation_id':result[0]['评价编号'],'status':'已复核','notes':'测试意见'})
        self.assertTrue(self.call('/api/reviews'))
        rule=self.call('/api/rules',{'name':'质量优先','version':'2','configuration':{'数据质量':100}})['id']
        self.call('/api/evaluate',{'project_id':self.pid,'rule_id':rule})
        self.assertEqual(len([r for r in self.call('/api/results') if r['project_id']==self.pid]),10)
        snap=self.call('/api/snapshot',{'project_id':self.pid})['id']
        saved=next(x for x in self.call('/api/snapshots') if x['id']==snap)
        self.assertTrue(json.loads(saved['payload'])['原始记录'])
        summary=next(x for x in self.call('/api/snapshots/summary') if x['id']==snap)
        self.assertEqual(summary['summary']['记录数'],5)
        with self.assertRaises(urllib.error.HTTPError):self.call('/api/rules',{'name':'坏规则','configuration':{'数据质量':-1}})
    def test_06_可视化与多格式导出(self):
        self.assertTrue(self.call('/api/visualization/summary')['完整性']);self.assertTrue(self.call('/api/network')['关联'])
        for fmt in ['csv','json','xlsx','fasta']:
            d=self.call('/api/export/dataset/'+(self.fasta if fmt=='fasta' else self.did)+'?format='+fmt)
            b=self.call(d['下载'],binary=True);self.assertTrue(b)
            if fmt=='xlsx':self.assertIn('xl/worksheets/sheet1.xml',zipfile.ZipFile(io.BytesIO(b)).namelist())
            if fmt=='fasta':self.assertIn(b'>a\nACGT\n',b)
        for fmt in ['pdf','html','csv','json']:
            r=self.call('/api/reports',{'project_id':self.pid,'format':fmt});b=self.call(r['download'],binary=True)
            if fmt=='pdf':
                self.assertTrue(b.startswith(b'%PDF'));self.assertIn(b'/FontFile2',b);self.assertIn(b'NotoSansSC-Regular',b);(ROOT/'测试'/'报告样本.pdf').write_bytes(b)
            if fmt=='json':self.assertEqual(json.loads(b)['项目基本信息']['id'],self.pid)
        tid=self.call('/api/report-templates',{'name':'简报','sections':['项目基本信息']})['id']
        r=self.call('/api/reports',{'project_id':self.pid,'format':'json','template_id':tid});b=json.loads(self.call(r['download'],binary=True))
        self.assertNotIn('原始记录',b)
    def test_06b_超时取消失败与隔离(self):
        pid=self.call('/api/projects',{'name':'异常任务测试'})['id']
        self.upload(pid,'large.csv',('id,name\n'+''.join(f'{i},记录{i}\n' for i in range(1000))).encode())
        task={'project_id':pid,'tool_id':'工具-基础质检','params':{},'timeout_seconds':0.001}
        j=self.wait_job(self.call('/api/jobs',task)['id'])
        self.assertIn(j['status'],['FAILED','PARTIAL']);self.assertIn('超时',j['logs'])
        task['timeout_seconds']=60;task['params']={'测试批次':'取消'}
        jid=self.call('/api/jobs',task)['id'];self.call('/api/jobs/cancel',{'id':jid});self.assertEqual(self.wait_job(jid)['status'],'CANCELLED')
        bad={'project_id':pid,'tool_id':'工具-记录标准化','params':{'字段映射':{'id':'相同','name':'相同'}}}
        self.assertEqual(self.wait_job(self.call('/api/jobs',bad)['id'])['status'],'FAILED')
        r=self.call('/api/reports',{'project_id':pid,'format':'json'})
        report=json.loads(self.call(r['download'],binary=True));self.assertFalse(report['关联证据'])
        self.call('/api/projects/'+pid,method='DELETE')
    def test_06c_重启持久化(self):
        self.proc.terminate();self.proc.wait()
        type(self).proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env=self.env,stdout=self.log,stderr=self.log)
        for _ in range(100):
            try:self.call('/api/health');break
            except Exception:time.sleep(.05)
        self.assertTrue(any(p['id']==self.pid for p in self.call('/api/projects')))
        self.assertEqual(len(self.call('/api/datasets/'+self.did+'/versions')),2)
    def test_07_数据库持久化和删除(self):
        c=sqlite3.connect(Path(self.tmp.name)/'epiwork.db')
        try:
            self.assertGreater(c.execute('SELECT count(*) FROM audit').fetchone()[0],0)
            self.assertNotEqual(c.execute('SELECT password FROM users').fetchone()[0],'epiwork123')
        finally:
            c.close()
        pid=self.call('/api/projects',{'name':'待删除'})['id'];self.call('/api/projects/'+pid,method='DELETE')
        self.assertFalse(any(x['id']==pid for x in self.call('/api/projects')))
        self.call('/api/logout',{})
        with self.assertRaises(urllib.error.HTTPError):self.call('/api/projects')
if __name__=='__main__':unittest.main(verbosity=2)
