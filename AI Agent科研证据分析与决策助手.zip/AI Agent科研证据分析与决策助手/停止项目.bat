@echo off
chcp 65001 >nul
echo 正在停止本机科研工作台（仅结束占用 8765 端口的 Python 进程）...
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /R /C:":8765 .*LISTENING"') do taskkill /PID %%p /F >nul 2>nul
echo 已停止。若窗口仍显示，请关闭启动窗口即可。
pause
