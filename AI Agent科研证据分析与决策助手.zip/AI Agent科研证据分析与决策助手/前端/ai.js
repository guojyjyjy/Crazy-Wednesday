// Brucella-EpiWork AI 决策与评估
let aiMeta = null;
let aiRuns = [];
let aiEvals = [];
let aiCurrent = null;
let aiProjectFilter = '';
let aiRunFilter = '';

async function showAI() {
  title('AI决策与评估');
  const content = document.querySelector('#content');
  content.innerHTML = '<div class="epi-loading"><span></span>正在加载 DeepSeek 配置与抗原决策结果……</div>';
  try {
    aiMeta = await api('/api/ai/meta');
    aiProjectFilter = aiProjectFilter || projects[0]?.id || '';
    const [runs, evals] = await Promise.all([
      api('/api/epitope/runs' + (aiProjectFilter ? '?project_id=' + encodeURIComponent(aiProjectFilter) : '')),
      api('/api/ai/evaluations' + (aiProjectFilter ? '?project_id=' + encodeURIComponent(aiProjectFilter) : ''))
    ]);
    aiRuns = runs || [];
    aiEvals = evals || [];
    aiRunFilter = aiRunFilter && aiRuns.some(x => x.id === aiRunFilter) ? aiRunFilter : (aiRuns[0]?.id || '');
    renderAIPage();
  } catch (e) {
    content.innerHTML = `<div class="notice warn">AI 决策与评估加载失败：${esc(e.message)}</div>`;
  }
}

function aiProjectOptions() {
  return projects.map(p => `<option value="${esc(p.id)}" ${p.id === aiProjectFilter ? 'selected' : ''}>${esc(p.name)}</option>`).join('') || '<option value="">暂无项目</option>';
}
function aiRunOptions() {
  return aiRuns.map(r => `<option value="${esc(r.id)}" ${r.id === aiRunFilter ? 'selected' : ''}>${esc(r.protein_name)} · ${esc(r.status)} · ${r.candidate_count || 0} 条候选 · ${esc(r.created_at)}</option>`).join('') || '<option value="">当前项目暂无抗原运行</option>';
}
function aiConfidenceBadge(level) {
  const value = level || '低';
  const cls = value === '高' ? 'green' : value === '中' ? 'orange' : 'red';
  return `<span class="ai-badge ${cls}">AI 置信度 ${esc(value)}</span>`;
}
function aiStatus(status) {
  const map = {SUCCESS: ['成功', 'green'], FAILED: ['失败', 'red'], RUNNING: ['运行中', 'orange']};
  const pair = map[status] || [status || '未知', 'gray'];
  return `<span class="ai-badge ${pair[1]}">${esc(pair[0])}</span>`;
}
function aiList(items, empty = '暂无') {
  if (!items || !items.length) return `<p class="ai-empty">${esc(empty)}</p>`;
  return `<ul class="ai-list">${items.map(x => `<li>${esc(x)}</li>`).join('')}</ul>`;
}
function aiRunChain(run) {
  return [run.dataset_name || '未关联数据集', run.record_key || '未关联记录', run.source_name || '未关联来源'].filter(Boolean).join(' → ');
}

function renderAIPage() {
  const content = document.querySelector('#content');
  if (!aiMeta) return;
  const run = aiRuns.find(x => x.id === aiRunFilter) || aiRuns[0] || null;
  const configured = aiMeta.configured ? '<span class="ai-badge green">DeepSeek 已连接</span>' : '<span class="ai-badge red">未配置 API Key</span>';
  content.innerHTML = `
    <section class="ai-hero">
      <div>
        <span class="epi-eyebrow">AI DECISION EXPLANATION</span>
        <h3>AI 决策与评估</h3>
        <p>基于已有项目来源、证据中心线索、抗原运行分数和联网检索材料，由 DeepSeek 解释蛋白可能功能、评分依据与不确定性。</p>
      </div>
      <div class="ai-hero-side">${configured}<span>${esc(aiMeta.provider)} / ${esc(aiMeta.model)}</span></div>
    </section>
    <div class="ai-warning"><b>边界：</b>AI 只做解释与综合评估，不产生新的实验数据，不把共识分解释为实验概率。</div>
    <section class="epi-panel">
      <div class="epi-panel-head"><div><span>EVALUATION SOURCE</span><h3>选择已有抗原运行</h3></div><div class="epi-inline-badges"><span>项目数据驱动</span><span>联网检索</span><span>结果归档</span></div></div>
      <div class="ai-controls">
        <div class="field"><label>项目</label><select id="aiProject" onchange="aiProjectChanged(this.value)">${aiProjectOptions()}</select></div>
        <div class="field"><label>抗原运行</label><select id="aiRun" onchange="aiRunChanged(this.value)">${aiRunOptions()}</select></div>
        <div class="field"><label>评估范围</label><select id="aiFocus"><option value="selected_or_top">优先已选候选，否则 Top 10</option><option value="top10">Top 10 候选</option><option value="protein">仅蛋白级综合评估</option></select></div>
        <div class="field ai-run-button"><label>&nbsp;</label><button id="aiEvaluateBtn" onclick="aiEvaluate()" ${run && aiMeta.configured ? '' : 'disabled'}>开始 AI 检索与评估</button></div>
      </div>
      ${run ? `<div class="ai-run-card"><div><span>${esc(run.protein_name)}</span><b>${esc(run.accession || '无 Accession')}</b></div><p>${aiRunChain(run)}</p><p>${esc(run.status)} · ${run.candidate_count || 0} 条候选 · ${esc(run.created_at)}</p></div>` : '<div class="notice warn">当前项目暂无抗原运行，请先完成一次抗原决策分析。</div>'}
      <div id="aiProgress" class="ai-progress hidden"></div>
    </section>
    <section id="aiResult">${aiCurrent ? aiRenderResult() : aiRenderEmpty()}</section>
    <section class="epi-panel"><div class="epi-panel-head"><div><span>HISTORY</span><h3>AI 评估历史</h3></div><button class="secondary" onclick="aiLoadHistory()">刷新</button></div><div id="aiHistory">${aiRenderHistory()}</div></section>`;
}

function aiRenderEmpty() {
  return `<div class="epi-empty-result"><div>✦</div><b>等待一次 AI 证据检索与综合评估</b><p>选择抗原运行后，系统会先检索 UniProt、Europe PMC 和证据中心，再由 DeepSeek 生成结构化解释。</p></div>`;
}

async function aiProjectChanged(projectId) {
  aiProjectFilter = projectId;
  aiRunFilter = '';
  await aiReloadData();
}
async function aiRunChanged(runId) {
  aiRunFilter = runId;
  aiCurrent = null;
  renderAIPage();
}
async function aiReloadData() {
  const projectId = aiProjectFilter;
  const [runs, evals] = await Promise.all([
    api('/api/epitope/runs' + (projectId ? '?project_id=' + encodeURIComponent(projectId) : '')),
    api('/api/ai/evaluations' + (projectId ? '?project_id=' + encodeURIComponent(projectId) : ''))
  ]);
  aiRuns = runs || [];
  aiEvals = evals || [];
  if (!aiRuns.some(x => x.id === aiRunFilter)) aiRunFilter = aiRuns[0]?.id || '';
  if (!aiEvals.some(x => x.id === aiCurrent?.id)) aiCurrent = null;
  renderAIPage();
}

async function aiEvaluate() {
  if (!aiRunFilter) return toast('请先选择抗原运行');
  const btn = document.querySelector('#aiEvaluateBtn');
  const progress = document.querySelector('#aiProgress');
  if (btn) { btn.disabled = true; btn.textContent = '正在联网检索与综合评估…'; }
  if (progress) {
    progress.classList.remove('hidden');
    progress.innerHTML = '<div class="ai-progress-step active"><b>1</b><span>读取抗原运行、工具状态、候选分数与来源链</span></div>' +
      '<div class="ai-progress-step"><b>2</b><span>检索证据中心、UniProt 与 Europe PMC</span></div>' +
      '<div class="ai-progress-step"><b>3</b><span>调用 DeepSeek 生成结构化综合评估</span></div>';
  }
  try {
    const result = await post('/api/ai/evaluate', {run_id: aiRunFilter, focus: document.querySelector('#aiFocus')?.value || 'selected_or_top'});
    aiCurrent = result;
    await aiReloadData();
    aiCurrent = result;
    renderAIPage();
    const resultEl = document.querySelector('#aiResult');
    if (resultEl) resultEl.scrollIntoView({behavior: 'smooth', block: 'start'});
    toast('AI 评估完成并已归档');
  } catch (e) {
    toast(e.message);
    if (progress) progress.innerHTML = `<div class="ai-progress-error">${esc(e.message)}</div>`;
    await aiLoadHistory();
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '开始 AI 检索与评估'; }
  }
}

function aiRenderResult() {
  if (!aiCurrent) return aiRenderEmpty();
  const r = aiCurrent.result || {};
  const run = aiCurrent.context?.decision || {};
  const retrieval = aiCurrent.retrieval || {};
  const uniprot = retrieval.uniprot || {};
  const articles = retrieval.articles || [];
  const citations = aiCurrent.citations || [];
  const contextEvidence = aiCurrent.context?.evidence_center || {};
  return `
    <section class="ai-result-hero">
      <div><span>AI ASSESSMENT / ${esc(aiCurrent.id)}</span><h3>${esc(aiCurrent.protein_name)} · 综合评估</h3><p>${esc(aiCurrent.project_name || aiCurrent.project_id)} · ${esc(aiCurrent.model)} · ${esc(aiCurrent.completed_at || aiCurrent.created_at)}</p></div>
      <div>${aiStatus(aiCurrent.status)}${aiConfidenceBadge(r.confidence_level)}</div>
    </section>
    <div class="ai-kpis">
      <div><span>候选范围</span><b>${(run.candidates || []).length}</b><small>${esc(aiCurrent.focus)}</small></div>
      <div><span>证据中心线索</span><b>${(contextEvidence.linked || []).length + (contextEvidence.matched || []).length}</b><small>关联与匹配</small></div>
      <div><span>Europe PMC</span><b>${articles.length}</b><small>联网文献</small></div>
      <div><span>UniProt</span><b>${uniprot.status === 'success' ? '已命中' : '未命中'}</b><small>${esc(uniprot.accession || '—')}</small></div>
    </div>
    <div class="ai-result-grid">
      <section class="ai-card ai-card-wide"><h4>蛋白质可能功能</h4><p>${esc(r.function_summary || '模型未返回功能摘要')}</p></section>
      <section class="ai-card"><h4>评分依据</h4><p>${esc(r.score_interpretation || '模型未返回评分解释')}</p></section>
      <section class="ai-card"><h4>综合评估</h4><p>${esc(r.overall_assessment || '模型未返回综合评估')}</p></section>
      <section class="ai-card"><h4>支持要点</h4>${aiList(r.supporting_points, '暂无支持要点')}</section>
      <section class="ai-card"><h4>不确定性</h4>${aiList(r.uncertainties, '暂无不确定性说明')}</section>
      <section class="ai-card"><h4>建议验证</h4>${aiList(r.recommended_validation, '暂无建议')}</section>
      <section class="ai-card ai-card-wide"><h4>检索与引用</h4>
        <div class="ai-retrieval-summary">
          <span>UniProt：${esc(uniprot.status || 'skipped')}</span>
          <span>Europe PMC：${articles.length} 条</span>
          <span>证据中心：${(contextEvidence.linked || []).length + (contextEvidence.matched || []).length} 条</span>
          <span>模型：${esc(aiCurrent.model)}</span>
        </div>
        <div class="tablewrap ai-citations"><table><thead><tr><th>来源</th><th>标题</th><th>链接</th></tr></thead><tbody>${citations.map(c => `<tr><td>${esc(c.source || '')}</td><td>${esc(c.title || '')}</td><td>${c.url ? `<a href="${esc(c.url)}" target="_blank" rel="noopener">打开</a>` : '—'}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">暂无引用</td></tr>'}</tbody></table></div>
      </section>
    </div>
    <div class="notice warn">AI 输出是基于已有计算证据和联网文献的解释性综合评估，不是新的实验结论，也不构成诊断、疫苗设计或保护性结论。</div>`;
}

function aiRenderHistory() {
  const rows = (aiEvals || []).map(e => `<tr>
    <td><b>${esc(e.protein_name)}</b><small>${esc(e.run_id)}</small></td>
    <td>${aiStatus(e.status)}</td>
    <td>${esc(e.model || '')}</td>
    <td>${esc(e.created_at)}</td>
    <td><button class="epi-rowbtn" onclick="aiOpenEvaluation('${esc(e.id)}')">打开</button></td>
  </tr>`).join('');
  return `<div class="tablewrap ai-history"><table><thead><tr><th>蛋白 / 运行</th><th>状态</th><th>模型</th><th>时间</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="empty">尚无 AI 评估记录</td></tr>'}</tbody></table></div>`;
}

async function aiLoadHistory() {
  aiEvals = await api('/api/ai/evaluations' + (aiProjectFilter ? '?project_id=' + encodeURIComponent(aiProjectFilter) : ''));
  const target = document.querySelector('#aiHistory');
  if (target) target.innerHTML = aiRenderHistory();
}
async function aiOpenEvaluation(id) {
  try {
    aiCurrent = await api('/api/ai/evaluations/' + encodeURIComponent(id));
    aiProjectFilter = aiCurrent.project_id || aiProjectFilter;
    aiRunFilter = aiCurrent.run_id || aiRunFilter;
    renderAIPage();
    setTimeout(() => document.querySelector('#aiResult')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 50);
  } catch (e) { toast(e.message); }
}
