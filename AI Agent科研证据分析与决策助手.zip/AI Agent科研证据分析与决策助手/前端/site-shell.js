let siteCarouselIndex = 0;
let siteCarouselTimer = null;

function siteCarouselGo(index) {
  const slides = [...document.querySelectorAll('#globalCarousel .site-slide')];
  const dots = [...document.querySelectorAll('#globalCarousel .site-carousel-dots button')];
  if (!slides.length) return;
  siteCarouselIndex = ((index % slides.length) + slides.length) % slides.length;
  slides.forEach((slide, i) => slide.classList.toggle('active', i === siteCarouselIndex));
  dots.forEach((dot, i) => dot.classList.toggle('active', i === siteCarouselIndex));
}
function siteCarouselStep(direction) {
  siteCarouselGo(siteCarouselIndex + direction);
  siteCarouselRestart();
}
function siteCarouselRestart() {
  if (siteCarouselTimer) clearInterval(siteCarouselTimer);
  siteCarouselTimer = setInterval(() => siteCarouselGo(siteCarouselIndex + 1), 4800);
}
document.addEventListener('DOMContentLoaded', () => {
  const carousel = document.querySelector('#globalCarousel');
  if (!carousel) return;
  siteCarouselGo(0);
  siteCarouselRestart();
  carousel.addEventListener('mouseenter', () => { if (siteCarouselTimer) clearInterval(siteCarouselTimer); });
  carousel.addEventListener('mouseleave', siteCarouselRestart);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && siteCarouselTimer) clearInterval(siteCarouselTimer);
    else if (!document.hidden) siteCarouselRestart();
  });
});
