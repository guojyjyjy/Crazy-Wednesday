// Brucella-EpiWork 3.1 抗原候选决策台
let epiMeta = null;
let epiProteins = [];
let epiRuns = [];
let epiEvidence = [];
let epiResult = null;
let epiWeights = {coverage: 35, strength: 30, evidence: 20, consistency: 15};
let epiSelected = new Set();
let epiRankingDirty = false;
let epiRecordCache = [];

function epiPct(value, digits = 0) {
  return Number(value || 0).toFixed(digits) + '%';
}
function epiPill(text, kind = '') {
  return `<span class="epi-pill ${kind}">${esc(text)}</span>`;
}
function epiRunStatus(status) {
  const map = {SUCCESS: ['成功', 'green'], PARTIAL: ['部分成功', 'orange'], FAILED: ['失败', 'red'], RUNNING: ['运行中', 'blue']};
  const pair = map[status] || [status || '未知', ''];
  return epiPill(pair[0], pair[1]);
}
function epiToolStatus(status) {
  const map = {SUCCESS: ['完成', 'green'], EMPTY: ['无区域', 'orange'], FAILED: ['降级', 'red']};
  const pair = map[status] || [status, ''];
  return epiPill(pair[0], pair[1]);
}
function epiProjectId() {
  return document.querySelector('#epiProject')?.value || projects[0]?.id || '';
}
async function epiEnsureProject() {
  if (projects.length) return projects[0].id;
  const created = await post('/api/projects', {name: '布鲁氏菌抗原决策项目', description: 'Brucella-EpiWork 3.0 抗原候选决策演示项目', owner: '管理员'});
  projects.unshift({id: created.id, name: '布鲁氏菌抗原决策项目', description: 'Brucella-EpiWork 3.0 抗原决策演示项目'});
  const sel = document.querySelector('#epiProject');
  if (sel) sel.insertAdjacentHTML('afterbegin', `<option value="${esc(created.id)}">布鲁氏菌抗原决策项目</option>`);
  return created.id;
}
async function epiCreateProject() {
  modal('新建布病抗原项目', field('项目名称', 'name', '例如：布鲁氏菌多表位抗原筛选') + '<div class="field"><label>项目说明</label><textarea name="description" placeholder="记录研究目标、候选蛋白范围或团队分工"></textarea></div>', async m => {
    const name = val(m, 'name').trim();
    if (!name) throw Error('项目名称不能为空');
    const created = await post('/api/projects', {name, description: val(m, 'description'), owner: '管理员'});
    projects.unshift({id: created.id, name, description: val(m, 'description')});
    toast('项目已创建');
    await epiShowWorkbench();
  });
}

async function epiShowWorkbench() {
  title('抗原决策台');
  const content = document.querySelector('#content');
  content.innerHTML = '<div class="epi-loading"><span></span>正在加载项目数据、工具服务与历史运行……</div>';
  try {
    const [meta, proteins, runs, freshDatasets, freshSources] = await Promise.all([
      api('/api/epitope/meta'), api('/api/epitope/proteins'), api('/api/epitope/runs'),
      api('/api/datasets'), api('/api/sources')
    ]);
    epiMeta = meta;
    const initialProjectId = projects[0]?.id || '';
    epiProteins = initialProjectId ? proteins.filter(x => x.project_id === initialProjectId) : proteins;
    epiRuns = initialProjectId ? runs.filter(x => x.project_id === initialProjectId) : runs;
    epiEvidence = [];
    datasets = freshDatasets;
    sources = freshSources;
    if (!epiResult) {
      epiWeights = {coverage: 35, strength: 30, evidence: 20, consistency: 15};
    }
    epiRenderWorkbench();
  } catch (e) {
    content.innerHTML = `<div class="notice warn">抗原决策台加载失败：${esc(e.message)}<br>请确认当前版本已包含 epitope.py 领域模块。</div>`;
  }
}

function epiProjectOptions() {
  if (!projects.length) return '<option value="">尚未创建项目</option>';
  return projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
}
function epiSequenceDatasets() {
  const pid = epiProjectId();
  return (datasets || []).filter(d => (!pid || d.project_id === pid) && ['FASTA','FA','FAA','FNA'].includes(String(d.type || '').toUpperCase()));
}
function epiDatasetOptions() {
  return '<option value="">请选择数据中心数据集</option>' + epiSequenceDatasets().map(d => `<option value="${esc(d.id)}">${esc(d.name)} · ${d.record_count || 0} 条 · ${esc(d.type)}</option>`).join('');
}
function epiSourceOptions(selected = '') {
  return '<option value="">不关联来源</option>' + (sources || []).map(x => `<option value="${esc(x.id)}" ${selected === x.id ? 'selected' : ''}>${esc(x.name)} · ${esc(x.source_type || '')}</option>`).join('');
}
function epiProvenanceText() {
  const projectId = epiProjectId();
  const project = projects.find(p => p.id === projectId);
  const datasetId = document.querySelector('#epiDatasetSelect')?.value || '';
  const recordId = document.querySelector('#epiRecordSelect')?.value || '';
  const sourceId = document.querySelector('#epiSourceSelect')?.value || '';
  const dataset = datasets.find(d => d.id === datasetId);
  const record = epiRecordCache.find(r => r.id === recordId);
  const source = sources.find(x => x.id === sourceId);
  return [
    project ? `<b>项目</b> ${esc(project.name)}` : '<b>项目</b> 未选择',
    dataset ? `<b>数据集</b> ${esc(dataset.name)}` : '<b>数据集</b> 未关联',
    record ? `<b>记录</b> ${esc(record.record_key)}` : '<b>记录</b> 未关联',
    source ? `<b>来源</b> ${esc(source.name)}` : '<b>来源</b> 未关联'
  ].join('<i>→</i>');
}
function epiUpdateProvenance() {
  const el = document.querySelector('#epiProvenance');
  if (el) el.innerHTML = epiProvenanceText();
}
async function epiLoadDatasetRecords() {
  const datasetId = document.querySelector('#epiDatasetSelect')?.value || '';
  const recordSelect = document.querySelector('#epiRecordSelect');
  epiRecordCache = [];
  if (recordSelect) recordSelect.innerHTML = '<option value="">先从数据集读取记录</option>';
  if (!datasetId) { epiUpdateProvenance(); return; }
  const dataset = datasets.find(d => d.id === datasetId);
  if (dataset?.source_id) {
    const sourceSelect = document.querySelector('#epiSourceSelect');
    if (sourceSelect) sourceSelect.value = dataset.source_id;
  }
  try {
    const records = await api('/api/datasets/' + encodeURIComponent(datasetId) + '/records');
    epiRecordCache = (records || []).filter(r => String(r.content || '').trim());
    if (recordSelect) recordSelect.innerHTML = '<option value="">选择一条序列记录</option>' + epiRecordCache.map(r => `<option value="${esc(r.id)}">${esc(r.record_key)} · ${String(r.content || '').replace(/\s+/g, '').length} aa</option>`).join('');
    toast('已读取 ' + epiRecordCache.length + ' 条序列记录');
  } catch (e) { toast(e.message); }
  epiUpdateProvenance();
}
function epiLoadRecordSequence() {
  const recordId = document.querySelector('#epiRecordSelect')?.value || '';
  const rec = epiRecordCache.find(r => r.id === recordId);
  if (!rec) { epiUpdateProvenance(); return; }
  let meta = {};
  try { meta = JSON.parse(rec.metadata || '{}'); } catch (e) {}
  document.querySelector('#epiProteinName').value = rec.record_key || '未命名蛋白';
  const accessionMatch = String(rec.record_key || '').match(/\b[A-Z0-9]{6,10}\b/);
  document.querySelector('#epiAccession').value = meta.Accession || meta.accession || meta['Accession Number'] || (accessionMatch ? accessionMatch[0] : '');
  const organism = meta.Organism || meta.organism || meta['Source Organism'];
  document.querySelector('#epiOrganism').value = organism || 'Brucella abortus';
  document.querySelector('#epiSeqInput').value = String(rec.content || '').replace(/\s+/g, '').toUpperCase();
  epiUpdateSeqCount();
  epiUpdateProvenance();
  toast('已从数据中心载入序列记录');
}

function epiToolCards() {
  return (epiMeta?.tools || []).map(t => {
    const local = t.mode === 'internal';
    return `<label class="epi-tool-card ${local ? 'local' : 'external'}" style="--tool-color:${t.color}">
      <input type="checkbox" id="epiTool_${esc(t.id)}" ${local ? 'checked' : ''}>
      <span class="epi-tool-dot"></span>
      <span><b>${esc(t.name)}</b><small>${local ? '本地可复现' : '外部在线服务'} · ${esc(t.version)}</small></span>
      <em>${esc(t.description)}</em>
    </label>`;
  }).join('');
}
function epiWeightControl(d) {
  return `<div class="epi-weight-row" style="--dim-color:${d.color}">
    <div class="epi-weight-head"><span>${esc(d.name)}</span><b id="epiWeightLabel_${esc(d.id)}">${epiWeights[d.id] ?? d.default}</b></div>
    <input type="range" min="0" max="100" step="1" value="${epiWeights[d.id] ?? d.default}" id="epiWeight_${esc(d.id)}" oninput="epiWeightInput('${esc(d.id)}', this.value)">
    <small>${esc(d.description)}</small>
  </div>`;
}
function epiPresetButtons() {
  return Object.entries(epiMeta?.presets || {}).map(([key, p]) => `<button class="epi-chipbtn" onclick="epiApplyPreset('${esc(key)}')">${esc(p.name)}</button>`).join('');
}
function epiExampleChips() {
  return (epiMeta?.examples || []).map((x, i) => `<button class="epi-example" onclick="epiLoadExample(${i})"><b>${esc(x.name)}</b><small>${esc(x.accession)}</small></button>`).join('');
}
function epiExternalAdapters() {
  return (epiMeta?.external_adapters || []).map(x => `<div class="epi-adapter"><span>${esc(x.name)}</span>${epiPill(x.status, x.status === '已接入' ? 'green' : 'gray')}<small>${esc(x.description)}</small></div>`).join('');
}

function epiRenderWorkbench() {
  const content = document.querySelector('#content');
  const noProject = !projects.length;
  content.innerHTML = `
    <section class="epi-hero">
      <div>
        <span class="epi-eyebrow">BRUCELLA · PROJECT-DRIVEN DECISION SUPPORT</span>
        <h3>从项目数据到抗原候选决策的单一贯通流程</h3>
        <p>决策台不手工录入数据。序列来自数据中心，来源与证据来自证据中心；选择记录后即可运行本地与外部工具，形成可追溯候选。</p>
      </div>
      <div class="epi-hero-actions">
        <button class="secondary" onclick="epiGoPage('projects')">前往项目管理</button>
        <button class="secondary" onclick="epiGoPage('datasets')">前往数据中心</button>
        <button onclick="epiGoPage('evidence')">查看证据中心</button>
      </div>
    </section>
    <div class="epi-steps">
      <div class="done"><b>01</b><span>项目与数据</span><small>项目管理 / 数据中心</small></div>
      <div><b>02</b><span>来源与证据</span><small>证据中心来源登记</small></div>
      <div><b>03</b><span>多工具编排</span><small>4 本地 + 3 外部</small></div>
      <div><b>04</b><span>候选交接</span><small>CSV / FASTA / PDF</small></div>
    </div>
    ${noProject ? '<div class="notice warn"><b>尚未创建项目。</b>请先到项目管理创建项目，再到数据中心导入序列并关联来源。<button class="epi-inline-btn" onclick="epiGoPage(\'projects\')">前往项目管理</button></div>' : ''}
    <div class="epi-layout">
      <section class="epi-panel epi-input-panel">
        <div class="epi-panel-head"><div><span>STEP 01</span><h3>项目数据选择与工具编排</h3></div><div class="epi-inline-badges"><span>无手工输入</span><span>4 本地 + 3 外部</span></div></div>
        <div class="epi-form-grid">
          <div class="field"><label>所属项目</label><select id="epiProject" onchange="epiProjectChanged()">${epiProjectOptions()}</select></div>
          <div class="field"><label>从数据中心关联数据集</label><select id="epiDatasetSelect" onchange="epiLoadDatasetRecords()">${epiDatasetOptions()}</select></div>
          <div class="field"><label>关联序列记录</label><select id="epiRecordSelect" onchange="epiLoadRecordSequence()"><option value="">选择记录</option></select></div>
          <div class="field"><label>数据来源（证据中心）</label><select id="epiSourceSelect" onchange="epiUpdateProvenance()">${epiSourceOptions()}</select></div>
        </div>
        <div id="epiProvenance" class="epi-provenance"></div>
        <div class="epi-record-card">
          <div class="epi-record-meta">
            <div><span>蛋白名称</span><b id="epiRecordProtein">未选择记录</b></div>
            <div><span>Accession</span><b id="epiRecordAccession">—</b></div>
            <div><span>物种</span><b id="epiRecordOrganism">—</b></div>
            <div><span>证据中心匹配</span><b id="epiRecordEvidenceCount">运行后显示</b></div>
          </div>
          <div class="epi-seqbox">
            <div class="epi-seqhead"><label>已载入序列（只读）</label><span id="epiSeqCount">0 aa</span></div>
            <pre id="epiSeqPreview" class="epi-seq-preview">请先从数据中心选择一条序列记录。</pre>
          </div>
        </div>
        <input type="hidden" id="epiProteinName"><input type="hidden" id="epiAccession"><input type="hidden" id="epiOrganism" value="Brucella abortus"><input type="hidden" id="epiSeqInput">
        <div class="epi-block-title"><span>运行工具</span><small>本地工具默认启用；外部工具可按需组合选择</small></div>
        <div class="epi-tools">${epiToolCards()}</div>
        <div class="epi-form-grid">
          <div class="field"><label>容错演示</label><select id="epiFailure"><option value="">正常运行</option>${epiMeta.tools.map(t => `<option value="${esc(t.id)}">模拟 ${esc(t.name)} 失败</option>`).join('')}</select></div>
          <div class="field"><label>外部服务最长等待</label><select id="epiExternalTimeout"><option value="120">120 秒</option><option value="240" selected>240 秒</option><option value="360">360 秒</option><option value="600">600 秒</option></select></div>
        </div>
        <div class="epi-block-title"><span>权重偏好</span><small>拖动后实时重排，点击“保存本次排序”固定版本</small></div>
        <div class="epi-presets">${epiPresetButtons()}</div>
        <div class="epi-weights">${epiMeta.dimensions.map(epiWeightControl).join('')}</div>
        <div class="epi-runbar"><button id="epiRunBtn" onclick="epiRunAnalysis()">运行分析并生成候选</button><span id="epiRunHint">本地约 1 秒；外部服务需联网，可能需要 30–180 秒</span></div>
      </section>
      <aside class="epi-side">
        <section class="epi-panel epi-method">
          <div class="epi-panel-head"><div><span>WORKFLOW</span><h3>贯通的数据链</h3></div></div>
          <div class="epi-persona"><b>项目管理</b><p>确定研究项目与归属，不在此处新增或覆盖项目数据。</p></div>
          <div class="epi-persona"><b>数据中心</b><p>提供候选蛋白序列记录；没有记录时不能运行分析。</p></div>
          <div class="epi-persona"><b>证据中心</b><p>提供数据来源和证据线索；运行结果会自动回流证据中心。</p></div>
          <div class="epi-boundary"><b>科学边界</b><p>${esc(epiMeta.method_note)}</p></div>
        </section>
        <section class="epi-panel">
          <div class="epi-panel-head"><div><span>EXTERNAL SERVICES</span><h3>外部工具接入状态</h3></div></div>
          <div class="epi-adapters">${epiExternalAdapters()}</div>
          <div class="notice">外部服务不可达时会标记降级，不会中断其他工具；不会用本地结果冒充外部工具结果。</div>
        </section>
      </aside>
    </div>
    <section id="epiResult">${epiResult ? '' : `<div class="epi-empty-result"><div>⌬</div><b>等待一次来自项目数据的候选分析</b><p>先在数据中心完成序列与来源关联，再回到这里选择项目和记录。</p></div>`}</section>
    <section class="epi-panel">
      <div class="epi-panel-head"><div><span>HISTORY</span><h3>历史运行</h3></div><button class="secondary" onclick="epiGoPage('visualization')">查看可视化中心</button></div>
      <div class="epi-history-caption">每次运行保存固定输入、项目数据来源链、工具状态、初始权重与候选结果。</div>
      <div id="epiRunHistory"></div>
    </section>`;
  epiUpdateSeqCount();
  epiUpdateProvenance();
  epiRenderRunHistory();
  if (epiResult) epiRenderResult();
}
function epiGoPage(target) {
  page = target;
  document.querySelectorAll('nav a').forEach(x => x.classList.toggle('active', x.dataset.page === target));
  render();
}
function epiUpdateSeqCount() {
  const seq = (document.querySelector('#epiSeqInput')?.value || '').replace(/\s+/g, '');
  const el = document.querySelector('#epiSeqCount');
  if (el) el.textContent = seq.length + ' aa';
  const preview = document.querySelector('#epiSeqPreview');
  if (preview) preview.textContent = seq ? seq.replace(/(.{10})/g, '$1 ') : '请先从数据中心选择一条序列记录。';
  const protein = document.querySelector('#epiProteinName')?.value || '';
  const accession = document.querySelector('#epiAccession')?.value || '';
  const organism = document.querySelector('#epiOrganism')?.value || '';
  const setText = (id, text) => { const x = document.querySelector(id); if (x) x.textContent = text || '—'; };
  setText('#epiRecordProtein', protein || '未选择记录');
  setText('#epiRecordAccession', accession);
  setText('#epiRecordOrganism', organism);
}
function epiClearForm() {
  ['epiProteinName', 'epiAccession', 'epiSeqInput'].forEach(id => { const el = document.querySelector('#' + id); if (el) el.value = ''; });
  const org = document.querySelector('#epiOrganism'); if (org) org.value = 'Brucella abortus';
  epiUpdateSeqCount();
}
function epiLoadExample(index) {
  const item = epiMeta?.examples?.[index];
  if (!item) return;
  document.querySelector('#epiProteinName').value = item.name;
  document.querySelector('#epiAccession').value = item.accession;
  document.querySelector('#epiOrganism').value = item.organism;
  document.querySelector('#epiSeqInput').value = item.sequence;
  epiUpdateSeqCount();
  toast(item.note || '示例序列已载入');
  document.querySelector('#epiSeqInput')?.focus();
}
function epiReadFasta(input) {
  const file = input.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) return toast('FASTA 文件请小于 5 MB');
  const reader = new FileReader();
  reader.onload = () => {
    const lines = String(reader.result || '').split(/\r?\n/);
    const header = lines.find(x => x.trim().startsWith('>')) || '';
    const seq = lines.filter(x => !x.trim().startsWith('>')).join('').replace(/\s+/g, '').toUpperCase();
    if (!seq) return toast('未在文件中识别到序列');
    document.querySelector('#epiSeqInput').value = seq;
    if (header) document.querySelector('#epiProteinName').value = header.slice(1).trim().split('|').slice(-1)[0].slice(0, 80);
    epiUpdateSeqCount();
    toast('FASTA 已载入：' + seq.length + ' aa');
  };
  reader.readAsText(file, 'utf-8');
}
async function epiProjectChanged() {
  const projectId = epiProjectId();
  try {
    epiProteins = await api('/api/epitope/proteins?project_id=' + encodeURIComponent(projectId));
    epiRuns = await api('/api/epitope/runs?project_id=' + encodeURIComponent(projectId));
    const sel = document.querySelector('#epiSavedProtein');
    if (sel) sel.innerHTML = '<option value="">选择历史蛋白</option>' + epiProteins.map(p => `<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.accession || '无 Accession')}</option>`).join('');
    epiRenderRunHistory();
  } catch (e) { toast(e.message); }
}
function epiLoadSaved(id) {
  const p = epiProteins.find(x => x.id === id);
  if (!p) return;
  document.querySelector('#epiProteinName').value = p.name || '';
  document.querySelector('#epiAccession').value = p.accession || '';
  document.querySelector('#epiOrganism').value = p.organism || 'Brucella abortus';
  document.querySelector('#epiSeqInput').value = p.sequence || '';
  epiUpdateSeqCount();
  toast('已载入已保存蛋白');
}
function epiWeightInput(id, value) {
  epiWeights[id] = Number(value);
  const label = document.querySelector('#epiWeightLabel_' + id);
  if (label) label.textContent = value;
  epiRankingDirty = true;
  epiLocalRerank();
}
function epiApplyPreset(key) {
  const preset = epiMeta?.presets?.[key];
  if (!preset) return;
  epiWeights = {...preset.weights};
  Object.entries(epiWeights).forEach(([id, value]) => {
    const el = document.querySelector('#epiWeight_' + id);
    if (el) el.value = value;
    const label = document.querySelector('#epiWeightLabel_' + id);
    if (label) label.textContent = value;
  });
  epiRankingDirty = true;
  epiLocalRerank();
  toast('已应用「' + preset.name + '」权重');
}
function epiLocalRerank() {
  if (!epiResult || !epiResult.candidates) return;
  const total = Object.values(epiWeights).reduce((a, b) => a + Number(b || 0), 0);
  if (!total) return;
  epiResult.candidates.forEach(c => {
    const f = c.factors || {};
    c.score = Math.round(1000 * Object.entries(epiWeights).reduce((sum, [key, weight]) => sum + Number(f[key] || 0) * Number(weight || 0), 0) / total) / 10;
  });
  epiResult.candidates.sort((a, b) => (b.score - a.score) || (a.start - b.start));
  epiResult.candidates.forEach((c, i) => { c.rank = i + 1; });
  epiRankingDirty = true;
  epiRenderResult();
}
async function epiSaveRanking() {
  if (!epiResult) return;
  try {
    const result = await post('/api/epitope/runs/' + encodeURIComponent(epiResult.id) + '/rerank', {weights: epiWeights});
    epiResult.candidates = result.candidates;
    epiResult.weights = result.weights;
    epiSelected = new Set(result.candidates.filter(x => x.selected).map(x => x.id));
    epiRankingDirty = false;
    epiRenderResult();
    toast('本次排序已作为新版本保存');
  } catch (e) { toast(e.message); }
}
async function epiRunAnalysis() {
  const seq = document.querySelector('#epiSeqInput')?.value || '';
  if (seq.replace(/\s+/g, '').length < 20) return toast('请先从数据中心选择一条有效序列记录');
  const selectedTools = (epiMeta?.tools || []).filter(t => document.querySelector('#epiTool_' + t.id)?.checked).map(t => t.id);
  if (!selectedTools.length) return toast('至少选择一个可用工具');
  const projectId = epiProjectId();
  const recordId = document.querySelector('#epiRecordSelect')?.value || '';
  const sourceId = document.querySelector('#epiSourceSelect')?.value || '';
  if (!projectId) return toast('请先在项目管理中创建项目');
  if (!recordId) return toast('请先从数据中心选择一条序列记录');
  if (!sourceId) return toast('该数据集尚未关联来源，请先到证据中心或数据中心完成来源关联');
  const button = document.querySelector('#epiRunBtn');
  const hint = document.querySelector('#epiRunHint');
  const oldHint = hint?.textContent || '';
  if (button) { button.disabled = true; button.textContent = '正在运行本地与外部工具…'; }
  if (hint) hint.textContent = '工作流运行中：外部服务可能需要较长时间，失败工具会降级并保留其余结果';
  try {
    const result = await post('/api/epitope/analyze', {
      project_id: projectId,
      protein_name: document.querySelector('#epiProteinName')?.value.trim() || '',
      accession: document.querySelector('#epiAccession')?.value.trim() || '',
      organism: document.querySelector('#epiOrganism')?.value.trim() || 'Brucella spp.',
      sequence: seq,
      dataset_id: document.querySelector('#epiDatasetSelect')?.value || '',
      record_id: recordId,
      source_id: sourceId,
      tools: selectedTools,
      external_timeout_seconds: Number(document.querySelector('#epiExternalTimeout')?.value || 240),
      weights: epiWeights,
      simulate_failure: document.querySelector('#epiFailure')?.value || ''
    });
    epiResult = result;
    epiWeights = {...result.weights};
    epiSelected = new Set((result.candidates || []).filter(x => x.selected).map(x => x.id));
    epiRankingDirty = false;
    epiRuns.unshift({id: result.id, project_id: result.project_id, protein_name: result.protein_name, accession: result.accession, status: result.status, candidate_count: result.candidate_count, elapsed_ms: result.elapsed_ms, created_at: result.created_at, dataset_name: result.dataset_name, record_key: result.record_key, source_name: result.source_name, source_id: result.source_id, dataset_id: result.dataset_id, record_id: result.record_id});
    epiRenderRunHistory();
    epiRenderResult();
    const failed = (result.tool_logs || []).filter(x => x.status === 'FAILED').length;
    toast(failed ? `分析完成：${failed} 个工具已降级，其余结果可用` : '分析完成，候选已生成');
    setTimeout(() => document.querySelector('#epiResult')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 80);
  } catch (e) {
    toast(e.message);
  } finally {
    if (button) { button.disabled = false; button.textContent = '运行分析并生成候选'; }
    if (hint) hint.textContent = oldHint;
  }
}
function epiToggleCandidate(id, checked) {
  if (checked) epiSelected.add(id); else epiSelected.delete(id);
  const c = epiResult?.candidates?.find(x => x.id === id);
  if (c) c.selected = checked;
  epiUpdateSelectionCount();
}
function epiSelectTop(n) {
  if (!epiResult) return;
  epiSelected = new Set(epiResult.candidates.slice(0, n).map(x => x.id));
  epiRenderResult();
  toast('已选择排序前 ' + n + ' 条候选');
}
function epiClearSelection() {
  epiSelected.clear();
  epiRenderResult();
}
function epiUpdateSelectionCount() {
  const el = document.querySelector('#epiSelectionCount');
  if (el) el.textContent = epiSelected.size;
  const saveBtn = document.querySelector('#epiSaveSelectionBtn');
  if (saveBtn) saveBtn.disabled = epiSelected.size === 0;
  const expBtn = document.querySelector('#epiExportBtn');
  if (expBtn) expBtn.disabled = epiSelected.size === 0;
}
async function epiSaveSelection() {
  if (!epiResult || !epiSelected.size) return toast('请先勾选候选');
  try {
    await post('/api/epitope/select', {run_id: epiResult.id, candidate_ids: [...epiSelected]});
    toast('候选选择已保存到本次运行');
  } catch (e) { toast(e.message); }
}
async function epiExport(format) {
  if (!epiResult || !epiSelected.size) return toast('请先勾选要交接的候选');
  try {
    const result = await post('/api/epitope/export', {run_id: epiResult.id, candidate_ids: [...epiSelected], format});
    const link = document.createElement('a');
    link.href = result.download;
    link.download = result.filename || '';
    document.body.append(link);
    link.click();
    link.remove();
    toast('已生成 ' + format.toUpperCase() + ' 交接文件');
  } catch (e) { toast(e.message); }
}

function epiFactorBar(label, value, color) {
  const pct = Math.max(0, Math.min(100, Number(value || 0) * 100));
  return `<div class="epi-factor"><span>${esc(label)}</span><i><b style="width:${pct}%;background:${color}"></b></i><em>${pct.toFixed(0)}</em></div>`;
}
function epiRenderTrack(run) {
  const seq = run.sequence || '';
  const n = Math.max(1, seq.length);
  const lanes = (run.tool_logs || []).map((tool, i) => {
    const color = epiMeta?.tools?.find(x => x.id === tool.id)?.color || '#5773a5';
    const regions = (tool.regions || []).map(r => {
      const left = r.start / n * 100;
      const width = Math.max(0.35, (r.end - r.start) / n * 100);
      return `<span class="epi-region" style="left:${left}%;width:${width}%;background:${color}" title="${esc(tool.name)} ${r.start + 1}-${r.end}，相对分 ${Number(r.score).toFixed(2)}"></span>`;
    }).join('');
    return `<div class="epi-lane"><label>${esc(tool.name)}</label><div class="epi-lane-track">${regions}</div><small>${tool.status === 'FAILED' ? '降级' : (tool.regions || []).length + ' 区'}</small></div>`;
  }).join('');
  const top = (run.candidates || []).slice(0, 10).map(c => {
    const left = (c.start - 1) / n * 100;
    const width = Math.max(0.6, (c.end - c.start + 1) / n * 100);
    return `<button class="epi-candidate-band ${epiSelected.has(c.id) ? 'selected' : ''}" style="left:${left}%;width:${width}%" onclick="epiCandidateDetail('${esc(c.id)}')" title="#${c.rank} ${c.start}-${c.end} · ${Number(c.score).toFixed(1)} 分">#${c.rank}</button>`;
  }).join('');
  return `<div class="epi-track-wrap">
    <div class="epi-track-scale"><span>1</span><span>${Math.round(n * .25)}</span><span>${Math.round(n * .5)}</span><span>${Math.round(n * .75)}</span><span>${n}</span></div>
    <div class="epi-ruler"><i></i><i></i><i></i><i></i></div>
    ${lanes}
    <div class="epi-lane epi-candidate-lane"><label>共识候选</label><div class="epi-lane-track">${top}</div><small>Top 10</small></div>
    <div class="epi-track-legend">${(run.tool_logs || []).map(tool => { const meta = epiMeta?.tools?.find(x => x.id === tool.id); return `<span><i style="background:${meta?.color || '#6d7e99'}"></i>${esc(tool.name)}</span>`; }).join('')}<span><i class="candidate-dot"></i>可点击候选</span></div>
  </div>`;
}
function epiRenderToolCards(run) {
  return `<div class="epi-tool-results">${(run.tool_logs || []).map(tool => `
    <div class="epi-tool-result ${tool.status === 'FAILED' ? 'failed' : ''}">
      <div><span class="epi-tool-dot" style="--tool-color:${epiMeta?.tools?.find(x => x.id === tool.id)?.color || '#6d7e99'}"></span><b>${esc(tool.name)}</b>${epiToolStatus(tool.status)}</div>
      <p>${tool.status === 'FAILED' ? esc(tool.error || '适配器异常') : `${(tool.regions || []).length} 个候选区域 · ${Number(tool.duration_ms).toFixed(1)} ms`}</p>
      <small>${esc((tool.warnings || []).join('；'))}</small>
    </div>`).join('')}</div>`;
}
function epiWeightSummary() {
  return (epiMeta?.dimensions || []).map(d => `<span style="--dim-color:${d.color}">${esc(d.name)} <b>${Number(epiWeights[d.id] || 0)}</b></span>`).join('');
}
function epiCandidateRows() {
  return (epiResult?.candidates || []).map(c => {
    const support = (c.support_tools || []).map(name => epiPill(name, 'tool')).join('') || epiPill('无工具支持', 'red');
    return `<tr data-candidate-id="${esc(c.id)}" data-search="${esc((c.sequence + ' ' + c.id + ' ' + c.start + ' ' + c.end + ' ' + (c.support_tools || []).join(' ')).toLowerCase())}" data-coverage="${Number(c.support_count)}">
      <td><input type="checkbox" class="epi-check" ${epiSelected.has(c.id) ? 'checked' : ''} onchange="epiToggleCandidate('${esc(c.id)}', this.checked)"></td>
      <td><span class="epi-rank">#${c.rank}</span></td>
      <td><b>${c.start}–${c.end}</b><small>${c.length} aa</small></td>
      <td><code>${esc(c.sequence)}</code></td>
      <td><div class="epi-score"><b>${Number(c.score).toFixed(1)}</b><i><span style="width:${Number(c.score)}%"></span></i></div></td>
      <td><b>${c.support_count}/${c.total_tools}</b><small>${epiPct(c.coverage * 100)}</small></td>
      <td><div class="epi-mini-factors">${epiFactorBar('强度', c.strength, '#13a38b')}${epiFactorBar('一致性', c.consistency, '#b86bd9')}</div></td>
      <td><div class="epi-support-chips">${support}</div></td>
      <td><button class="epi-rowbtn" onclick="epiCandidateDetail('${esc(c.id)}')">详情</button></td>
    </tr>`;
  }).join('');
}
function epiRenderCandidatePanel() {
  return `<section class="epi-panel epi-candidates">
    <div class="epi-panel-head"><div><span>STEP 03</span><h3>候选优先级与证据交接</h3></div><div class="epi-selection-actions"><span>已选 <b id="epiSelectionCount">${epiSelected.size}</b> 条</span><button class="secondary" onclick="epiSelectTop(10)">选择前 10</button><button class="secondary" onclick="epiClearSelection()">清空</button><button id="epiSaveSelectionBtn" onclick="epiSaveSelection()" ${epiSelected.size ? '' : 'disabled'}>保存选择</button><button id="epiExportBtn" onclick="epiExport('csv')" ${epiSelected.size ? '' : 'disabled'}>导出 CSV</button></div></div>
    <div class="epi-table-tools">
      <div class="epi-search"><input id="epiCandidateSearch" placeholder="筛选序列、位置或支持工具" oninput="epiApplyCandidateFilter()"><span>支持按位置、覆盖与得分筛选</span></div>
      <select id="epiCoverageFilter" onchange="epiApplyCandidateFilter()"><option value="0">全部覆盖</option><option value="2">≥ 2 个工具</option><option value="3">≥ 3 个工具</option><option value="4">≥ 4 个工具</option></select>
      <select id="epiSortMode" onchange="epiSortCandidates(this.value)"><option value="score">按共识分排序</option><option value="position">按序列位置排序</option><option value="coverage">按工具覆盖排序</option></select>
    </div>
    <div class="tablewrap epi-tablewrap"><table class="epi-candidate-table"><thead><tr><th></th><th>排序</th><th>位置</th><th>候选序列</th><th>共识分</th><th>工具覆盖</th><th>证据因子</th><th>支持工具</th><th>操作</th></tr></thead><tbody>${epiCandidateRows()}</tbody></table></div>
    <div class="epi-export-row"><div><b>交接文件</b><span>导出内容包含当前排序、权重、候选序列、位置和支持工具。</span></div><button class="secondary" onclick="epiExport('fasta')">导出 FASTA</button><button class="secondary" onclick="epiExport('json')">导出 JSON</button><button onclick="epiExport('pdf')">生成中文决策报告 PDF</button></div>
  </section>`;
}
function epiRenderResult() {
  if (!epiResult) return;
  const run = epiResult;
  const top = run.candidates?.[0];
  const bestCoverage = Math.max(0, ...(run.candidates || []).map(x => x.support_count));
  const successTools = (run.tool_logs || []).filter(x => x.status === 'SUCCESS').length;
  const target = document.querySelector('#epiResult');
  if (!target) return;
  target.innerHTML = `
    <section class="epi-run-summary">
      <div class="epi-run-title"><div><span>RUN / ${esc(run.id)}</span><h3>${esc(run.protein_name)}</h3><p>${esc(run.organism || '物种未填写')} · ${esc(run.accession || '无 Accession')} · ${run.sequence.length} aa · ${run.created_at || ''}</p><p class="epi-run-provenance"><b>项目</b> ${esc(projects.find(p=>p.id===run.project_id)?.name || run.project_id)} <i>→</i> <b>数据集</b> ${esc(run.dataset_name || '未关联')} <i>→</i> <b>记录</b> ${esc(run.record_key || '未关联')} <i>→</i> <b>来源</b> ${esc(run.source_name || '未关联')}${run.output_evidence_id ? ` <span class="link" onclick="epiOpenEvidenceCenter('${esc(run.output_evidence_id)}')">查看证据中心记录</span>` : ''}</p></div><div>${epiRunStatus(run.status)}${epiRankingDirty ? epiPill('权重已变化，尚未保存', 'orange') : epiPill('排序已归档', 'green')}<button class="secondary" onclick="epiSaveRanking()">保存本次排序</button></div></div>
      <div class="epi-kpis">
        <div><span>候选区域</span><b>${run.candidate_count || run.candidates.length}</b><small>最多 24 aa/候选</small></div>
        <div><span>最高共识分</span><b>${top ? Number(top.score).toFixed(1) : '—'}</b><small>当前权重版本</small></div>
        <div><span>最高覆盖</span><b>${bestCoverage}/${(run.tool_logs || []).length}</b><small>跨工具重叠</small></div>
        <div><span>成功工具</span><b>${successTools}/${(run.tool_logs || []).length}</b><small>${run.elapsed_ms || 0} ms</small></div>
      </div>
    </section>
    <div class="epi-result-grid">
      ${panel('工具编排与容错状态', epiRenderToolCards(run), '')}
      ${panel('当前权重版本', `<div class="epi-weight-summary">${epiWeightSummary()}</div><div class="notice">权重改变后页面会立即重排；点击“保存本次排序”才会把当前权重和排序写入新的不可变版本。</div>`, '')}
    </div>
    ${panel('序列证据轨道', epiRenderTrack(run), '<span class="epi-panel-note">颜色 = 工具；条带 = 预测区域；编号 = 共识候选</span>')}
    <div id="epiCandidatePanel">${epiRenderCandidatePanel()}</div>`;
  epiUpdateSelectionCount();
}
function epiApplyCandidateFilter() {
  const term = (document.querySelector('#epiCandidateSearch')?.value || '').toLowerCase().trim();
  const minCoverage = Number(document.querySelector('#epiCoverageFilter')?.value || 0);
  document.querySelectorAll('.epi-candidate-table tbody tr').forEach(row => {
    const matchesText = !term || (row.dataset.search || '').includes(term);
    const matchesCoverage = Number(row.dataset.coverage || 0) >= minCoverage;
    row.hidden = !(matchesText && matchesCoverage);
  });
}
function epiSortCandidates(mode) {
  if (!epiResult) return;
  if (mode === 'position') epiResult.candidates.sort((a, b) => a.start - b.start);
  else if (mode === 'coverage') epiResult.candidates.sort((a, b) => (b.support_count - a.support_count) || (b.score - a.score));
  else epiResult.candidates.sort((a, b) => (b.score - a.score) || (a.start - b.start));
  epiResult.candidates.forEach((c, i) => { c.rank = i + 1; });
  epiRenderResult();
  const sel = document.querySelector('#epiSortMode'); if (sel) sel.value = mode;
  document.querySelector('#epiCandidatePanel')?.scrollIntoView({behavior: 'smooth', block: 'start'});
}
function epiCopyText(text) {
  if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(() => toast('已复制到剪贴板')).catch(() => toast('复制失败'));
  else toast('当前浏览器不支持一键复制');
}
function epiCandidateDetail(id) {
  const c = epiResult?.candidates?.find(x => x.id === id);
  if (!c) return;
  const evidence = (c.evidence_items || []).map(e => `<div class="epi-evidence-item"><div><b>${esc(e.title)}</b>${epiPill(e.level, 'orange')}</div><p>${esc(e.relation)} · 置信度 ${Number(e.confidence).toFixed(2)}</p>${e.url ? `<a href="${esc(e.url)}" target="_blank" rel="noopener">查看公开来源</a>` : ''}</div>`).join('') || '<div class="epi-no-evidence">证据中心没有匹配该蛋白或表位序列的线索。</div>';
  const tools = Object.entries(c.tool_scores || {}).map(([tid, v]) => `<div class="epi-tool-score"><span style="background:${v.color}"></span><b>${esc(v.name)}</b><i><em style="width:${Number(v.score) * 100}%"></em></i><small>${Number(v.score).toFixed(3)}</small></div>`).join('') || '<p class="muted">没有工具支持。</p>';
  modal(`候选 #${c.rank} · ${c.start}–${c.end}`, `
    <div class="epi-detail-score"><div><span>共识分</span><b>${Number(c.score).toFixed(2)}</b></div><div><span>工具覆盖</span><b>${c.support_count}/${c.total_tools}</b></div><div><span>长度</span><b>${c.length} aa</b></div><div><span>运行</span><b>${esc(epiResult.id)}</b></div></div>
    <div class="epi-peptide"><code>${esc(c.sequence)}</code><button class="epi-rowbtn" onclick="epiCopyText('${esc(c.sequence)}')">复制序列</button></div>
    <div class="epi-detail-grid">
      <div class="epi-detail-block"><h4>评分因子</h4><div class="epi-factor-detail">${epiMeta.dimensions.map(d => epiFactorBar(d.name, c.factors?.[d.id], d.color)).join('')}</div><p class="muted">${esc(c.note || '')}</p></div>
      <div class="epi-detail-block"><h4>支持工具与得分</h4><div class="epi-tool-scores">${tools}</div></div>
    </div>
    <div class="epi-detail-block"><h4>证据中心匹配证据</h4><div class="epi-evidence-list">${evidence}</div></div>
    <div class="notice warn">候选分只表示当前证据与权重下的相对优先级，不表示表位已被实验验证。</div>
  `, async () => {
    if (epiSelected.has(c.id)) epiSelected.delete(c.id); else epiSelected.add(c.id);
    epiRenderResult();
  }, epiSelected.has(c.id) ? '取消选择该候选' : '选择该候选');
  document.querySelector('.modalbox')?.classList.add('wide');
}

function epiRenderEvidenceTable(data) {
  const target = document.querySelector('#epiEvidenceTable');
  if (!target) return;
  const rows = (data || []).map(e => `<tr>
    <td><b>${esc(e.title)}</b><small>${esc(e.evidence_type || '')} · ${esc(e.source_name || e.source || '未关联来源')}${e.pmid ? ' · PMID ' + esc(e.pmid) : ''}</small></td>
    <td><code>${esc(e.protein_pattern || '—')}</code></td>
    <td>${esc(e.relation || '—')}</td>
    <td><span class="epi-confidence">${Number(e.confidence || 0).toFixed(2)}</span><i><b style="width:${Number(e.confidence || 0) * 100}%"></b></i></td>
    <td>${e.linked_evidence_id ? `<span class="link" onclick="epiOpenEvidenceCenter('${esc(e.linked_evidence_id)}')">证据中心</span>` : ''}${e.linked_evidence_id && e.url ? '　' : ''}${e.url ? `<a href="${esc(e.url)}" target="_blank" rel="noopener">公开原文</a>` : (e.linked_evidence_id ? '' : '—')}</td>
  </tr>`).join('');
  target.innerHTML = `<div class="tablewrap epi-evidence-table"><table><thead><tr><th>证据</th><th>蛋白匹配模式</th><th>关系</th><th>置信度</th><th>关联</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="empty">证据库暂无匹配记录</td></tr>'}</tbody></table></div>`;
}
function epiFilterEvidence(term) {
  const q = String(term || '').toLowerCase().trim();
  const list = q ? epiEvidence.filter(e => JSON.stringify(e).toLowerCase().includes(q)) : epiEvidence;
  epiRenderEvidenceTable(list);
  const label = document.querySelector('#epiEvidenceSearch')?.nextElementSibling;
  if (label) label.textContent = list.length + ' 条';
}
function epiEvidenceForm() {
  modal('登记公开证据', `
    <div class="epi-form-grid">
      <div class="field"><label>证据标题 *</label><input name="title" placeholder="论文标题、数据库记录或方法学来源"></div>
      <div class="field"><label>证据类型</label><select name="evidence_type"><option>诊断抗原研究</option><option>疫苗免疫原性研究</option><option>表位实验研究</option><option>方法学来源</option><option>公开数据库</option></select></div>
    </div>
    <div class="epi-form-grid">
      <div class="field"><label>蛋白匹配模式</label><input name="protein_pattern" placeholder="例如 BP26|Q6YA76；可留空"></div>
      <div class="field"><label>与候选的关系</label><input name="relation" placeholder="例如 支持蛋白层面的免疫原性"></div>
    </div>
    <div class="epi-form-grid three">
      <div class="field"><label>关联证据中心来源</label><select name="source_id"><option value="">不关联来源</option>${(sources||[]).map(s=>`<option value="${esc(s.id)}">${esc(s.name)} · ${esc(s.source_type||"")}</option>`).join("")}</select></div>
      <div class="field"><label>PMID</label><input name="pmid" placeholder="可选"></div>
      <div class="field"><label>置信度 0–1</label><input name="confidence" type="number" min="0" max="1" step="0.01" value="0.60"></div>
    </div>
    <div class="field"><label>公开链接</label><input name="url" placeholder="https://..."></div>
    <div class="field"><label>证据摘要与局限性</label><textarea name="summary" placeholder="说明该证据支持到什么层级：蛋白级、表位级还是仅方法学参考"></textarea></div>
    <div class="notice">登记的是“证据线索”，不是系统自动生成的新实验结论。蛋白级证据不应该被解释为某条线性表位已验证。</div>
  `, async m => {
    const title = val(m, 'title').trim();
    if (!title) throw Error('证据标题不能为空');
    await post('/api/epitope/evidence', {
      title, evidence_type: val(m, 'evidence_type'), protein_pattern: val(m, 'protein_pattern'),
      relation: val(m, 'relation'), source_id: val(m, 'source_id'), pmid: val(m, 'pmid'),
      confidence: Number(val(m, 'confidence') || 0.6), url: val(m, 'url'), summary: val(m, 'summary')
    });
    epiEvidence = await api('/api/epitope/evidence');
    epiRenderEvidenceTable(epiEvidence);
    toast('公开证据已登记');
  });
}
function epiRenderRunHistory() {
  const target = document.querySelector('#epiRunHistory');
  if (!target) return;
  const rows = (epiRuns || []).slice(0, 12).map(r => `<tr class="${epiResult?.id === r.id ? 'epi-current-run' : ''}">
    <td><b>${esc(r.protein_name)}</b><small>${esc(r.accession || '无 Accession')} · ${esc(r.created_at)}</small></td>
    <td><small>${esc(r.dataset_name || '未关联')}${r.record_key ? ' / ' + esc(r.record_key) : ''}${r.source_name ? ' · ' + esc(r.source_name) : ''}</small></td>
    <td>${epiRunStatus(r.status)}</td>
    <td>${r.candidate_count || 0}</td>
    <td>${Number(r.elapsed_ms || 0).toFixed(1)} ms</td>
    <td><button class="epi-rowbtn" onclick="epiLoadRun('${esc(r.id)}')">打开</button></td>
  </tr>`).join('');
  target.innerHTML = `<div class="tablewrap epi-history-table"><table><thead><tr><th>运行 / 蛋白</th><th>数据来源链</th><th>状态</th><th>候选</th><th>耗时</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="empty">尚无分析运行</td></tr>'}</tbody></table></div>`;
}
async function epiLoadRun(id) {
  try {
    epiResult = await api('/api/epitope/runs/' + encodeURIComponent(id));
    epiWeights = {...epiResult.weights};
    epiSelected = new Set(epiResult.candidates.filter(x => x.selected).map(x => x.id));
    epiRankingDirty = false;
    epiRenderResult();
    epiRenderRunHistory();
    setTimeout(() => document.querySelector('#epiResult')?.scrollIntoView({behavior: 'smooth', block: 'start'}), 50);
    toast('已打开运行 ' + id);
  } catch (e) { toast(e.message); }
}

function epiGo() {
  page = 'epitope';
  document.querySelectorAll('nav a').forEach(x => x.classList.toggle('active', x.dataset.page === 'epitope'));
  render();
}
function epiInjectDashboard(attempt = 0) {
  const content = document.querySelector('#content');
  if (!content || content.querySelector('.epi-dash-banner')) return;
  if (!content.querySelector('.stats') && attempt < 12) {
    setTimeout(() => epiInjectDashboard(attempt + 1), 80);
    return;
  }
  const html = `<section class="epi-dash-banner"><div><span class="epi-eyebrow">核心科研场景</span><h3>布病多表位抗原计算筛选与优先级工作台</h3><p>不预测“哪个蛋白一定是抗原”，而是帮助实验人员决定：当多个证据源给出不同区域时，优先合成哪几条候选。</p></div><div><button onclick="epiGo()">进入抗原决策台</button><a onclick="epiGoPage('datasets')">前往数据中心 →</a></div></section>`;
  content.insertAdjacentHTML('afterbegin', html);
}

const epiOriginalRender = render;
render = function() {
  if (typeof page !== 'undefined' && page === 'epitope') {
    epiShowWorkbench();
    return;
  }
  epiOriginalRender();
  if (typeof page !== 'undefined' && page === 'dashboard') epiInjectDashboard();
};






// 3.1 数据来源关联与跨中心跳转
function epiClearAssociations() {
  epiRecordCache = [];
  const ds = document.querySelector('#epiDatasetSelect'); if (ds) ds.value = '';
  const rec = document.querySelector('#epiRecordSelect'); if (rec) rec.innerHTML = '<option value="">选择记录</option>';
  const src = document.querySelector('#epiSourceSelect'); if (src) src.value = '';
  epiUpdateProvenance();
}
function epiClearForm() {
  ['epiProteinName', 'epiAccession', 'epiSeqInput'].forEach(id => { const el = document.querySelector('#' + id); if (el) el.value = ''; });
  const org = document.querySelector('#epiOrganism'); if (org) org.value = 'Brucella abortus';
  epiClearAssociations();
  epiUpdateSeqCount();
}
function epiLoadExample(index) {
  const item = epiMeta?.examples?.[index];
  if (!item) return;
  epiClearAssociations();
  document.querySelector('#epiProteinName').value = item.name;
  document.querySelector('#epiAccession').value = item.accession;
  document.querySelector('#epiOrganism').value = item.organism;
  document.querySelector('#epiSeqInput').value = item.sequence;
  epiUpdateSeqCount();
  epiUpdateProvenance();
  toast(item.note || '示例序列已载入');
  document.querySelector('#epiSeqInput')?.focus();
}
function epiReadFasta(input) {
  const file = input.files?.[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) return toast('FASTA 文件请小于 5 MB');
  const reader = new FileReader();
  reader.onload = () => {
    const lines = String(reader.result || '').split(/\r?\n/);
    const header = lines.find(x => x.trim().startsWith('>')) || '';
    const seq = lines.filter(x => !x.trim().startsWith('>')).join('').replace(/\s+/g, '').toUpperCase();
    if (!seq) return toast('未在文件中识别到序列');
    epiClearAssociations();
    document.querySelector('#epiSeqInput').value = seq;
    if (header) document.querySelector('#epiProteinName').value = header.slice(1).trim().split('|').slice(-1)[0].slice(0, 80);
    epiUpdateSeqCount();
    epiUpdateProvenance();
    toast('FASTA 已载入：' + seq.length + ' aa');
  };
  reader.readAsText(file, 'utf-8');
}
async function epiProjectChanged() {
  const projectId = epiProjectId();
  try {
    epiProteins = await api('/api/epitope/proteins?project_id=' + encodeURIComponent(projectId));
    epiRuns = await api('/api/epitope/runs?project_id=' + encodeURIComponent(projectId));
    const sel = document.querySelector('#epiSavedProtein');
    if (sel) sel.innerHTML = '<option value="">选择历史蛋白</option>' + epiProteins.map(p => `<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.accession || '无 Accession')}</option>`).join('');
    const ds = document.querySelector('#epiDatasetSelect');
    if (ds) ds.innerHTML = epiDatasetOptions();
    epiRecordCache = [];
    const rec = document.querySelector('#epiRecordSelect'); if (rec) rec.innerHTML = '<option value="">选择记录</option>';
    const src = document.querySelector('#epiSourceSelect'); if (src) src.innerHTML = epiSourceOptions();
    epiRenderRunHistory();
    epiUpdateProvenance();
  } catch (e) { toast(e.message); }
}
async function epiLoadSaved(id) {
  const p = epiProteins.find(x => x.id === id);
  if (!p) return;
  document.querySelector('#epiProteinName').value = p.name || '';
  document.querySelector('#epiAccession').value = p.accession || '';
  document.querySelector('#epiOrganism').value = p.organism || 'Brucella abortus';
  document.querySelector('#epiSeqInput').value = p.sequence || '';
  const ds = document.querySelector('#epiDatasetSelect'); if (ds) ds.value = p.dataset_id || '';
  if (p.dataset_id) await epiLoadDatasetRecords();
  const rec = document.querySelector('#epiRecordSelect'); if (rec) rec.value = p.record_id || '';
  const src = document.querySelector('#epiSourceSelect'); if (src) src.value = p.source_id || '';
  epiUpdateSeqCount();
  epiUpdateProvenance();
  toast('已载入已保存蛋白及其数据来源链');
}
async function epiOpenRunFromDashboard(id) {
  page = 'epitope';
  document.querySelectorAll('nav a').forEach(x => x.classList.toggle('active', x.dataset.page === 'epitope'));
  await epiShowWorkbench();
  await epiLoadRun(id);
}


// 3.1 可视化中心：以抗原决策输出为主视图
function epiVisBars(data) {
  if (!data || !data.length) return '<div class="empty">暂无数据</div>';
  const max = Math.max(1, ...data.map(x => Number(x.count || 0)));
  return `<div class="chartbars epi-vis-bars">${data.map(x => `<div class="barcol"><div class="bar" style="height:${Math.max(4, Number(x.count || 0) / max * 140)}px"></div><b>${x.count || 0}</b><span>${esc(x.name ?? x.status ?? '')}</span></div>`).join('')}</div>`;
}
window.showVisualization = async function () {
  title('可视化中心');
  const content = document.querySelector('#content');
  content.innerHTML = '<div class="epi-loading"><span></span>正在汇总抗原决策结果……</div>';
  try {
    const projectId = document.querySelector('#epiVisProject')?.value || '';
    const d = await api('/api/epitope/visualization/summary' + (projectId ? '?project_id=' + encodeURIComponent(projectId) : ''));
    const k = d.kpis || {};
    const projectOptions = '<option value="">全部项目</option>' + projects.map(p => `<option value="${esc(p.id)}" ${projectId === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    const candidateRows = (d.top_candidates || []).map(c => `<tr>
      <td><b>#${c.rank}</b> ${esc(c.protein_name)}<small>${c.start_pos}–${c.end_pos} · ${esc(c.sequence)}</small></td>
      <td><b>${Number(c.score).toFixed(1)}</b></td>
      <td>${c.support_count}/${c.total_tools}</td>
      <td>${(c.support_tools || []).map(x => epiPill(x, 'tool')).join('')}</td>
      <td>${c.selected ? epiPill('已选择', 'green') : epiPill('未选择', 'gray')}</td>
      <td><button class="epi-rowbtn" onclick="epiVisCandidate('${esc(c.run_id)}','${esc(c.id)}')">查看详情</button></td>
    </tr>`).join('');
    const runRows = (d.runs || []).slice(0, 12).map(r => `<tr>
      <td><b>${esc(r.protein_name)}</b><small>${esc(r.accession || '无 Accession')} · ${esc(r.created_at)}</small></td>
      <td>${esc(r.dataset_name || '未关联')}${r.record_key ? ' / ' + esc(r.record_key) : ''}${r.source_name ? ' · ' + esc(r.source_name) : ''}</td>
      <td>${epiRunStatus(r.status)}</td>
      <td>${r.candidate_count || 0}</td>
      <td><button class="epi-rowbtn" onclick="epiOpenRunFromDashboard('${esc(r.id)}')">打开运行</button></td>
    </tr>`).join('');
    content.innerHTML = `
      <section class="epi-hero epi-vis-hero"><div><span class="epi-eyebrow">ANTIGEN DECISION INTELLIGENCE</span><h3>抗原决策结果总览</h3><p>集中展示候选蛋白、工具覆盖、共识分数、数据来源链和证据中心输出。</p></div><div class="epi-hero-actions"><select id="epiVisProject" onchange="showVisualization()" class="epi-vis-select">${projectOptions}</select><button onclick="epiGo()">进入抗原决策台</button></div></section>
      <div class="grid stats epi-vis-kpis">
        <div class="stat"><div class="label">抗原运行</div><strong>${k.runs || 0}</strong><small>固定输入与工具状态</small></div>
        <div class="stat"><div class="label">候选蛋白</div><strong>${k.proteins || 0}</strong><small>已进入决策流程</small></div>
        <div class="stat"><div class="label">候选区域</div><strong>${k.candidates || 0}</strong><small>可排序、可追溯</small></div>
        <div class="stat"><div class="label">已选候选</div><strong>${k.selected || 0}</strong><small>待交接与合成</small></div>
        <div class="stat"><div class="label">最高共识分</div><strong>${Number(k.top_score || 0).toFixed(1)}</strong><small>当前项目范围</small></div>
        <div class="stat"><div class="label">证据线索</div><strong>${k.evidence || 0}</strong><small>证据库线索</small></div>
      </div>
      <div class="grid split">
        ${panel('候选分数分布', epiVisBars(d.score_counts))}
        ${panel('工具覆盖分布', epiVisBars(d.coverage_counts))}
      </div>
      <div class="grid split">
        ${panel('运行状态', epiVisBars(d.status_counts))}
        ${panel('数据来源分布', epiVisBars(d.source_counts))}
      </div>
      ${panel('候选优先级 Top 20', `<div class="tablewrap epi-vis-table"><table><thead><tr><th>候选</th><th>共识分</th><th>覆盖</th><th>支持工具</th><th>状态</th><th>操作</th></tr></thead><tbody>${candidateRows || '<tr><td colspan="6" class="empty">暂无候选结果</td></tr>'}</tbody></table></div>`)}
      ${panel('抗原运行与数据来源链', `<div class="tablewrap epi-vis-table"><table><thead><tr><th>运行 / 蛋白</th><th>项目 → 数据集 → 记录 → 来源</th><th>状态</th><th>候选</th><th></th></tr></thead><tbody>${runRows || '<tr><td colspan="5" class="empty">暂无运行记录</td></tr>'}</tbody></table></div>`)}
      <div class="notice">可视化数据全部来自抗原决策台的持久化结果，并由项目、数据集、记录和来源关联形成追溯链。</div>`;
  } catch (e) {
    content.innerHTML = `<div class="notice warn">可视化加载失败：${esc(e.message)}</div>`;
  }
};
async function epiVisCandidate(runId, candidateId) {
  try {
    epiResult = await api('/api/epitope/runs/' + encodeURIComponent(runId));
    epiWeights = {...epiResult.weights};
    epiSelected = new Set((epiResult.candidates || []).filter(x => x.selected).map(x => x.id));
    epiCandidateDetail(candidateId);
  } catch (e) { toast(e.message); }
}
async function epiOpenEvidenceCenter(evidenceId) {
  page = 'evidence';
  document.querySelectorAll('nav a').forEach(x => x.classList.toggle('active', x.dataset.page === 'evidence'));
  evidence = await api('/api/evidence');
  sources = await api('/api/sources');
  await showEvidence();
  if (evidenceId && typeof evidenceVersions === 'function') {
    try { await evidenceVersions(evidenceId); } catch (e) {}
  }
}

// 3.1 报告中心：自动纳入抗原决策结果
async function epiLoadReportRuns() {
  const projectId = document.querySelector('#reportProject')?.value || projects[0]?.id || '';
  return projectId ? api('/api/epitope/runs?project_id=' + encodeURIComponent(projectId)) : api('/api/epitope/runs');
}
window.showReports = async function () {
  title('报告中心');
  const [reports, templates] = await Promise.all([api('/api/reports'), api('/api/report-templates')]);
  window.reports = reports; window.templates = templates;
  const projectId = document.querySelector('#reportProject')?.value || projects[0]?.id || '';
  const runs = projectId ? await api('/api/epitope/runs?project_id=' + encodeURIComponent(projectId)) : [];
  const projectOptions = projects.map(p => `<option value="${esc(p.id)}" ${projectId === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
  const templateOptions = templates.map(t => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('');
  document.querySelector('#content').innerHTML = `
    <section class="epi-hero epi-report-hero"><div><span class="epi-eyebrow">DECISION REPORTING</span><h3>抗原候选决策报告</h3><p>报告自动汇总抗原运行、工具状态、候选结果、排序版本、数据来源链和证据线索，并附科学边界声明。</p></div><div class="epi-hero-actions"><button onclick="epiMakeReport()">生成当前项目报告</button></div></section>
    <div class="epi-panel">
      <div class="epi-panel-head"><div><span>REPORT BUILDER</span><h3>报告生成参数</h3></div><div class="epi-inline-badges"><span>含抗原运行</span><span>含候选与排序版本</span><span>中文 PDF</span></div></div>
      <div class="epi-report-controls">
        <div class="field"><label>项目</label><select id="reportProject" onchange="epiReportProjectChanged()">${projectOptions || '<option value="">暂无项目</option>'}</select></div>
        <div class="field"><label>格式</label><select id="reportFormat"><option value="pdf">中文决策报告 PDF</option><option value="html">网页 HTML</option><option value="json">完整结构化 JSON</option><option value="csv">章节摘要 CSV</option></select></div>
        <div class="field"><label>章节模板</label><select id="reportTemplate"><option value="">默认：包含全部抗原决策输出</option>${templateOptions}</select></div>
        <div class="field epi-report-generate"><label>&nbsp;</label><button onclick="epiMakeReport()">生成并下载报告</button></div>
      </div>
      <div class="notice">默认报告章节包含：项目基本信息、数据集与来源、抗原运行记录、抗原候选结果、抗原排序版本、抗原证据线索、数据质量、关联证据和局限性声明。</div>
    </div>
    <div class="grid split">
      ${panel('即将纳入报告的抗原运行', `<div class="tablewrap epi-report-runs"><table><thead><tr><th>蛋白</th><th>数据来源链</th><th>状态</th><th>候选</th></tr></thead><tbody>${runs.slice(0,12).map(r=>`<tr><td><b>${esc(r.protein_name)}</b><small>${esc(r.accession||'无 Accession')}</small></td><td>${esc(r.dataset_name||'未关联')}${r.record_key?' / '+esc(r.record_key):''}${r.source_name?' · '+esc(r.source_name):''}</td><td>${epiRunStatus(r.status)}</td><td>${r.candidate_count||0}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">当前项目暂无抗原运行</td></tr>'}</tbody></table></div>`, btn('＋ 新建报告模板','epiReportTemplateForm()','secondary'))}
      ${panel('历史报告', `<div class="tablewrap epi-report-history"><table><thead><tr><th>报告</th><th>格式</th><th>时间</th><th></th></tr></thead><tbody>${reports.map(r=>`<tr><td><b>${esc(r.name)}</b><small>${esc(r.path)}</small></td><td>${esc(String(r.format).toUpperCase())}</td><td>${esc(r.created_at)}</td><td><a href="/download/${encodeURIComponent(r.path.split(/[\\\\/]/).pop())}">下载</a></td></tr>`).join('') || '<tr><td colspan="4" class="empty">尚无报告</td></tr>'}</tbody></table></div>`)}
    </div>`;
};
window.epiReportProjectChanged = async function () {
  await showReports();
};
window.epiMakeReport = async function () {
  const projectId = document.querySelector('#reportProject')?.value;
  if (!projectId) return toast('请先创建或选择项目');
  try {
    const r = await post('/api/reports', {project_id: projectId, format: document.querySelector('#reportFormat')?.value || 'pdf', template_id: document.querySelector('#reportTemplate')?.value || ''});
    const a = document.createElement('a'); a.href = r.download; document.body.append(a); a.click(); a.remove();
    toast('报告已生成，包含抗原决策结果');
    await showReports();
  } catch (e) { toast(e.message); }
};
window.epiReportTemplateForm = function () {
  modal('新建抗原决策报告模板', field('模板名称','name','例如：项目抗原决策报告') + field('模板说明','description','说明该模板适用的阶段') + `<div class="field"><label>报告章节（每行一项）</label><textarea name="sections" rows="13">项目基本信息
数据集信息
数据来源
抗原运行记录
抗原候选结果
抗原排序版本
抗原证据线索
关联证据
数据质量与异常记录
人工复核
报告历史
局限性声明</textarea></div>`, async m => {
    const name = val(m,'name').trim();
    if(!name) throw Error('模板名称不能为空');
    const sections = val(m,'sections').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    await post('/api/report-templates',{name,description:val(m,'description'),sections});
    toast('报告模板已保存');
    await showReports();
  });
};

















