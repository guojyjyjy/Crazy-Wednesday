// 2.1 体验增强：导入说明、记录关联检索、任务输出、分析汇总和快照摘要。
const v21BaseShowDatasets = window.showDatasets;
const v21BaseShowReports = window.showReports;
const v21BaseShowSettings = window.showSettings;

function v21DownloadJSON(filename, obj) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], {type: 'application/json;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function v21DownloadCSVTemplate() {
  const csv = '\ufeff记录编号,名称,序列/内容,来源,备注\n示例-001,示例记录,请输入该记录的主要内容,示例来源,可留空\n';
  const blob = new Blob([csv], {type: 'text/csv;charset=utf-8'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = '科研数据导入模板.csv';
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function v21ImportGuide() {
  modal('表格导入要求', `<div class="v21-guide">
    <div><b>支持格式</b><p>CSV、TSV、JSON、XLSX、FASTA。XLSX 读取第一张工作表；CSV/TSV 使用 UTF-8。</p></div>
    <div><b>表头</b><p>第一行填写唯一字段名。IEDB 那种“两行表头”的导出表会自动合并两行字段名。</p></div>
    <div><b>记录标识</b><p>建议包含“记录编号 / ID / Epitope ID / IEDB IRI / Accession”之一；没有时系统会用行号生成稳定标识。</p></div>
    <div><b>空单元格</b><p>允许为空，只显示“空字段提示”，不会再把整条记录判为异常。只有整行为空、标识重复或内容为空才是异常。</p></div>
    <div><b>证据关联</b><p>关联记录时可以选择该项目中的任意一条记录。3000 条数据就对应 3000 个候选记录，这是正常的，用数据集筛选和关键词搜索定位即可。</p></div>
  </div>`, async () => {}, '知道了');
  document.querySelector('.modalbox').classList.add('wide');
}
window.showDatasets = function () {
  v21BaseShowDatasets();
  const notice = document.querySelector('#content .notice');
  if (notice) notice.innerHTML = '数据管理采用真实本地数据库和文件存储。支持 CSV、TSV、JSON、XLSX、FASTA；单文件最大 25 MB。空单元格会提示但不影响记录有效性。';
  const toolbar = document.querySelector('#content .toolbar');
  if (toolbar) toolbar.insertAdjacentHTML('afterbegin', btn('查看导入要求', 'v21ImportGuide()', 'secondary') + btn('下载 CSV 模板', 'v21DownloadCSVTemplate()', 'secondary'));
  const filter = document.querySelector('#dsFilter');
  if (filter && ![...filter.options].some(x => x.value === 'XLSX')) filter.insertAdjacentHTML('beforeend', '<option>XLSX</option>');
};

window.uploadForm = function (datasetId = '') {
  const selected = datasets.find(d => d.id === datasetId);
  const options = projects.map(p => `<option value="${esc(p.id)}" ${selected?.project_id === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
  modal(selected ? '导入并创建数据集新版本' : '导入科研数据文件', `
    <div class="v21-import-summary">
      <b>推荐做法</b>
      <span>第一行是唯一字段名；每条记录一行；建议有“记录编号/ID/Epitope ID”；空单元格允许存在。</span>
    </div>
    <div class="field"><label>所属项目</label><select name="project_id" ${selected ? 'disabled' : ''}>${options}</select></div>
    ${selected ? `<input type="hidden" name="dataset_id" value="${esc(datasetId)}"><div class="notice">本次导入将创建 V${Number(selected.version) + 1}，旧版本快照保留。</div>` : field('数据集名称', 'name', '不填则使用文件名')}
    <div class="field"><label>关联数据来源</label><select name="source_id"><option value="">暂不关联</option>${sources.map(x => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select></div>
    <div class="field"><label>选择文件（CSV / TSV / JSON / XLSX / FASTA，最大 25 MB）</label><input name="file" type="file" accept=".csv,.tsv,.json,.xlsx,.fasta,.fa,.faa,.fna" required></div>
    <div class="field"><label>数据说明（可选）</label><textarea name="description"></textarea></div>
    <div class="notice">导入后请查看“有效 / 异常”和“记录”列表。空字段提示不等于整条记录异常。</div>
  `, async m => {
    const f = m.querySelector('[name=file]').files[0];
    if (!f) throw Error('请先选择文件');
    if (f.size > 25 * 1024 * 1024) throw Error('单个文件最大支持 25 MB');
    const fd = new FormData();
    fd.append('file', f);
    fd.append('project_id', val(m, 'project_id') || selected?.project_id || '');
    fd.append('name', val(m, 'name'));
    fd.append('dataset_id', val(m, 'dataset_id'));
    fd.append('source_id', val(m, 'source_id'));
    fd.append('description', val(m, 'description'));
    const r = await fetch('/api/upload', {method: 'POST', body: fd});
    const d = await r.json();
    if (!r.ok) throw Error(d.错误 || '导入失败');
    await load();
    toast(`导入完成：V${d.version}，${d.records} 条记录，有效 ${d.valid_count}，异常 ${d.invalid_count}，空字段提示 ${d.warning_count || 0}`);
    const lines = [];
    if (d.issues?.length) lines.push('异常记录：\n' + d.issues.slice(0, 20).join('\n'));
    if (d.warnings?.length) lines.push('提示（不影响有效性）：\n' + d.warnings.slice(0, 20).join('\n'));
    if (lines.length) alert(lines.join('\n\n') + (d.warnings?.length > 20 ? '\n\n更多提示请在记录列表中查看。' : ''));
  });
  document.querySelector('.modalbox').classList.add('wide');
};

window.linkEvidence = async function (eid) {
  const evidenceItem = evidence.find(x => x.id === eid);
  if (!datasets.length) return toast('请先在数据中心导入数据');
  const options = datasets.map(d => `<option value="${d.id}">${esc(d.name)}（${d.record_count || 0} 条）</option>`).join('');
  modal('建立证据关联', `
    <div class="v21-import-summary"><b>为什么有很多记录？</b><span>一条证据关联的是某个具体数据记录；数据集中有 3000 条记录，就会显示 3000 个候选。先选择数据集，再用关键词搜索记录编号或内容。</span></div>
    <div class="field"><label>证据</label><input value="${esc(evidenceItem?.title || '')}" disabled></div>
    <div class="two">
      <div class="field"><label>数据集</label><select id="v21LinkDataset">${options}</select></div>
      <div class="field"><label>关联类型</label><select name="relation"><option>关联</option><option>支持</option><option>补充</option><option>存在差异</option><option>待核查</option></select></div>
    </div>
    <div class="field"><label>搜索记录编号、标识或内容</label><input id="v21LinkSearch" placeholder="例如：1073、Epitope、蛋白名称"></div>
    <div class="field"><label>选择具体记录</label><select id="v21LinkRecord" name="record_id" size="10"></select></div>
    <div class="detail" id="v21LinkPreview">正在读取记录…</div>
  `, async m => {
    const rid = val(m, 'record_id');
    if (!rid) throw Error('请选择一条记录');
    await post('/api/evidence/link', {evidence_id: eid, record_id: rid, relation: val(m, 'relation')});
    toast('证据关联已建立；记录编号已写入追溯链');
  });
  const box = document.querySelector('.modalbox');
  box.classList.add('wide');
  const dsSel = box.querySelector('#v21LinkDataset');
  const search = box.querySelector('#v21LinkSearch');
  const recSel = box.querySelector('#v21LinkRecord');
  const preview = box.querySelector('#v21LinkPreview');
  let cache = [];
  const drawPreview = () => {
    const item = cache.find(r => r.id === recSel.value);
    if (!item) return;
    preview.textContent = `记录标识：${item.record_key}\n有效性：${item.valid ? '有效' : '异常'}\n提示：${item.issue || '无'}\n内容：${String(item.content).slice(0, 500)}`;
  };
  const draw = () => {
    const q = (search.value || '').trim().toLowerCase();
    const filtered = q ? cache.filter(r => (r.record_key + ' ' + r.content + ' ' + (r.issue || '')).toLowerCase().includes(q)) : cache;
    const shown = filtered.slice(0, 500);
    recSel.innerHTML = shown.map(r => `<option value="${r.id}">${esc(r.record_key)}${r.valid ? '' : '【异常】'}</option>`).join('') || '<option value="">未找到匹配记录</option>';
    preview.textContent = q ? `匹配 ${filtered.length} 条${filtered.length > 500 ? '，下拉框显示前 500 条，请输入更精确关键词' : ''}` : `当前数据集共 ${cache.length} 条，下拉框先显示前 500 条；输入关键词可快速定位。`;
    drawPreview();
  };
  const loadRecords = async () => {
    recSel.innerHTML = '<option>正在读取…</option>';
    cache = recordsCache[dsSel.value] || await api('/api/datasets/' + encodeURIComponent(dsSel.value) + '/records');
    recordsCache[dsSel.value] = cache;
    draw();
  };
  dsSel.onchange = loadRecords;
  search.oninput = draw;
  recSel.onchange = drawPreview;
  await loadRecords();
};

window.showJobs = function () {
  title('工具与任务');
  const cards = [
    ['任务是什么', '任务会固定本次输入版本，运行检查或字段标准化，生成独立的派生结果；不会覆盖原始数据。'],
    ['完成后在哪里看', '在任务列表点击“运行详情”查看结果摘要和日志；点击“下载任务结果”获取完整 JSON。文件归档在“数据/报告”目录。'],
    ['两类工具', '数据质量检查：标出空字段、重复标识和异常记录。记录标准化：按“字段映射”生成标准字段。']
  ];
  const list = jobs.map(j => `<tr>
    <td><b>${esc(j.name)}</b><br><small class="muted">${j.tool_id === '规则评价' ? '分析中心评价任务' : esc(j.tool_id)}</small></td>
    <td>${esc(j.id)}</td><td>${status(j.status)}</td>
    <td style="min-width:130px"><div class="progress"><i style="width:${j.progress}%"></i></div><small>${j.progress}%</small></td>
    <td>${esc(j.created_at)}</td>
    <td><span class="link" onclick="jobDetail('${j.id}')">运行详情</span>${['SUCCESS','PARTIAL','FAILED'].includes(j.status) ? `　<a href="/api/jobs/${encodeURIComponent(j.id)}/result">下载结果</a>` : ''}${['QUEUED','RUNNING','PENDING'].includes(j.status) ? `　<span class="link" onclick="cancelJob('${j.id}')">取消</span>` : `　<span class="link" onclick="retryJob('${j.id}')">重新运行</span>`}</td>
  </tr>`).join('');
  document.querySelector('#content').innerHTML = `<div class="v21-guide-grid">${cards.map(c => `<div class="v21-guide-card"><b>${c[0]}</b><p>${c[1]}</p></div>`).join('')}</div>
    <div class="toolbar">${btn('＋ 提交分析任务', 'jobForm()')}${btn('管理工具', 'manageTools()', 'secondary')}<input id="v21JobSearch" placeholder="搜索任务名称或编号" oninput="document.querySelectorAll('#v21JobTable tbody tr').forEach(r=>r.hidden=!r.textContent.includes(this.value))"></div>
    ${panel('任务运行列表', table(['任务 / 工具', '任务编号', '状态', '进度', '创建时间', '操作'], list))}`;
  const tableWrap = document.querySelector('#content .tablewrap'); if (tableWrap) tableWrap.id = 'v21JobTable';
};

window.jobForm = function () {
  const toolOptions = tools.filter(t => t.enabled).map(t => `<option value="${esc(t.id)}">${esc(t.name)}（${esc(t.version)}）</option>`).join('');
  modal('提交分析任务', `
    <div class="v21-import-summary"><b>提交后会发生什么？</b><span>系统保存当前项目数据快照 → 后台运行工具 → 生成逐条结果和 JSON 输出文件。原始数据不会被覆盖。</span></div>
    <div class="field"><label>所属项目</label><select name="project_id">${projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select></div>
    ${field('任务名称', 'name', '例如：全项目数据质量检查')}
    <div class="field"><label>选择工具</label><select name="tool_id" id="v21JobTool">${toolOptions}</select></div>
    <div class="field"><label>任务参数（JSON）</label><textarea name="params" rows="7">{}</textarea></div>
    <div class="field"><label>超时（秒）</label><input name="timeout_seconds" type="number" min="0.001" max="3600" value="60"></div>
    <div class="detail" id="v21ToolHint"></div>
  `, async m => {
    let params;
    try { params = JSON.parse(val(m, 'params') || '{}'); } catch { throw Error('任务参数必须是合法 JSON'); }
    if (!val(m, 'name').trim()) throw Error('请填写任务名称');
    const r = await post('/api/jobs', {project_id: val(m, 'project_id'), name: val(m, 'name'), tool_id: val(m, 'tool_id'), params, timeout_seconds: Number(val(m, 'timeout_seconds') || 60)});
    await load();
    page = 'jobs'; render();
    toast(r.缓存命中 ? '已命中相同输入缓存，结果可直接查看' : '任务已提交，后台执行中');
    jobDetail(r.id);
  });
  const box = document.querySelector('.modalbox');
  box.classList.add('wide');
  const sel = box.querySelector('#v21JobTool');
  const hint = box.querySelector('#v21ToolHint');
  const params = box.querySelector('[name=params]');
  const updateHint = () => {
    if (sel.value === '工具-基础质检') {
      hint.textContent = '数据质量检查：逐条检查空字段、重复记录标识和记录有效性。结果会标注每条记录的问题；参数保持 {} 即可。';
      params.value = '{}';
    } else {
      hint.textContent = '记录标准化：按“字段映射”把原字段改名为标准字段。示例：{"字段映射":{"name":"名称","sequence":"序列"}}。建议先确认目标字段名。';
      params.value = '{"字段映射":{"name":"名称","sequence":"序列"}}';
    }
  };
  sel.onchange = updateHint; updateHint();
};

window.jobDetail = async function (id) {
  const [j, input] = await Promise.all([api('/api/jobs/' + encodeURIComponent(id)), api('/api/job-input/' + encodeURIComponent(id)).catch(() => null)]);
  let resultObj = null;
  try { resultObj = j.result ? JSON.parse(j.result) : null; } catch { resultObj = j.result; }
  let summary = '';
  if (resultObj && !Array.isArray(resultObj) && resultObj.结果 && Array.isArray(resultObj.结果)) {
    const rows = resultObj.结果;
    if (j.tool_id === '工具-基础质检') {
      const invalid = rows.filter(x => !x.有效).length;
      const missing = rows.filter(x => (x.缺失字段 || []).length).length;
      const dup = rows.filter(x => x.重复标识).length;
      summary = `记录 ${rows.length} 条；异常 ${invalid} 条；含空字段 ${missing} 条；重复标识 ${dup} 条。`;
    } else {
      summary = `已生成 ${rows.length} 条标准化结果。标准化字段保存在本任务结果中，并同步写入标准记录索引。`;
    }
  } else if (Array.isArray(resultObj)) {
    const lack = resultObj.filter(x => Number(x.维度?.可追溯性 || 0) === 0).length;
    summary = `评价记录 ${resultObj.length} 条；缺少关联证据 ${lack} 条。`;
  }
  const inputRows = input?.payload ? (() => { try { const p = JSON.parse(input.payload); return `数据集 ${p.数据集?.length || 0} 个；输入记录 ${p.记录?.length || 0} 条；工具：${p.工具?.name || ''}`; } catch { return '输入快照已归档'; } })() : '输入快照已归档';
  modal('任务运行详情', `
    <div class="v21-kpis"><div><span>状态</span><b>${status(j.status)}</b></div><div><span>进度</span><b>${j.progress}%</b></div><div><span>工具</span><b>${esc(j.tool_id)}</b></div></div>
    <div class="detail">任务编号：${esc(j.id)}
所属项目：${esc(projects.find(p => p.id === j.project_id)?.name || j.project_id)}
创建时间：${esc(j.created_at || '')}
完成时间：${esc(j.completed_at || '尚未完成')}
输入摘要：${esc(inputRows)}</div>
    <h4>这个任务在做什么</h4><div class="detail">${j.tool_id === '工具-基础质检' ? '检查每条记录的空字段、重复标识和有效性，输出问题清单。' : j.tool_id === '规则评价' ? '按所选权重规则计算每条记录的完整性、证据一致性和可追溯性评分。' : '按字段映射生成标准字段，原始字段和映射关系同时保留。'}</div>
    <h4>结果摘要</h4><div class="detail">${esc(summary || (j.result ? '结果已生成，可下载完整 JSON。' : '任务尚未完成。'))}</div>
    <h4>输出位置</h4><div class="detail">${esc(j.结果文件 || ('数据/报告/任务结果_' + j.id + '.json'))}</div>
    <h4>运行日志</h4><div class="detail">${esc(j.logs || '暂无日志')}</div>
    <div class="actions" style="justify-content:flex-start">
      ${j.result ? `<a class="v21-action-link" href="${esc(j.结果下载 || ('/api/jobs/' + encodeURIComponent(j.id) + '/result'))}">下载任务结果 JSON</a>` : ''}
    </div>
  `, async () => {}, '关闭');
  document.querySelector('.modalbox').classList.add('wide');
};

window.showAnalysis = function () {
  title('分析中心');
  const projectOptions = projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  const ruleOptions = rules.map(r => `<option value="${esc(r.id)}" ${r.active ? 'selected' : ''}>${esc(r.name)} / ${esc(r.version)}</option>`).join('');
  document.querySelector('#content').innerHTML = `
    <div class="notice warn">分析中心执行的是可解释的通用完整性评价，不是生物学有效性预测。评价按项目运行，并归档为可追溯任务。</div>
    <div class="v21-guide-grid">
      <div class="v21-guide-card"><b>选择项目</b><p>只评价该项目的数据记录和关联证据。</p></div>
      <div class="v21-guide-card"><b>选择规则</b><p>不同版本可设置不同权重；历史结果不会被覆盖。</p></div>
      <div class="v21-guide-card"><b>查看汇总</b><p>页面先显示平均分、缺证记录和前 200 条明细；完整结果可下载。</p></div>
    </div>
    <div class="toolbar"><select id="evalProject">${projectOptions}</select><select id="evalRule">${ruleOptions}</select>${btn('运行当前规则评价', 'runEvaluation()')}${btn('＋ 创建规则版本', 'ruleForm()', 'secondary')}${btn('历史结果与复核', 'evaluationHistory()', 'secondary')}</div>
    <div id="evaluationResult">${panel('评价说明', '<div class="detail">数据质量：记录是否有效；来源完整性：关联证据是否填了来源和链接/编号；证据一致性：是否存在争议标记；可追溯性：是否关联证据。空字段本身不会被当作整条记录异常。</div>')}</div>
    ${panel('评价规则版本', table(['规则名称', '版本', '权重配置', '说明', '状态'], rules.map(r => `<tr><td>${esc(r.name)}</td><td>${esc(r.version)}</td><td>${esc(r.configuration)}</td><td>${esc(r.description)}</td><td>${r.active ? '<span class="pill green">当前启用</span>' : '<span class="pill">历史版本</span>'}</td></tr>`).join('')))}
  `;
};

window.runEvaluation = async function () {
  const projectId = document.querySelector('#evalProject')?.value;
  const ruleId = document.querySelector('#evalRule')?.value;
  if (!projectId) return toast('请先创建项目并导入数据');
  if (!ruleId) return toast('请先创建评价规则');
  const resultBox = document.querySelector('#evaluationResult');
  const button = [...document.querySelectorAll('button')].find(x => x.textContent.includes('运行当前规则评价'));
  if (button) { button.disabled = true; button.textContent = '正在评价…'; }
  resultBox.innerHTML = panel('正在评价', '<div class="detail">正在读取项目记录、评价规则和证据关联。记录较多时可能需要几秒，请不要重复点击。</div>');
  try {
    const arr = await post('/api/evaluate', {project_id: projectId, rule_id: ruleId});
    window.v21LastEvalResult = arr;
    const n = arr.length;
    const avg = n ? arr.reduce((s, x) => s + Number(x.得分), 0) / n : 0;
    const min = n ? Math.min(...arr.map(x => Number(x.得分))) : 0;
    const max = n ? Math.max(...arr.map(x => Number(x.得分))) : 0;
    const noEvidence = arr.filter(x => Number(x.维度?.可追溯性 || 0) === 0).length;
    const conflict = arr.filter(x => Number(x.解释?.冲突证据数 || 0) > 0).length;
    const invalid = arr.filter(x => Number(x.维度?.数据质量 || 0) === 0).length;
    const shown = arr.slice(0, 200);
    const rows = shown.map(x => `<tr><td>${esc(x.记录)}</td><td><b>${Number(x.得分).toFixed(2)}</b></td><td>${Number(x.维度.来源完整性).toFixed(1)}</td><td>${Number(x.维度.数据质量).toFixed(1)}</td><td>${Number(x.维度.证据一致性).toFixed(1)}</td><td>${Number(x.维度.可追溯性).toFixed(1)}</td><td>${x.解释.关联证据数 || 0}</td></tr>`).join('');
    resultBox.innerHTML = `<div class="v21-kpis"><div><span>评价记录</span><b>${n}</b></div><div><span>平均分</span><b>${avg.toFixed(2)}</b></div><div><span>分数范围</span><b>${min.toFixed(1)}–${max.toFixed(1)}</b></div><div><span>缺少证据</span><b>${noEvidence}</b></div><div><span>争议标记</span><b>${conflict}</b></div><div><span>异常记录</span><b>${invalid}</b></div></div>
      ${panel(`评价明细（显示 ${shown.length} / ${n} 条）`, table(['记录', '得分', '来源完整性', '数据质量', '证据一致性', '可追溯性', '关联证据数'], rows) + (n > shown.length ? `<div class="notice" style="margin-top:10px">为保持页面流畅，只显示前 200 条；完整 ${n} 条结果可下载 JSON。</div>` : ''), btn('下载完整评价结果', "v21DownloadJSON('评价结果.json', window.v21LastEvalResult)", 'secondary'))}`;
    toast('评价完成，结果已归档');
  } catch (e) {
    resultBox.innerHTML = panel('评价失败', `<div class="detail">${esc(e.message)}</div>`);
    toast(e.message);
  } finally {
    if (button) { button.disabled = false; button.textContent = '运行当前规则评价'; }
  }
};
window.evaluate = window.runEvaluation;

window.evaluationHistory = async function () {
  const arr = await api('/api/results');
  const reviews = await api('/api/reviews');
  const filter = document.querySelector('#evalProject')?.value;
  const visible = (filter ? arr.filter(x => x.project_id === filter) : arr).slice(0, 200);
  const revMap = {};
  reviews.forEach(r => { if (!revMap[r.evaluation_id]) revMap[r.evaluation_id] = []; revMap[r.evaluation_id].push(r); });
  modal('历史评价与人工复核', `<div class="notice">显示最近 200 条。评价记录不可修改；人工复核会作为新记录追加。</div>${table(['记录', '规则版本', '得分', '时间', '复核'], visible.map(x => `<tr><td>${esc(x.record_key || x.record_id)}</td><td>${esc(x.rule_name)} ${esc(x.rule_version)}</td><td>${Number(x.score).toFixed(2)}</td><td>${esc(x.created_at)}</td><td>${(revMap[x.id] || []).map(r => `<span class="pill">${esc(r.status)}</span> ${esc(r.notes)}`).join('<br>') || '—'}<br><button class="secondary" onclick="reviewResult('${x.id}')">人工复核</button></td></tr>`).join(''))}`, async () => {}, '关闭');
  document.querySelector('.modalbox').classList.add('wide');
};

window.snapshot = async function (id) {
  const p = projects.find(x => x.id === id);
  const name = prompt('为项目快照命名（快照保存后内容不可修改）', (p?.name || '项目') + '_' + new Date().toLocaleString('zh-CN'));
  if (name === null) return;
  if (!name.trim()) return toast('快照名称不能为空');
  await post('/api/snapshot', {project_id: id, name: name.trim()});
  toast('项目快照已保存；可在系统审计中查看摘要或下载完整归档');
};

window.showSettings = async function () {
  title('系统审计');
  const [logs, snaps] = await Promise.all([api('/api/audit'), api('/api/snapshots/summary')]);
  document.querySelector('#content').innerHTML = `<div class="toolbar">${btn('修改管理员密码', 'changePassword()')}${btn('查看项目快照', 'viewSnapshots()', 'secondary')}<span class="muted">快照是不可变项目状态归档，不是整目录文件备份</span></div>
    ${panel('项目快照', table(['快照名称', '项目', '数据集', '记录', '任务', '评价', '保存时间', '操作'], snaps.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.project_name || s.project_id)}</td><td>${s.summary.数据集数}</td><td>${s.summary.记录数}</td><td>${s.summary.任务数}</td><td>${s.summary.评价数}</td><td>${esc(s.created_at)}</td><td><span class="link" onclick="showSnapshotDetail('${s.id}')">查看摘要</span>　<span class="link" onclick="downloadSnapshot('${s.id}')">下载完整归档</span></td></tr>`).join('')))}
    ${panel('运行环境', `<div class="detail">系统：本地单机环境
后端：Python 标准库 HTTP 服务
数据库：SQLite（本地持久化）
上传文件：数据/上传文件
报告和任务结果：数据/报告
服务地址：http://127.0.0.1:8765
版本：3.3.0</div>`)}
    ${panel('审计日志', table(['时间', '用户', '操作', '对象编号', '详情'], logs.map(x => `<tr><td>${esc(x.created_at)}</td><td>${esc(x.username)}</td><td>${esc(x.action)}</td><td>${esc(x.target)}</td><td>${esc(x.detail)}</td></tr>`).join('')))}
  `;
};

window.viewSnapshots = async function () {
  const snaps = await api('/api/snapshots/summary');
  modal('项目快照摘要', `<div class="notice">快照保存的是当时项目数据库中的数据集元信息、记录、证据关联、任务、评价和报告历史。它不会复制“上传文件”目录中的二进制原文件，因此不能代替整目录备份。</div>${table(['名称', '项目', '数据集', '记录', '保存时间', '操作'], snaps.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.project_name || s.project_id)}</td><td>${s.summary.数据集数}</td><td>${s.summary.记录数}</td><td>${esc(s.created_at)}</td><td><span class="link" onclick="showSnapshotDetail('${s.id}')">查看摘要</span>　<span class="link" onclick="downloadSnapshot('${s.id}')">下载</span></td></tr>`).join(''))}`, async () => {}, '关闭');
  document.querySelector('.modalbox').classList.add('wide');
};

window.showSnapshotDetail = async function (id) {
  const s = await api('/api/snapshot/' + encodeURIComponent(id));
  const p = s.payload || {};
  const items = [
    ['项目基本信息', p.项目基本信息 ? `${p.项目基本信息.name || ''}（${p.项目基本信息.id || ''}）` : '无'],
    ['数据集', `${(p.数据集信息 || []).length} 个`],
    ['原始记录', `${(p.原始记录 || []).length} 条`],
    ['数据来源', `${(p.数据来源 || []).length} 个`],
    ['关联证据', `${(p.关联证据 || []).length} 条`],
    ['证据关联', `${(p.证据关联 || []).length} 条`],
    ['任务运行记录', `${(p.任务运行记录 || []).length} 条`],
    ['评价结果', `${(p.结果统计 || []).length} 条`],
    ['报告历史', `${(p.报告历史 || []).length} 条`]
  ];
  modal('项目快照摘要', `<div class="notice">这是不可变归档的摘要。需要核对每条记录时，请下载完整 JSON；系统不再把近 3000 条原始记录直接展开在弹窗里。</div><div class="v21-snapshot-grid">${items.map(x => `<div><span>${x[0]}</span><b>${esc(x[1])}</b></div>`).join('')}</div><div class="detail">快照编号：${esc(s.id)}\n保存时间：${esc(s.created_at)}\n项目编号：${esc(s.project_id)}\n快照名称：${esc(s.name)}</div><div class="actions" style="justify-content:flex-start"><button class="secondary" onclick="downloadSnapshot('${s.id}')">下载完整 JSON 归档</button></div>`, async () => {}, '关闭');
  document.querySelector('.modalbox').classList.add('wide');
};
window.downloadSnapshot = async function (id) {
  const s = await api('/api/snapshot/' + encodeURIComponent(id));
  v21DownloadJSON(`项目快照_${id}.json`, s);
};

window.showReports = async function () {
  await v21BaseShowReports();
  const format = document.querySelector('#reportFormat');
  if (format) {
    if (![...format.options].some(x => x.value === 'pdf')) format.insertAdjacentHTML('afterbegin', '<option value="pdf">中文报告 PDF</option>');
    format.value = 'pdf';
  }
  const notice = document.querySelector('#content .notice');
  if (notice) notice.innerHTML = '报告从当前项目数据库生成。PDF 已嵌入中文字体，不依赖本机是否安装宋体；PDF 用于阅读摘要，JSON 用于完整归档。生成文件和任务结果统一保存在“数据/报告”。';
};
window.makeReport = async function () {
  const button = [...document.querySelectorAll('button')].find(x => x.textContent.includes('生成报告'));
  if (button) { button.disabled = true; button.textContent = '正在生成…'; }
  try {
    const d = await post('/api/reports', {project_id: document.querySelector('#reportProject').value, format: document.querySelector('#reportFormat').value, template_id: document.querySelector('#reportTemplate')?.value || ''});
    toast('报告生成成功，正在打开下载');
    window.open(d.download, '_blank');
    await showReports();
  } catch (e) { toast(e.message); }
  finally { if (button) { button.disabled = false; button.textContent = '生成报告'; } }
};





