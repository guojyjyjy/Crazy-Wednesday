@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist "runtime\python.exe" goto bundled
py -3.14 --version >nul 2>nul
if not errorlevel 1 goto py314
python --version >nul 2>nul
if not errorlevel 1 goto python
py -3 --version >nul 2>nul
if not errorlevel 1 goto py3
echo 未找到随包运行环境，也没有检测到 Python。
echo 请确认压缩包已完整解压，并且 runtime 文件夹没有被删除。
pause
exit /b 1
:bundled
"runtime\python.exe" "启动器.py"
goto end
:py314
py -3.14 "启动器.py"
goto end
:python
python "启动器.py"
goto end
:py3
py -3 "启动器.py"
:end
pause
