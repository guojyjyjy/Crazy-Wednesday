#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Brucella-EpiWork 本地一体化服务。仅使用 Python 标准库，便于竞赛现场离线演示。"""
import http.server, socketserver, json, sqlite3, os, uuid, hashlib, csv, io, mimetypes, urllib.parse, datetime, threading, time, zipfile, html, re
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("EPIWORK_DATA", str(BASE / "数据")))
UPLOAD = DATA / "上传文件"
REPORT = DATA / "报告"
DB = DATA / "epiwork.db"
WEB = BASE / "前端"
for p in (UPLOAD, REPORT): p.mkdir(parents=True, exist_ok=True)
APP_VERSION = "3.3.0"
MAX_UPLOAD_BYTES = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {".fa", ".fasta", ".faa", ".fna", ".csv", ".tsv", ".json", ".xlsx"}

def now(): return datetime.datetime.now().isoformat(timespec="seconds")
def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT);
        CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,name TEXT,description TEXT,owner TEXT,created_at TEXT,updated_at TEXT);
        CREATE TABLE IF NOT EXISTS datasets(id TEXT PRIMARY KEY,project_id TEXT,name TEXT,type TEXT,filename TEXT,record_count INTEGER,valid_count INTEGER,invalid_count INTEGER,sha256 TEXT,version INTEGER,created_at TEXT,notes TEXT);
        CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,dataset_id TEXT,record_key TEXT,content TEXT,metadata TEXT,valid INTEGER,issue TEXT);
        CREATE TABLE IF NOT EXISTS file_assets(id TEXT PRIMARY KEY,project_id TEXT,dataset_id TEXT,original_filename TEXT,stored_filename TEXT,relative_path TEXT,file_size INTEGER,sha256 TEXT,file_type TEXT,uploaded_at TEXT,upload_status TEXT);
        CREATE TABLE IF NOT EXISTS dataset_versions(id TEXT PRIMARY KEY,dataset_id TEXT,version INTEGER,file_asset_id TEXT,record_count INTEGER,valid_count INTEGER,invalid_count INTEGER,change_summary TEXT,records_snapshot TEXT,created_at TEXT,UNIQUE(dataset_id,version));
        CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,name TEXT,source_type TEXT,source_url TEXT,description TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS evidence(id TEXT PRIMARY KEY,source_id TEXT,title TEXT,identifier TEXT,url TEXT,evidence_type TEXT,status TEXT,content TEXT,notes TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS evidence_links(id TEXT PRIMARY KEY,evidence_id TEXT,record_id TEXT,relation TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS tools(id TEXT PRIMARY KEY,name TEXT,version TEXT,description TEXT,enabled INTEGER);
        CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,project_id TEXT,name TEXT,tool_id TEXT,status TEXT,progress INTEGER,params TEXT,logs TEXT,result TEXT,created_at TEXT,completed_at TEXT);
        CREATE TABLE IF NOT EXISTS rules(id TEXT PRIMARY KEY,name TEXT,version TEXT,configuration TEXT,description TEXT,created_at TEXT,active INTEGER);
        CREATE TABLE IF NOT EXISTS evaluations(id TEXT PRIMARY KEY,job_id TEXT,record_id TEXT,rule_id TEXT,score REAL,details TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS snapshots(id TEXT PRIMARY KEY,project_id TEXT,name TEXT,payload TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT,target TEXT,detail TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,project_id TEXT,name TEXT,format TEXT,path TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS report_templates(id TEXT PRIMARY KEY,name TEXT,description TEXT,sections TEXT,created_at TEXT,updated_at TEXT);
        """)
        # 证据中心与任务中心的增量结构迁移（兼容既有数据库）。
        c.execute("CREATE TABLE IF NOT EXISTS evidence_versions(id TEXT PRIMARY KEY,evidence_id TEXT,version INTEGER,payload TEXT,change_summary TEXT,created_at TEXT,UNIQUE(evidence_id,version))")
        c.execute("CREATE TABLE IF NOT EXISTS job_cache(cache_key TEXT PRIMARY KEY,result TEXT,created_at TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS normalized_records(id TEXT PRIMARY KEY,record_id TEXT,standard_type TEXT,standard_payload TEXT,field_mapping TEXT,created_at TEXT,UNIQUE(record_id,standard_type))")
        evidence_cols={r[1] for r in c.execute("PRAGMA table_info(evidence)").fetchall()}
        for column,definition in [("publication_date","TEXT DEFAULT ''"),("source_identifier","TEXT DEFAULT ''"),("tags","TEXT DEFAULT ''"),("conflict_group","TEXT DEFAULT ''"),("updated_at","TEXT DEFAULT ''")]:
            if column not in evidence_cols: c.execute(f"ALTER TABLE evidence ADD COLUMN {column} {definition}")
        job_cols={r[1] for r in c.execute("PRAGMA table_info(jobs)").fetchall()}
        for column,definition in [("cancel_requested","INTEGER DEFAULT 0"),("timeout_seconds","INTEGER DEFAULT 60"),("cache_key","TEXT DEFAULT ''"),("attempt","INTEGER DEFAULT 1"),("parent_job_id","TEXT DEFAULT ''")]:
            if column not in job_cols: c.execute(f"ALTER TABLE jobs ADD COLUMN {column} {definition}")
        # 兼容旧版数据库：为数据集补充可维护元数据字段。
        existing = {r[1] for r in c.execute("PRAGMA table_info(datasets)").fetchall()}
        for column, definition in [("description", "TEXT DEFAULT ''"), ("source_id", "TEXT"), ("updated_at", "TEXT")]:
            if column not in existing:
                c.execute(f"ALTER TABLE datasets ADD COLUMN {column} {definition}")
        c.execute("INSERT OR IGNORE INTO users(username,password,role) VALUES(?,?,?)",("管理员","epiwork123","系统管理员"))
        # 仅创建运行所需的工具和默认评价规则，不写入任何演示项目或业务数据。
        c.execute("INSERT OR IGNORE INTO tools VALUES(?,?,?,?,?)",("工具-基础质检","数据质量检查","1.0.0","统计空字段、重复标识和记录有效性；不执行生物学预测。",1))
        c.execute("INSERT OR IGNORE INTO tools VALUES(?,?,?,?,?)",("工具-记录标准化","记录标准化","1.0.0","按显式字段映射生成标准字段，保留原始字段和映射关系。",1))
        c.execute("INSERT OR IGNORE INTO rules VALUES(?,?,?,?,?,?,?)",("规则-默认","通用完整性评价规则","1.0",json.dumps({"来源完整性":30,"数据质量":30,"证据一致性":20,"可追溯性":20},ensure_ascii=False),"按来源完整性、数据质量、证据一致性和可追溯性进行通用完整性评价。",now(),1))
        # 旧版数据集升级时补建可追溯的初始版本快照，不伪造原始文件资产。
        for ds in c.execute("SELECT * FROM datasets").fetchall():
            exists = c.execute("SELECT 1 FROM dataset_versions WHERE dataset_id=? LIMIT 1", (ds["id"],)).fetchone()
            if not exists:
                recs = c.execute("SELECT record_key,content,metadata,valid,issue FROM records WHERE dataset_id=?", (ds["id"],)).fetchall()
                snapshot = [{"记录标识":r[0],"内容":r[1],"元数据":json.loads(r[2] or "{}"),"有效":r[3],"问题":r[4]} for r in recs]
                c.execute("INSERT INTO dataset_versions VALUES(?,?,?,?,?,?,?,?,?,?)", (ident("版本"),ds["id"],ds["version"],None,ds["record_count"],ds["valid_count"],ds["invalid_count"],"由旧版数据库迁移生成的历史快照（原始文件资产未登记）",json.dumps(snapshot,ensure_ascii=False),now()))

def audit(user,action,target="",detail=""):
    with conn() as c: c.execute("INSERT INTO audit(username,action,target,detail,created_at) VALUES(?,?,?,?,?)",(user,action,target,detail,now()))

def rows(sql,args=()):
    with conn() as c: return [dict(x) for x in c.execute(sql,args).fetchall()]
def one(sql,args=()):
    with conn() as c:
        x=c.execute(sql,args).fetchone()
        return dict(x) if x else None
def ident(prefix): return prefix+"-"+uuid.uuid4().hex[:10]
def safe_name(s): return "".join(ch for ch in s if ch.isalnum() or ch in "._-中文")[:100] or "文件"
def stored_asset_path(value):
    p=Path(value); return p.resolve() if p.is_absolute() else (BASE/p).resolve()
def db_asset_path(path):
    path=path.resolve(); return str(path.relative_to(BASE)) if path.is_relative_to(BASE) else str(path)

XLSX_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main", "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
KEY_FIELDS = ["Epitope ID", "IEDB IRI", "记录编号", "记录ID", "记录ID", "ID", "id", "编号", "Name", "name", "名称", "Accession", "accession", "protein_id", "Protein ID"]


def _xlsx_col_index(ref):
    letters = re.match(r"([A-Za-z]+)", str(ref or ""))
    if not letters:
        return 0
    n = 0
    for ch in letters.group(1).upper():
        n = n * 26 + ord(ch) - 64
    return n - 1


def _xlsx_sheet_rows(raw):
    """读取 XLSX 第一张工作表，返回 [(行号, {列号: 文本}), ...]。"""
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = set(z.namelist())
            shared = []
            if "xl/sharedStrings.xml" in names:
                root = ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in root.findall("m:si", XLSX_NS):
                    shared.append("".join(t.text or "" for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
            workbook = ET.fromstring(z.read("xl/workbook.xml"))
            sheets = workbook.find("m:sheets", XLSX_NS)
            if sheets is None or not list(sheets):
                raise ValueError("XLSX 中没有工作表")
            first = list(sheets)[0]
            rid = first.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id", "")
            target = ""
            if "xl/_rels/workbook.xml.rels" in names:
                relroot = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
                for rel in relroot:
                    if rel.attrib.get("Id") == rid:
                        target = rel.attrib.get("Target", "")
                        break
            if target.startswith("/"):
                sheet_path = target.lstrip("/")
            elif target:
                sheet_path = "xl/" + target.lstrip("/")
            else:
                sheet_path = "xl/worksheets/sheet1.xml"
            if sheet_path not in names:
                raise ValueError("找不到 XLSX 第一张工作表")
            root = ET.fromstring(z.read(sheet_path))
            result = []
            for row in root.findall(".//m:sheetData/m:row", XLSX_NS):
                cells = {}
                for cell in row.findall("m:c", XLSX_NS):
                    col = _xlsx_col_index(cell.attrib.get("r", ""))
                    typ = cell.attrib.get("t", "")
                    value_node = cell.find("m:v", XLSX_NS)
                    inline = cell.find("m:is", XLSX_NS)
                    formula = cell.find("m:f", XLSX_NS)
                    if typ == "s" and value_node is not None and str(value_node.text or "").strip().isdigit():
                        idx = int(value_node.text)
                        value = shared[idx] if 0 <= idx < len(shared) else ""
                    elif typ == "inlineStr" and inline is not None:
                        value = "".join(t.text or "" for t in inline.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
                    elif typ == "b" and value_node is not None:
                        value = "是" if value_node.text == "1" else "否"
                    elif value_node is not None:
                        value = value_node.text or ""
                    elif formula is not None:
                        value = ""
                    else:
                        value = ""
                    cells[col] = str(value).strip()
                if any(v for v in cells.values()):
                    result.append((int(float(row.attrib.get("r", len(result) + 1))), cells))
            return result
    except zipfile.BadZipFile:
        raise ValueError("XLSX 文件损坏或不是有效的 Excel 工作簿")


def _make_headers(parent, child):
    cols = sorted(set(parent) | set(child))
    used = {}
    result = {}
    for col in cols:
        p = parent.get(col, "").strip()
        c = child.get(col, "").strip()
        if p and c and p != c:
            name = p + " / " + c
        else:
            name = c or p
        if not name:
            continue
        base = name
        n = used.get(base, 0) + 1
        used[base] = n
        if n > 1:
            name = f"{base} ({n})"
        result[col] = name
    return result


def _xlsx_headers_and_rows(rows):
    if not rows:
        raise ValueError("XLSX 中没有可读取的数据")
    first_i = 0
    first_row = rows[0][1]
    parent = {c: first_row.get(c, "") for c in first_row}
    merge = False
    headers = _make_headers({}, parent)
    data_start = 1
    if len(rows) > 1:
        second = rows[1][1]
        parent_values = [v for v in parent.values() if v]
        child_values = [v for v in second.values() if v]
        parent_unique = len(set(parent_values))
        child_unique = len(set(child_values))
        shared_cols = len(set(parent) & set(second))
        if (len(parent_values) >= 2 and len(child_values) >= 2 and
                shared_cols >= max(2, int(len(parent_values) * 0.7)) and
                parent_unique <= max(2, int(len(parent_values) * 0.55)) and
                child_unique >= parent_unique + 2):
            headers = _make_headers(parent, second)
            data_start = 2
            merge = True
    headers = {c: h for c, h in headers.items() if h}
    if not headers:
        raise ValueError("XLSX 缺少有效表头")
    data_rows = []
    for rownum, cells in rows[data_start:]:
        meta = {h: cells.get(c, "") for c, h in sorted(headers.items())}
        if any(str(v).strip() for v in meta.values()):
            data_rows.append((rownum, meta))
    if not data_rows:
        raise ValueError("表格只有表头，没有数据记录")
    return list(headers.values()), data_rows, merge


def _record_key(meta, row_no):
    lower = {str(k).strip().lower(): (k, v) for k, v in meta.items()}
    for candidate in KEY_FIELDS:
        key = candidate.lower()
        if key in lower:
            value = str(lower[key][1]).strip()
            if value:
                if re.match(r"https?://", value, re.I):
                    value = urllib.parse.urlparse(value).path.rstrip("/").split("/")[-1] or value
                return value
    for header, value in meta.items():
        h = str(header).lower()
        if any(x in h for x in ("epitope id", "iedb iri", "记录编号", "记录id", "accession", "protein id")):
            value = str(value).strip()
            if value:
                if re.match(r"https?://", value, re.I):
                    value = urllib.parse.urlparse(value).path.rstrip("/").split("/")[-1] or value
                return value
    return f"第{row_no}行"


def parse_upload(filename, raw):
    """解析 FASTA/CSV/TSV/JSON/XLSX，返回记录和解析级提示。"""
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError("文件格式不支持，仅支持 FASTA、CSV、TSV、JSON、XLSX")
    records, parse_warnings = [], []
    if ext == ".xlsx":
        all_rows = _xlsx_sheet_rows(raw)
        headers, data_rows, merged = _xlsx_headers_and_rows(all_rows)
        if merged:
            parse_warnings.append("检测到两行表头，已合并为唯一字段名。")
        for row_no, normalized in data_rows:
            key = _record_key(normalized, row_no)
            records.append((key, json.dumps(normalized, ensure_ascii=False), normalized))
        return records, parse_warnings

    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("文件编码不是 UTF-8，请另存为 UTF-8 后重试")
    if not text.strip():
        raise ValueError("文件内容为空")

    if ext in (".fa", ".fasta", ".faa", ".fna"):
        current, seq = None, []
        for line_no, line in enumerate(text.splitlines(), 1):
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if current is not None:
                    records.append((current, "".join(seq), {"标题": current, "格式": "FASTA"}))
                current, seq = line[1:].strip(), []
                if not current:
                    raise ValueError(f"第 {line_no} 行：FASTA 标题为空")
            elif current is None:
                raise ValueError(f"第 {line_no} 行：FASTA 序列必须位于 > 标题行之后")
            else:
                seq.append("".join(line.split()))
        if current is not None:
            records.append((current, "".join(seq), {"标题": current, "格式": "FASTA"}))
        if not records:
            raise ValueError("未解析到任何 FASTA 记录")
    elif ext in (".csv", ".tsv"):
        delimiter = "\t" if ext == ".tsv" else ","
        reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
        if not reader.fieldnames:
            raise ValueError("表格缺少字段表头")
        headers = [str(x or "").strip() for x in reader.fieldnames]
        if any(not h for h in headers):
            raise ValueError("表头中存在空字段名")
        if len(set(headers)) != len(headers):
            raise ValueError("表头中存在重复字段名")
        for line_no, row in enumerate(reader, 2):
            if None in row:
                raise ValueError(f"第 {line_no} 行：字段数量多于表头列数")
            normalized = {str(k or "").strip(): str(v if v is not None else "").strip() for k, v in row.items()}
            if not any(normalized.values()):
                continue
            key = _record_key(normalized, line_no)
            records.append((key, json.dumps(normalized, ensure_ascii=False), normalized))
        if not records:
            raise ValueError("表格只有表头，没有数据记录")
    else:
        try:
            obj = json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"JSON 格式错误：第 {e.lineno} 行，第 {e.colno} 列：请检查逗号、引号及括号是否完整")
        if isinstance(obj, list):
            arr = obj
        elif isinstance(obj, dict) and isinstance(obj.get("records"), list):
            arr = obj["records"]
        else:
            raise ValueError("JSON 顶层必须是数组，或包含 records 数组的对象")
        for i, item in enumerate(arr, 1):
            if isinstance(item, dict):
                key = _record_key(item, i)
                meta = item
            else:
                key, meta = f"第{i}条", {"value": item}
                parse_warnings.append(f"第 {i} 条不是对象，已按 value 字段保存。")
            records.append((key, json.dumps(item, ensure_ascii=False), meta))
        if not records:
            raise ValueError("JSON 中 records 数组为空")
    return records, parse_warnings


def record_validation(key, value, meta, seen):
    """返回 (致命错误, 提示)。空单元格只提示，不直接把整条记录判为异常。"""
    errors, warnings = [], []
    if not str(key).strip():
        errors.append("记录标识为空")
    if key in seen:
        errors.append("记录标识重复")
    if not str(value).strip():
        errors.append("记录内容为空")
    if isinstance(meta, dict) and not meta:
        errors.append("记录字段为空")
    if isinstance(meta, dict):
        missing = [str(k) for k, v in meta.items() if v is None or (isinstance(v, str) and not v.strip())]
        if len(missing) == len(meta):
            errors.append("整行记录为空")
        elif missing:
            shown = "、".join(missing[:8]) + ("等" if len(missing) > 8 else "")
            warnings.append(f"空字段：{shown}（可选字段为空不影响记录有效性）")
    if isinstance(meta, dict) and meta.get("格式") == "FASTA":
        seq = str(value).upper()
        if not seq:
            errors.append("FASTA 序列内容为空")
        elif any(ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ*.-" for ch in seq):
            errors.append("FASTA 序列包含非法字符")
    return errors, warnings


def save_dataset_version(dataset_id, version, asset_id, records_data, valid_count, invalid_count, summary):
    snapshot = [{"记录标识": x[0], "内容": x[1], "元数据": x[2], "有效": x[3], "问题": x[4]} for x in records_data]
    with conn() as c:
        c.execute("INSERT INTO dataset_versions VALUES(?,?,?,?,?,?,?,?,?,?)", (
            ident("版本"), dataset_id, version, asset_id, len(records_data), valid_count,
            invalid_count, summary, json.dumps(snapshot, ensure_ascii=False), now()))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(WEB),**kw)
    def log_message(self,*a): pass
    def send_json(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.send_header("Access-Control-Allow-Origin","*"); self.end_headers(); self.wfile.write(data)
    def body(self):
        n=int(self.headers.get("Content-Length",0)); return self.rfile.read(n)
    def original_get(self):
        u=urllib.parse.urlparse(self.path); p=urllib.parse.unquote(u.path); q=urllib.parse.parse_qs(u.query)
        if p.startswith("/api/"):
            try:
                if p=="/api/health": return self.send_json({"ok":True,"时间":now(),"版本":APP_VERSION})
                if p=="/api/dashboard":
                    return self.send_json({
                        "projects":one("SELECT COUNT(*) n FROM projects")["n"],
                        "datasets":one("SELECT COUNT(*) n FROM datasets")["n"],
                        "records":one("SELECT COUNT(*) n FROM records")["n"],
                        "evidence":one("SELECT COUNT(*) n FROM evidence")["n"],
                        "jobs":one("SELECT COUNT(*) n FROM jobs")["n"],
                        "success":one("SELECT COUNT(*) n FROM jobs WHERE status='SUCCESS'")["n"],
                        "epitopeProteins":one("SELECT COUNT(*) n FROM epitope_proteins")["n"],
                        "epitopeRuns":one("SELECT COUNT(*) n FROM epitope_runs")["n"],
                        "epitopeCandidates":one("SELECT COUNT(*) n FROM epitope_candidates")["n"],
                        "epitopeSelected":one("SELECT COUNT(*) n FROM epitope_candidates WHERE selected=1")["n"],
                        "epitopeEvidence":one("SELECT COUNT(*) n FROM epitope_evidence")["n"],
                        "recent":rows("SELECT * FROM jobs ORDER BY created_at DESC LIMIT 5"),
                        "recentEpitope":rows("""SELECT er.id,er.protein_name,er.accession,er.status,er.candidate_count,er.elapsed_ms,er.created_at,
                                                       d.name dataset_name,rec.record_key,s.name source_name
                                                FROM epitope_runs er
                                                LEFT JOIN datasets d ON d.id=er.dataset_id
                                                LEFT JOIN records rec ON rec.id=er.record_id
                                                LEFT JOIN sources s ON s.id=er.source_id
                                                ORDER BY er.created_at DESC LIMIT 8"""),
                        "datasetTypes":rows("SELECT type,COUNT(*) count FROM datasets GROUP BY type"),
                        "jobStates":rows("SELECT status,COUNT(*) count FROM jobs GROUP BY status")
                    })
                mapping={"/api/projects":"SELECT * FROM projects ORDER BY created_at DESC","/api/datasets":"SELECT d.*,p.name project_name,s.name source_name FROM datasets d LEFT JOIN projects p ON p.id=d.project_id LEFT JOIN sources s ON s.id=d.source_id ORDER BY d.created_at DESC","/api/sources":"SELECT * FROM sources ORDER BY created_at DESC","/api/evidence":"SELECT e.*,s.name source_name FROM evidence e LEFT JOIN sources s ON s.id=e.source_id ORDER BY e.created_at DESC","/api/tools":"SELECT * FROM tools","/api/jobs":"SELECT * FROM jobs ORDER BY created_at DESC","/api/rules":"SELECT * FROM rules ORDER BY created_at DESC","/api/snapshots":"SELECT * FROM snapshots ORDER BY created_at DESC","/api/audit":"SELECT * FROM audit ORDER BY id DESC LIMIT 200","/api/reports":"SELECT * FROM reports ORDER BY created_at DESC"}
                if p in mapping: return self.send_json(rows(mapping[p]))
                if p == "/api/datasets/search":
                    term=q.get("关键词",[""])[0].strip(); dtype=q.get("类型",[""])[0].strip(); source=q.get("来源",[""])[0].strip(); project=q.get("项目",[""])[0].strip()
                    sql="SELECT d.*,p.name project_name,s.name source_name FROM datasets d LEFT JOIN projects p ON p.id=d.project_id LEFT JOIN sources s ON s.id=d.source_id WHERE 1=1"; args=[]
                    if term: sql += " AND (d.id LIKE ? OR d.name LIKE ? OR d.filename LIKE ?)"; args += [f"%{term}%"]*3
                    if dtype: sql += " AND d.type=?"; args.append(dtype)
                    if source: sql += " AND (d.source_id=? OR s.name LIKE ?)"; args += [source,f"%{source}%"]
                    if project: sql += " AND d.project_id=?"; args.append(project)
                    sql += " ORDER BY d.created_at DESC"; return self.send_json(rows(sql,args))
                if p.startswith("/api/datasets/") and p.endswith("/records"):
                    did=p.split("/")[-2]; return self.send_json(rows("SELECT * FROM records WHERE dataset_id=? ORDER BY rowid",(did,)))
                if p.startswith("/api/datasets/") and p.endswith("/versions"):
                    did=p.split("/")[-2]; return self.send_json(rows("SELECT v.*,f.original_filename,f.sha256 FROM dataset_versions v LEFT JOIN file_assets f ON f.id=v.file_asset_id WHERE v.dataset_id=? ORDER BY v.version DESC",(did,)))
                if p.startswith("/api/datasets/") and p.endswith("/files"):
                    did=p.split("/")[-2]; return self.send_json(rows("SELECT * FROM file_assets WHERE dataset_id=? ORDER BY uploaded_at DESC",(did,)))
                if p.startswith("/api/datasets/"):
                    did=p.rsplit("/",1)[-1]; return self.send_json(one("SELECT * FROM datasets WHERE id=?",(did,)) or {"错误":"数据集不存在"},200 if one("SELECT id FROM datasets WHERE id=?",(did,)) else 404)
                if p.startswith("/api/jobs/"):
                    jid=p.rsplit("/",1)[-1]; return self.send_json(one("SELECT * FROM jobs WHERE id=?",(jid,)) or {},404 if not one("SELECT id FROM jobs WHERE id=?",(jid,)) else 200)
                if p=="/api/evidence/versions":
                    return self.send_json(rows("SELECT * FROM evidence_versions WHERE evidence_id=? ORDER BY version DESC",(q.get("evidence_id",[""])[0],)))
                if p.startswith("/api/evidence/"):
                    eid=p.rsplit("/",1)[-1]
                    return self.send_json({"evidence":one("SELECT e.*,s.name source_name FROM evidence e LEFT JOIN sources s ON s.id=e.source_id WHERE e.id=?",(eid,)),"links":rows("SELECT l.*,r.record_key,d.name dataset_name FROM evidence_links l LEFT JOIN records r ON r.id=l.record_id LEFT JOIN datasets d ON d.id=r.dataset_id WHERE l.evidence_id=?",(eid,))})
                if p=="/api/trace":
                    rid=q.get("record_id",[""])[0]
                    return self.send_json({"record":one("SELECT r.*,d.name dataset_name,d.project_id FROM records r JOIN datasets d ON d.id=r.dataset_id WHERE r.id=?",(rid,)),"links":rows("SELECT e.*,s.name source_name,l.relation FROM evidence_links l JOIN evidence e ON e.id=l.evidence_id LEFT JOIN sources s ON s.id=e.source_id WHERE l.record_id=?",(rid,))})
                if p=="/api/evidence/versions":
                    eid=q.get("evidence_id",[""])[0]
                    return self.send_json(rows("SELECT * FROM evidence_versions WHERE evidence_id=? ORDER BY version DESC",(eid,)))
                if p=="/api/trace-chain":
                    rid=q.get("record_id",[""])[0]
                    rec=one("SELECT r.*,d.name dataset_name,d.id dataset_id,d.project_id,p.name project_name FROM records r JOIN datasets d ON d.id=r.dataset_id JOIN projects p ON p.id=d.project_id WHERE r.id=?",(rid,))
                    links=rows("SELECT e.*,s.name source_name,l.relation FROM evidence_links l JOIN evidence e ON e.id=l.evidence_id LEFT JOIN sources s ON s.id=e.source_id WHERE l.record_id=?",(rid,))
                    assets=rows("SELECT f.* FROM file_assets f JOIN datasets d ON d.id=f.dataset_id JOIN records r ON r.dataset_id=d.id WHERE r.id=?",(rid,))
                    return self.send_json({"项目":rec.get("project_name") if rec else None,"数据集":rec.get("dataset_name") if rec else None,"记录":rec,"文件资产":assets,"证据":links})
                if p=="/api/visualization/summary":
                    return self.send_json({"数据集格式":rows("SELECT type 名称,COUNT(*) 数量 FROM datasets GROUP BY type"),"来源分布":rows("SELECT COALESCE(s.name,'未关联来源') 名称,COUNT(d.id) 数量 FROM datasets d LEFT JOIN sources s ON s.id=d.source_id GROUP BY s.name"),"完整性":rows("SELECT name 名称,record_count 总数,valid_count 有效数,invalid_count 异常数 FROM datasets"),"任务状态":rows("SELECT status 名称,COUNT(*) 数量 FROM jobs GROUP BY status"),"证据状态":rows("SELECT status 名称,COUNT(*) 数量 FROM evidence GROUP BY status"),"评价规则":rows("SELECT rule_id,ROUND(AVG(score),2) 平均分,COUNT(*) 记录数 FROM evaluations GROUP BY rule_id")})
                if p=="/api/report-templates":
                    return self.send_json(rows("SELECT * FROM report_templates ORDER BY created_at DESC"))
                if p.startswith("/api/export/dataset/"):
                    did=p.rsplit("/",1)[-1]; ds=one("SELECT * FROM datasets WHERE id=?",(did,))
                    if not ds: return self.send_json({"错误":"数据集不存在"},404)
                    fmt=q.get("format",["json"])[0].lower()
                    recs=rows("SELECT record_key,content,metadata,valid,issue FROM records WHERE dataset_id=? ORDER BY rowid",(did,))
                    name=safe_name(ds["name"])+"_"+datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    if fmt=="fasta":
                        if ds["type"].lower() not in ("fa","fasta","faa","fna"):return self.send_json({"错误":"仅序列数据集可以导出 FASTA"},400)
                        payload="\n".join(">"+str(r["record_key"])+"\n"+str(r["content"]) for r in recs)
                        path=REPORT/(name+".fasta"); path.write_text(payload+"\n",encoding="utf-8",newline="\n")
                    elif fmt=="csv":
                        path=REPORT/(name+".csv")
                        with path.open("w",newline="",encoding="utf-8-sig") as f:
                            w=csv.writer(f); w.writerow(["记录编号","记录内容","是否有效","异常说明","元数据"])
                            for r in recs:w.writerow([r["record_key"],r["content"],r["valid"],r["issue"],r["metadata"]])
                    elif fmt=="json":
                        path=REPORT/(name+".json"); path.write_text(json.dumps({"数据集":ds,"记录":recs},ensure_ascii=False,indent=2),encoding="utf-8")
                    elif fmt=="xlsx":
                        import zipfile as zf, xml.etree.ElementTree as ET
                        path=REPORT/(name+".xlsx")
                        headers=["记录编号","记录内容","是否有效","异常说明","元数据"]
                        def cell(ref,val):
                            return '<c r="'+ref+'" t="inlineStr"><is><t>'+html.escape(str(val))+'</t></is></c>'
                        sheet=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
                        for ri,row in enumerate([headers]+[[r["record_key"],r["content"],r["valid"],r["issue"],r["metadata"]] for r in recs],1):
                            sheet.append('<row r="'+str(ri)+'">')
                            for ci,v in enumerate(row):
                                col=""; n=ci+1
                                while n: n,rem=divmod(n-1,26); col=chr(65+rem)+col
                                sheet.append(cell(col+str(ri),v))
                            sheet.append('</row>')
                        sheet.append('</sheetData></worksheet>')
                        with zf.ZipFile(path,"w",zf.ZIP_DEFLATED) as z:
                            z.writestr("[Content_Types].xml",'<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
                            z.writestr("_rels/.rels",'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
                            z.writestr("xl/workbook.xml",'<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="数据记录" sheetId="1" r:id="rId1"/></sheets></workbook>')
                            z.writestr("xl/_rels/workbook.xml.rels",'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
                            z.writestr("xl/worksheets/sheet1.xml","".join(sheet))
                    else: return self.send_json({"错误":"导出格式仅支持 FASTA、CSV、JSON、XLSX"},400)
                    audit("管理员","导出数据集",did,fmt)
                    return self.send_json({"文件":path.name,"下载":"/download/"+path.name,"格式":fmt,"记录数":len(recs)})
                if p=="/api/projects/detail":
                    pid=q.get("id",[""])[0]
                    return self.send_json({"project":one("SELECT * FROM projects WHERE id=?",(pid,)),"datasets":rows("SELECT * FROM datasets WHERE project_id=?",(pid,)),"jobs":rows("SELECT * FROM jobs WHERE project_id=?",(pid,)),"snapshots":rows("SELECT * FROM snapshots WHERE project_id=?",(pid,))})
                return self.send_json({"错误":"接口不存在"},404)
            except Exception as e: return self.send_json({"错误":str(e)},500)
        return super().do_GET()
    def do_POST(self):
        p=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if p != "/api/upload":
            return self._json_post(p)
        try:
            ctype=self.headers.get("Content-Type","")
            if "multipart/form-data" not in ctype: return self.send_json({"错误":"请选择文件并使用表单上传"},400)
            raw=self.body()
            if len(raw) > MAX_UPLOAD_BYTES + 1024*1024: return self.send_json({"错误":"上传请求超过 26 MB 限制"},413)
            import email
            msg=email.message_from_bytes(b"Content-Type: "+ctype.encode()+b"\r\nMIME-Version: 1.0\r\n\r\n"+raw)
            fields={}
            for part in msg.walk():
                if part.get_content_maintype()=="multipart": continue
                name=part.get_param("name",header="content-disposition")
                filename=part.get_filename(); payload=part.get_payload(decode=True) or b""
                if filename: fields["file"]=(filename,payload)
                elif name: fields[name]=payload.decode("utf-8","replace")
            if "file" not in fields: return self.send_json({"错误":"未收到文件"},400)
            filename,content=fields["file"]
            if len(content)>MAX_UPLOAD_BYTES: return self.send_json({"错误":"单个文件最大支持 25 MB"},413)
            ext=Path(filename).suffix.lower()
            if ext not in ALLOWED_EXTENSIONS: return self.send_json({"错误":"文件格式不支持，仅支持 FASTA、CSV、TSV、JSON、XLSX"},400)
            records,parse_warnings=parse_upload(filename,content)
            project_id=fields.get("project_id") or (rows("SELECT id FROM projects LIMIT 1")[0]["id"])
            if not one("SELECT id FROM projects WHERE id=?",(project_id,)): return self.send_json({"错误":"所属科研项目不存在"},400)
            dataset_id=fields.get("dataset_id","").strip()
            existing=one("SELECT * FROM datasets WHERE id=?",(dataset_id,)) if dataset_id else None
            if dataset_id and not existing: return self.send_json({"错误":"要追加版本的数据集不存在"},404)
            if existing and existing["project_id"] != project_id: return self.send_json({"错误":"不能跨项目更新数据集版本"},400)
            digest=hashlib.sha256(content).hexdigest()
            stored=safe_name(ident("文件")+"_"+Path(filename).name)
            (UPLOAD/stored).write_bytes(content)
            asset_id=ident("文件资产"); dsid=dataset_id or ident("数据集")
            version=(int(existing["version"])+1) if existing else 1
            seen=set(); parsed=[]; valid=0; invalid=0
            error_preview=[]; warning_preview=list(parse_warnings); warning_count=0
            for key,value,meta in records:
                errors,warnings=record_validation(key,value,meta,seen); seen.add(key)
                if errors:
                    invalid += 1
                    error_preview.append(f"记录“{key}”：{'；'.join(errors)}")
                else:
                    valid += 1
                if warnings:
                    warning_count += 1
                    if len(warning_preview) < 100:
                        warning_preview.append(f"记录“{key}”：{'；'.join(warnings)}")
                parts=[]
                if errors: parts.append("错误："+"；".join(errors))
                if warnings: parts.append("提示："+"；".join(warnings))
                parsed.append((key,value,meta,0 if errors else 1,"；".join(parts)))
            note=f"已解析 {len(parsed)} 条；有效 {valid}；异常 {invalid}；含空字段提示 {warning_count} 条（提示不影响有效性）"
            with conn() as c:
                c.execute("INSERT INTO file_assets VALUES(?,?,?,?,?,?,?,?,?,?,?)",(asset_id,project_id,dsid,Path(filename).name,stored,db_asset_path(UPLOAD/stored),len(content),digest,ext[1:].upper(),now(),"已保存"))
                if existing:
                    c.execute("UPDATE datasets SET type=?,filename=?,record_count=?,valid_count=?,invalid_count=?,sha256=?,version=?,updated_at=?,notes=?,description=COALESCE(NULLIF(?,''),description),source_id=COALESCE(NULLIF(?,''),source_id) WHERE id=?",(ext[1:].upper(),stored,len(parsed),valid,invalid,digest,version,now(),note,fields.get("description",""),fields.get("source_id",""),dsid))
                    old_records={r["record_key"]:r["id"] for r in c.execute("SELECT * FROM records WHERE dataset_id=?",(dsid,))}
                    c.execute("DELETE FROM records WHERE dataset_id=?",(dsid,))
                else:
                    c.execute("INSERT INTO datasets(id,project_id,name,type,filename,record_count,valid_count,invalid_count,sha256,version,created_at,notes,description,source_id,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(dsid,project_id,fields.get("name") or Path(filename).stem,ext[1:].upper(),stored,len(parsed),valid,invalid,digest,version,now(),note,fields.get("description",""),fields.get("source_id") or None,now()))
                for key,value,meta,is_valid,issue in parsed:
                    c.execute("INSERT INTO records VALUES(?,?,?,?,?,?,?)",((old_records.pop(key, None) if existing else None) or ident("记录"),dsid,key,value,json.dumps(meta,ensure_ascii=False),is_valid,issue))
            with conn() as c:
                c.execute("DELETE FROM evidence_links WHERE record_id NOT IN (SELECT id FROM records)")
            save_dataset_version(dsid,version,asset_id,parsed,valid,invalid,"首次导入" if version==1 else "重新导入并生成新版本")
            audit("管理员","导入数据集" if version==1 else "创建数据集新版本",dsid,f"{filename}；版本 V{version}；{len(parsed)} 条记录")
            return self.send_json({"id":dsid,"file_asset_id":asset_id,"records":len(parsed),"valid_count":valid,"invalid_count":invalid,"warning_count":warning_count,"issues":error_preview[:200],"warnings":warning_preview[:200],"sha256":digest,"version":version,"stored":stored})
        except Exception as e:
            return self.send_json({"错误":str(e)},400)

    def _json_post(self,p):
        # Re-dispatch JSON endpoints without recursive method override
        raw=self.body()
        try: d=json.loads(raw or b"{}")
        except: d={}
        def respond(obj,status=200): self.send_json(obj,status)
        try:
            if p=="/api/login":
                u=one("SELECT username,role FROM users WHERE username=? AND password=?",(d.get("username"),d.get("password")))
                return respond({"成功":bool(u),"用户":u,"提示":"登录成功" if u else "用户名或密码错误"},200 if u else 401)
            if p=="/api/projects":
                pid=ident("项目")
                with conn() as c:c.execute("INSERT INTO projects VALUES(?,?,?,?,?,?)",(pid,d["name"],d.get("description",""),"管理员",now(),now()))
                audit("管理员","创建项目",pid,d["name"]); return respond({"id":pid})
            if p=="/api/datasets":
                name=d.get("name","").strip(); project_id=d.get("project_id","")
                if not name: return respond({"错误":"数据集名称不能为空"},400)
                if not one("SELECT id FROM projects WHERE id=?",(project_id,)): return respond({"错误":"请选择有效科研项目"},400)
                did=ident("数据集")
                with conn() as c:
                    c.execute("INSERT INTO datasets(id,project_id,name,type,filename,record_count,valid_count,invalid_count,sha256,version,created_at,notes,description,source_id,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(did,project_id,name,d.get("type","未指定"),"",0,0,0,"",1,now(),"",d.get("description",""),d.get("source_id") or None,now()))
                    c.execute("INSERT INTO dataset_versions VALUES(?,?,?,?,?,?,?,?,?,?)",(ident("版本"),did,1,None,0,0,0,"创建空数据集", "[]", now()))
                audit("管理员","创建数据集",did,name); return respond({"id":did})
            if p=="/api/sources":
                sid=ident("来源")
                with conn() as c:c.execute("INSERT INTO sources VALUES(?,?,?,?,?,?)",(sid,d["name"],d.get("source_type","数据库"),d.get("source_url",""),d.get("description",""),now()))
                audit("管理员","新增数据来源",sid,d["name"]); return respond({"id":sid})
            if p=="/api/evidence":
                eid=ident("证据")
                with conn() as c:
                    c.execute("INSERT INTO evidence(id,source_id,title,identifier,url,evidence_type,status,content,notes,created_at,publication_date,source_identifier,tags,conflict_group,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(eid,d.get("source_id") or None,d["title"],d.get("identifier",""),d.get("url",""),d.get("evidence_type","文献"),d.get("status","待核验"),d.get("content",""),d.get("notes",""),now(),d.get("publication_date",""),d.get("source_identifier",d.get("identifier","")),d.get("tags",""),d.get("conflict_group",""),now()))
                    payload=dict(c.execute("SELECT * FROM evidence WHERE id=?",(eid,)).fetchone())
                    c.execute("INSERT INTO evidence_versions VALUES(?,?,?,?,?,?)",(ident("证据版本"),eid,1,json.dumps(payload,ensure_ascii=False),"首次登记",now()))
                audit("管理员","新增证据",eid,d["title"]); return respond({"id":eid,"version":1})
            if p=="/api/evidence/link":
                lid=ident("关联")
                with conn() as c:c.execute("INSERT INTO evidence_links VALUES(?,?,?,?,?)",(lid,d["evidence_id"],d["record_id"],d.get("relation","关联"),now()))
                audit("管理员","建立证据关联",lid,lid); return respond({"id":lid})
            if p=="/api/rules":
                rid=ident("规则")
                with conn() as c:c.execute("UPDATE rules SET active=0"); c.execute("INSERT INTO rules VALUES(?,?,?,?,?,?,?)",(rid,d["name"],d.get("version","1.0"),json.dumps(d.get("configuration",{}),ensure_ascii=False),d.get("description","演示性评价规则"),now(),1))
                audit("管理员","创建评价规则",rid,d["name"]); return respond({"id":rid})
            if p=="/api/evidence/update":
                eid=d.get("id"); old=one("SELECT * FROM evidence WHERE id=?",(eid,))
                if not old:return respond({"错误":"证据不存在"},404)
                fields={k:d.get(k,old.get(k)) for k in ["title","identifier","url","evidence_type","status","content","notes","publication_date","source_identifier","tags","conflict_group"]}
                version=one("SELECT COALESCE(MAX(version),0)+1 n FROM evidence_versions WHERE evidence_id=?",(eid,))["n"]
                with conn() as c:
                    c.execute("UPDATE evidence SET title=?,identifier=?,url=?,evidence_type=?,status=?,content=?,notes=?,publication_date=?,source_identifier=?,tags=?,conflict_group=?,updated_at=? WHERE id=?",(fields["title"],fields["identifier"],fields["url"],fields["evidence_type"],fields["status"],fields["content"],fields["notes"],fields["publication_date"],fields["source_identifier"],fields["tags"],fields["conflict_group"],now(),eid))
                    payload=dict(c.execute("SELECT * FROM evidence WHERE id=?",(eid,)).fetchone())
                    c.execute("INSERT INTO evidence_versions VALUES(?,?,?,?,?,?)",(ident("证据版本"),eid,version,json.dumps(payload,ensure_ascii=False),d.get("change_summary","更新证据元数据"),now()))
                audit("管理员","更新证据并保存版本",eid,f"V{version}");return respond({"ok":True,"version":version})
            if p=="/api/jobs/cancel":
                jid=d.get("id"); job=one("SELECT * FROM jobs WHERE id=?",(jid,))
                if not job:return respond({"错误":"任务不存在"},404)
                if job["status"] in ("SUCCESS","FAILED","CANCELLED"):return respond({"错误":"任务已结束，不能取消"},400)
                with conn() as c:c.execute("UPDATE jobs SET cancel_requested=1,status='CANCELLED',completed_at=?,logs=logs||? WHERE id=?",(now(),"\n用户请求取消任务。",jid))
                audit("管理员","取消任务",jid,"用户主动取消");return respond({"ok":True})
            if p=="/api/report-templates":
                tid=ident("报告模板")
                sections=d.get("sections",["项目基本信息","数据集信息","数据来源","抗原运行记录","抗原候选结果","抗原排序版本","抗原证据线索","关联证据","数据质量与异常记录","人工复核","报告历史","局限性声明"])
                with conn() as c:c.execute("INSERT INTO report_templates VALUES(?,?,?,?,?,?)",(tid,d["name"],d.get("description",""),json.dumps(sections,ensure_ascii=False),now(),now()))
                audit("管理员","创建报告模板",tid,d["name"]); return respond({"id":tid})
            if p.startswith("/api/datasets/"):
                did=p.rsplit("/",1)[-1]; old=one("SELECT * FROM datasets WHERE id=?",(did,))
                if not old: return respond({"错误":"数据集不存在"},404)
                name=d.get("name",old["name"]).strip()
                if not name: return respond({"错误":"数据集名称不能为空"},400)
                with conn() as c: c.execute("UPDATE datasets SET name=?,description=?,source_id=?,updated_at=? WHERE id=?",(name,d.get("description",old.get("description") or ""),d.get("source_id") or None,now(),did))
                audit("管理员","编辑数据集",did,name); return respond({"ok":True})
            return respond({"错误":"接口不存在"},404)
        except Exception as e:return respond({"错误":str(e)},400)
    def do_PUT(self):
        path=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        try:
            d=json.loads(self.body() or b"{}")
            if path.startswith("/api/projects/"):
                pid=path.rsplit("/",1)[-1]; old=one("SELECT * FROM projects WHERE id=?",(pid,))
                if not old: return self.send_json({"错误":"科研项目不存在"},404)
                name=d.get("name",old["name"]).strip()
                if not name: return self.send_json({"错误":"项目名称不能为空"},400)
                with conn() as c: c.execute("UPDATE projects SET name=?,description=?,updated_at=? WHERE id=?",(name,d.get("description",old["description"]),now(),pid))
                audit("管理员","更新项目",pid,name); return self.send_json({"ok":True})
            if path.startswith("/api/datasets/"):
                did=path.rsplit("/",1)[-1]; old=one("SELECT * FROM datasets WHERE id=?",(did,))
                if not old: return self.send_json({"错误":"数据集不存在"},404)
                name=d.get("name",old["name"]).strip()
                if not name: return self.send_json({"错误":"数据集名称不能为空"},400)
                source_id=d.get("source_id") or None
                with conn() as c: c.execute("UPDATE datasets SET name=?,description=?,source_id=?,updated_at=? WHERE id=?",(name,d.get("description",old.get("description") or ""),source_id,now(),did))
                audit("管理员","编辑数据集",did,name); return self.send_json({"ok":True})
            return self.send_json({"错误":"接口不存在"},404)
        except Exception as e: return self.send_json({"错误":str(e)},400)

    def do_DELETE(self):
        path=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if path.startswith("/api/projects/"):
            pid=path.rsplit("/",1)[-1]; project=one("SELECT * FROM projects WHERE id=?",(pid,))
            if not project: return self.send_json({"错误":"科研项目不存在"},404)
            ds_ids=[x["id"] for x in rows("SELECT id FROM datasets WHERE project_id=?",(pid,))]
            assets=rows("SELECT relative_path FROM file_assets WHERE project_id=?",(pid,))
            with conn() as c:
                for did in ds_ids:
                    c.execute("DELETE FROM evidence_links WHERE record_id IN (SELECT id FROM records WHERE dataset_id=?)",(did,))
                    c.execute("DELETE FROM evaluations WHERE record_id IN (SELECT id FROM records WHERE dataset_id=?)",(did,))
                    c.execute("DELETE FROM records WHERE dataset_id=?",(did,))
                c.execute("DELETE FROM dataset_versions WHERE dataset_id IN (SELECT id FROM datasets WHERE project_id=?)",(pid,))
                c.execute("DELETE FROM file_assets WHERE project_id=?",(pid,))
                c.execute("DELETE FROM datasets WHERE project_id=?",(pid,))
                c.execute("DELETE FROM jobs WHERE project_id=?",(pid,))
                c.execute("DELETE FROM snapshots WHERE project_id=?",(pid,))
                c.execute("DELETE FROM reports WHERE project_id=?",(pid,))
                c.execute("DELETE FROM projects WHERE id=?",(pid,))
            for asset in assets:
                target=stored_asset_path(asset["relative_path"])
                if UPLOAD.resolve() in target.parents and target.is_file(): target.unlink()
            audit("管理员","删除科研项目",pid,project["name"]); return self.send_json({"ok":True,"已删除数据集数":len(ds_ids)})
        if path.startswith("/api/datasets/"):
            did=path.rsplit("/",1)[-1]; ds=one("SELECT * FROM datasets WHERE id=?",(did,))
            if not ds: return self.send_json({"错误":"数据集不存在"},404)
            assets=rows("SELECT relative_path FROM file_assets WHERE dataset_id=?",(did,))
            with conn() as c:
                c.execute("DELETE FROM evidence_links WHERE record_id IN (SELECT id FROM records WHERE dataset_id=?)",(did,))
                c.execute("DELETE FROM records WHERE dataset_id=?",(did,))
                c.execute("DELETE FROM dataset_versions WHERE dataset_id=?",(did,))
                c.execute("DELETE FROM file_assets WHERE dataset_id=?",(did,))
                c.execute("DELETE FROM datasets WHERE id=?",(did,))
            for asset in assets:
                target=stored_asset_path(asset["relative_path"])
                if UPLOAD.resolve() in target.parents and target.is_file(): target.unlink()
            audit("管理员","删除数据集",did,ds["name"]); return self.send_json({"ok":True})
        return self.send_json({"错误":"接口不存在"},404)

    def do_GET_download(self,name):
        path=REPORT/name
        if not path.exists(): return self.send_error(404)
        data=path.read_bytes(); self.send_response(200); self.send_header("Content-Type","application/octet-stream"); self.send_header("Content-Disposition","attachment; filename*=UTF-8''"+urllib.parse.quote(path.name)); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET_asset(self,asset_id):
        asset=one("SELECT * FROM file_assets WHERE id=?",(asset_id,))
        if not asset: return self.send_error(404)
        path=stored_asset_path(asset["relative_path"])
        if UPLOAD.resolve() not in path.parents or not path.is_file(): return self.send_error(404)
        data=path.read_bytes(); self.send_response(200); self.send_header("Content-Type","application/octet-stream"); self.send_header("Content-Disposition","attachment; filename*=UTF-8''"+urllib.parse.quote(asset["original_filename"])); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        p=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
        if p.startswith("/download/"): return self.do_GET_download(p.rsplit("/",1)[-1])
        if p.startswith("/asset/"): return self.do_GET_asset(p.rsplit("/",1)[-1])
        return self._get_dispatch()
    def _get_dispatch(self):
        return self.original_get()

init_db()
from extension import install
Handler = install(Handler)
from epitope import install as install_epitope
Handler = install_epitope(Handler)
from ai_decision import install as install_ai
Handler = install_ai(Handler)
class ThreadingServer(socketserver.ThreadingMixIn,http.server.HTTPServer): daemon_threads=True
if __name__=="__main__":
    host="127.0.0.1"; port=int(os.environ.get("EPIWORK_PORT","8765"))
    try:
        server=ThreadingServer((host,port),Handler)
        print(f"Brucella-EpiWork 已启动：http://127.0.0.1:{port}")
        print("按 Ctrl+C 可停止服务。")
        server.serve_forever()
    except OSError as e:
        print("启动失败：端口 8765 可能被占用。",e); input("按回车退出……")







