# API 接口说明

前缀沿用已有项目的 /api/。响应为 JSON 对象或数组；失败状态为 4xx/5xx，包含「错误」字段。此版本未迁移为蓝图建议的 /api/v1 统一包装协议。

登录以外的业务接口需要 epi_session Cookie；浏览器同源请求自动携带。文件和报表下载同样要求登录。所有中文参数与 URL 路径应编码为 UTF-8 URL。

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | /api/health | 运行状态与版本 |
| POST | /api/login、/api/logout、/api/password | 登录、退出、改密码 |
| GET/POST | /api/projects | 项目列表/创建 |
| PUT/DELETE | /api/projects/{编号} | 编辑/删除 |
| GET/POST | /api/datasets | 列表/创建空数据集 |
| POST | /api/upload | multipart 文件导入，字段 file、project_id、name、source_id、dataset_id |
| GET | /api/datasets/search | 关键词、类型、来源、项目过滤 |
| GET | /api/datasets/{编号}/records、versions、files | 当前记录、历史版本、文件资产 |
| PUT/DELETE | /api/datasets/{编号} | 元数据编辑、删除 |
| GET/POST | /api/sources、/api/evidence | 来源/证据列表与创建 |
| POST | /api/sources/update、/api/evidence/update | 修改并保存版本 |
| POST | /api/evidence/link | 证据关联，evidence_id、record_id、relation |
| GET | /api/evidence/versions?evidence_id=编号 | 证据历史 |
| GET | /api/trace-chain?record_id=编号 | 完整追溯链 |
| GET/POST | /api/tools | 工具列表、注册及启停 |
| GET/POST | /api/jobs | 任务列表、提交 |
| GET | /api/jobs/{编号}、/api/job-input/{编号} | 运行详情、输入快照 |
| POST | /api/jobs/cancel、/api/jobs/retry | 传入 id 取消或重运行 |
| GET | /api/normalized | 字段标准化结果 |
| GET/POST | /api/rules | 规则列表、新版本 |
| POST | /api/evaluate | 传入 project_id、rule_id 运行评价 |
| GET | /api/results、/api/reviews | 历史结果、复核记录 |
| POST | /api/review | 传入 evaluation_id、status、notes |
| GET | /api/visualization/summary、/api/network | 图表与网络数据 |
| POST | /api/snapshot | 生成项目不可变归档 |
| GET | /api/snapshots、/api/audit | 快照列表、最近审计 |
| GET/POST | /api/report-templates、/api/reports | 模板和报告 |
| GET | /api/export/dataset/{编号}?format=格式 | 数据集导出 |
| GET | /download/{文件名}、/asset/{资产编号} | 下载报表、原始文件 |

提交任务示例：{"project_id":"实际项目编号","tool_id":"工具-基础质检","params":{},"timeout_seconds":60}。

报告示例：{"project_id":"实际项目编号","format":"pdf","template_id":"可选模板编号"}。

---

# Brucella-EpiWork 3.0 抗原决策接口

新增接口均需登录，前缀为 `/api/epitope/`。

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | `/api/epitope/meta` | 可用适配器、外部适配器状态、权重维度、预设、示例蛋白和方法边界 |
| GET | `/api/epitope/proteins?project_id=编号` | 查询已保存蛋白 |
| POST | `/api/epitope/proteins` | 保存蛋白：project_id、name、accession、organism、sequence |
| GET | `/api/epitope/evidence?q=关键词` | 查询公开证据库 |
| POST | `/api/epitope/evidence` | 登记证据，可提供 protein_pattern、confidence、sequence 等字段 |
| POST | `/api/epitope/analyze` | 运行多适配器分析并生成候选 |
| GET | `/api/epitope/runs?project_id=编号` | 查询历史运行摘要 |
| GET | `/api/epitope/runs/{运行编号}` | 查询运行详情、工具状态和候选 |
| POST | `/api/epitope/runs/{运行编号}/rerank` | 保存新权重版本并更新候选排序 |
| POST | `/api/epitope/select` | 保存某次运行中的候选选择 |
| POST | `/api/epitope/export` | 导出 CSV、FASTA、JSON 或 PDF |

## 分析请求示例

```json
{
  "project_id": "项目编号",
  "protein_name": "BP26 / Omp28",
  "accession": "Q6YA76",
  "organism": "Brucella abortus",
  "sequence": "MNTRASNF...",
  "tools": ["hydrophilicity", "flexibility", "accessibility", "turn"],
  "weights": {
    "coverage": 35,
    "strength": 30,
    "evidence": 20,
    "consistency": 15
  },
  "simulate_failure": "turn"
}
```

`simulate_failure` 可留空，用于演示某个适配器超时后的降级行为。

## 权重重排示例

```json
{"weights": {"coverage": 20, "strength": 20, "evidence": 45, "consistency": 15}}
```

## 导出请求示例

```json
{
  "run_id": "运行编号",
  "candidate_ids": ["候选编号1", "候选编号2"],
  "format": "pdf"
}
```

返回值中的 `download` 为需要登录下载的地址。

## 3.0 领域数据表

| 表 | 含义 |
|---|---|
| epitope_proteins | 项目中的候选蛋白序列与元数据 |
| epitope_runs | 一次分析的固定输入、工具列表、权重、状态和耗时 |
| epitope_candidates | 共识候选、位置、序列、评分因子和选择状态 |
| epitope_rankings | 每次保存的权重重排版本 |
| epitope_evidence | 公开证据、蛋白匹配模式、PMID、链接、置信度与证据层级 |

---

# 3.1.0 跨模块整合接口变更

- 导航移除“工具与任务”和“分析中心”，相关运行能力统一进入抗原决策台。
- `POST /api/epitope/analyze` 新增可选字段：`dataset_id`、`record_id`、`source_id`。
- `GET /api/epitope/runs` 返回 `dataset_name`、`record_key`、`source_name`。
- `GET /api/epitope/runs/{id}` 返回完整来源链和 `output_evidence_id`。
- `POST /api/epitope/evidence` 支持 `source_id`，并同步创建证据中心记录。
- 新增 `GET /api/epitope/visualization/summary?project_id=编号`，返回抗原运行、Top 候选、状态、覆盖和来源分布。
- 项目报告新增章节：`抗原运行记录`、`抗原候选结果`、`抗原排序版本`、`抗原证据线索`。
- 抗原分析完成后自动在证据中心创建“计算结果”证据；若关联数据记录，则自动建立 evidence_link。


---

# 3.2.0 外部工具与项目数据约束

## 分析请求约束

`POST /api/epitope/analyze` 必须来自项目内已有数据：

- `project_id` 必须有效；
- `dataset_id` 必须属于该项目；
- `record_id` 必须属于该数据集；
- `source_id` 必须来自证据中心来源；
- 不允许手工序列、示例序列或独立证据库作为决策台输入。

新增可选字段：

- `external_timeout_seconds`：外部工具最长等待时间，范围 30–600 秒，默认 240。

## 工具编号

本地工具：

- `hydrophilicity`
- `flexibility`
- `accessibility`
- `turn`

外部工具：

- `iedb`
- `bepipred`
- `abcpred`

7 个工具可以在同一次分析中自由组合。

## 外部结果标准化

- IEDB-KT 和 BepiPred 通过 IEDB Analysis Resource Web 表单提交。
- IEDB-KT 为同步结果；BepiPred 为异步作业，需要轮询状态。
- ABCpred 同步提交并解析表格结果。
- 外部工具原始得分先进行工具内归一化，再加入共识评分。
- 工具日志保存服务 URL、作业编号和请求参数。
- 外部服务不可达、超时或失败时，只将该工具标记为 FAILED，主工作流继续。

---

# 3.3.0 AI 决策与评估接口

## 菜单位置

报告中心下方、系统审计上方。

## 接口

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | `/api/ai/meta` | DeepSeek 配置状态、模型、检索来源 |
| POST | `/api/ai/evaluate` | 对已有抗原运行执行联网检索与 AI 评估 |
| GET | `/api/ai/evaluations` | AI 评估历史 |
| GET | `/api/ai/evaluations/{id}` | 单次 AI 评估详情 |

## 评估请求

```json
{"run_id": "运行编号", "focus": "selected_or_top"}
```

可选评估范围：

- `selected_or_top`
- `top10`
- `protein`

## 检索与生成

1. 读取抗原运行、来源链、工具状态、权重和候选；
2. 查询证据中心关联与匹配证据；
3. 查询 UniProt；
4. 查询 Europe PMC；
5. 调用 DeepSeek `deepseek-chat`；
6. 保存上下文、检索结果、引用、模型输出与 token 用量。

## 安全与边界

- API Key 仅保存在后端 `数据/ai_config.json` 或环境变量中；
- 不通过任何前端接口返回 API Key；
- AI 输出只用于解释，不替代湿实验；
- 引用只允许来自输入中的证据中心、UniProt 和 Europe PMC 记录。
