# -*- coding: utf-8 -*-
"""启动本机服务，确认健康后打开浏览器。优先使用随包 Python，无需系统安装。"""
import sys, time, subprocess, urllib.request, json, webbrowser, os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PORT=os.environ.get('EPIWORK_PORT','8765')
URL='http://127.0.0.1:'+PORT
def running_version():
    try:
        with urllib.request.urlopen(URL+'/api/health',timeout=1) as r:return json.load(r).get('版本','')
    except Exception:return ''
version=running_version()
if version=='3.3.0':
    print('3.3.0 项目已在运行，即将打开。');webbrowser.open(URL);raise SystemExit()
if version:
    print(f'检测到端口 {PORT} 正在运行版本 {version}。')
    print('请先关闭旧版启动窗口，或双击本包的“停止项目.bat”，然后重新启动 3.3.0。')
    raise SystemExit()
bundled=ROOT/'runtime'/'python.exe'
python=str(bundled if bundled.exists() else Path(sys.executable))
process=subprocess.Popen([python,str(ROOT/'server.py')],cwd=ROOT)
try:
    for _ in range(100):
        if process.poll() is not None:raise RuntimeError('服务未能启动，请查看上方错误。')
        if running_version()=='3.3.0':webbrowser.open(URL);break
        time.sleep(.15)
    else:raise RuntimeError(f'服务启动超时。请检查端口 {PORT} 是否被占用。')
    print('项目已启动：'+URL)
    print('关闭此窗口或按 Ctrl+C 停止服务。报告及任务结果位于：'+str(ROOT/'数据'/'报告'))
    process.wait()
except KeyboardInterrupt:pass
finally:
    if process.poll() is None:process.terminate();process.wait()




