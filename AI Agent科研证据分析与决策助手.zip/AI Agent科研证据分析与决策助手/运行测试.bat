@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "runtime\python.exe" (
  "runtime\python.exe" "测试\完整验收.py"
  if errorlevel 1 goto failed
  "runtime\python.exe" "测试\验收_epitope.py"
  if errorlevel 1 goto failed
) else (
  py -3.14 --version >nul 2>nul
  if errorlevel 1 (set PY=python) else (set PY=py -3.14)
  %PY% "测试\完整验收.py"
  if errorlevel 1 goto failed
  %PY% "测试\验收_epitope.py"
  if errorlevel 1 goto failed
)
echo.
echo 全部验收通过。
pause
exit /b 0
:failed
echo.
echo 验收未通过，请查看上方输出。
pause
exit /b 1
