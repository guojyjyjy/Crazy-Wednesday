# -*- coding: utf-8 -*-
"""Brucella-EpiWork 3.0 领域增强：多源表位证据整合与候选优先级决策。

设计边界：
1. 内部适配器是透明、可复现的启发式基线，不冒充任何已发表训练模型；
2. 外部工具可通过统一适配器协议接入，未配置时明确标记而不是伪造结果；
3. 共识评分是决策辅助启发式，不构成保护性、诊断或疫苗有效性的结论。
"""
import sys, json, math, re, time, csv, io, urllib.parse, urllib.request, urllib.error, http.cookiejar, statistics, html as html_lib
from concurrent.futures import ThreadPoolExecutor, as_completed
from report_pdf import build_pdf

APP_VERSION = "3.3.0"

TOOL_CATALOG = {
    "hydrophilicity": {
        "name": "HP-Window", "version": "1.0-local", "mode": "internal",
        "color": "#2f6fed",
        "description": "Kyte-Doolittle 亲水性滑窗；窗口 9 aa，取序列内相对高分区域。",
        "warning": "相对排序分数，不是校准概率。"
    },
    "flexibility": {
        "name": "Flex-Window", "version": "1.0-local", "mode": "internal",
        "color": "#13a38b",
        "description": "Karplus-Schulz 柔性残基倾向滑窗；窗口 9 aa。",
        "warning": "用于产生可解释的候选区域，不等于实验验证的柔性。"
    },
    "accessibility": {
        "name": "Surface-Window", "version": "1.0-local", "mode": "internal",
        "color": "#e09a2d",
        "description": "Emini 表面可及性倾向滑窗；窗口 9 aa。",
        "warning": "基于残基倾向的近似指标，未进行三维结构校正。"
    },
    "turn": {
        "name": "Turn-Window", "version": "1.0-local", "mode": "internal",
        "color": "#b86bd9",
        "description": "Chou-Fasman β-转角倾向滑窗；窗口 7 aa。",
        "warning": "仅捕捉转角倾向，不覆盖构象表位。"
    },
    "iedb": {
        "name": "IEDB-KT", "version": "IEDB-web", "mode": "external",
        "color": "#e25757",
        "description": "IEDB Analysis Resource 的 Kolaskar-Tongaonkar 抗原性预测服务。",
        "warning": "依赖外部网络与 IEDB 服务可用性；结果随服务版本变化。"
    },
    "bepipred": {
        "name": "BepiPred 2.0", "version": "IEDB-web", "mode": "external",
        "color": "#3478c7",
        "description": "通过 IEDB Analysis Resource 调用 BepiPred 2.0 线性表位预测。",
        "warning": "外部服务；单序列最长 250 aa，依赖网络与 IEDB 队列。"
    },
    "abcpred": {
        "name": "ABCpred", "version": "Raghava-web", "mode": "external",
        "color": "#d17a22",
        "description": "Raghava 团队 ABCpred 循环神经网络 B 细胞表位预测服务。",
        "warning": "依赖外部网络；默认窗口 16 aa，阈值 0.51。"
    }
}

EXTERNAL_ADAPTERS = [
    {"id": "iedb", "name": "IEDB Analysis Resource", "version": "IEDB-web", "status": "已接入",
     "description": "已接入 IEDB Web 预测服务，使用 Kolaskar-Tongaonkar 抗原性方法。"},
    {"id": "bepipred", "name": "BepiPred 2.0", "version": "IEDB-web", "status": "已接入",
     "description": "已通过 IEDB Analysis Resource 接入 BepiPred 2.0 线性表位预测。"},
    {"id": "abcpred", "name": "ABCpred", "version": "Raghava-web", "status": "已接入",
     "description": "已接入 Raghava 团队 ABCpred Web 服务，窗口 16 aa、阈值 0.51。"}
]

DIMENSIONS = [
    {"id": "coverage", "name": "工具覆盖", "description": "支持该候选的已选工具比例。", "default": 35, "color": "#2f6fed"},
    {"id": "strength", "name": "证据强度", "description": "支持工具归一化得分的均值。", "default": 30, "color": "#13a38b"},
    {"id": "evidence", "name": "证据线索", "description": "蛋白质/表位与证据中心线索的匹配强度。", "default": 20, "color": "#e09a2d"},
    {"id": "consistency", "name": "跨工具一致性", "description": "支持工具得分越接近，一致性越高。", "default": 15, "color": "#b86bd9"}
]

PRESETS = {
    "balanced": {"name": "均衡", "weights": {"coverage": 35, "strength": 30, "evidence": 20, "consistency": 15}},
    "coverage": {"name": "共识优先", "weights": {"coverage": 50, "strength": 20, "evidence": 20, "consistency": 10}},
    "strength": {"name": "信号优先", "weights": {"coverage": 20, "strength": 50, "evidence": 15, "consistency": 15}},
    "evidence": {"name": "证据优先", "weights": {"coverage": 20, "strength": 20, "evidence": 45, "consistency": 15}}
}

EXAMPLES = [
    {
        "name": "BP26 / Omp28 (Brucella abortus)",
        "accession": "Q6YA76",
        "organism": "Brucella abortus",
        "note": "UniProtKB 公开序列；常用于布鲁氏菌血清学诊断研究的候选抗原。",
        "sequence": "MNTRASNFLAASFSTIMLVGAFSLPAFAQENQMTTQPARIAVTGEGMMTASPDMAILNLSVLRQAKTAREAMTANNEAMTKVLDAMKKAGIEDRDLQTGGINIQPIYVYPDDKNNLKEPTITGYSVSTSLTVRVRELANVGKILDESVTLGVNQGGDLNLVNDNPSAVINEARKRAVANAIAKAKTLADAAGVGLGRVVEISELSRPPMPMPIARGQFRTMLAAAPDNSVPIAAGENSYNVSVNVVFEIK"
    },
    {
        "name": "L7/L12 ribosomal protein (Brucella abortus)",
        "accession": "P0A470",
        "organism": "Brucella abortus",
        "note": "UniProtKB 公开序列；布鲁氏菌疫苗与免疫原性研究中的常见抗原。",
        "sequence": "MADLAKIVEDLSALTVLEAAELSKLLEEKWGVSAAAPVAVAAAGGAAPAAAAEEKTEFDVVLADGGANKINVIKEVRALTGLGLKEAKDLVEGAPKAVKEGASKDEAEKIKAQLEAAGAKVELK"
    },
    {
        "name": "Omp25d (Brucella abortus)",
        "accession": "Q64JB9",
        "organism": "Brucella abortus",
        "note": "UniProtKB 公开序列；用于展示外膜蛋白候选的计算证据汇总流程。",
        "sequence": "MTFKNLLGASLVAVITSTSAYAADAIVAQEPAPIAIAPSFSWAGAYFGGQVGYGWGRAKLENRTNGGTSEFKPNGFIGGLYTGYNFDTGNNFILGLDANVDYNNLKKSRDFITSGNPVQTTGETQLRWSGAVRARAGYAIDRFMPYIAGGVAFGGIKNSLRIGGEESSKSKTQTGWTVGAGIDYAATDNVLLRLEYRYTDYGKKNFGLNDLDTRGSFKTNDIRLGVAYKF"
    }
]

KD = {"A":1.8,"R":-4.5,"N":-3.5,"D":-3.5,"C":2.5,"Q":-3.5,"E":-3.5,"G":-0.4,"H":-3.2,"I":4.5,"L":3.8,
      "K":-3.9,"M":1.9,"F":2.8,"P":-1.6,"S":-0.8,"T":-0.7,"W":-0.9,"Y":-1.3,"V":4.2,"X":0.0,"B":-1.0,"Z":-1.0}
FLEX = {"A":0.984,"R":0.964,"N":1.048,"D":1.068,"C":0.906,"Q":1.037,"E":1.094,"G":1.031,"H":0.950,"I":0.927,
        "L":0.935,"K":1.102,"M":0.952,"F":0.915,"P":1.049,"S":1.046,"T":0.997,"W":0.904,"Y":0.929,"V":0.931,
        "X":1.0,"B":1.0,"Z":1.0}
SURFACE = {"A":0.62,"R":0.95,"N":0.50,"D":0.58,"C":0.70,"Q":0.62,"E":0.74,"G":0.55,"H":0.70,"I":0.40,
           "L":0.42,"K":0.95,"M":0.45,"F":0.34,"P":0.73,"S":0.67,"T":0.69,"W":0.36,"Y":0.48,"V":0.38,
           "X":0.55,"B":0.54,"Z":0.68}
TURN = {"A":0.66,"R":0.95,"N":1.56,"D":1.46,"C":1.19,"Q":0.98,"E":0.74,"G":1.57,"H":0.95,"I":0.47,
        "L":0.59,"K":1.01,"M":0.60,"F":0.60,"P":1.52,"S":1.43,"T":0.96,"W":0.96,"Y":1.14,"V":0.50,
        "X":0.90,"B":1.00,"Z":1.00}

DEFAULT_WEIGHTS = {d["id"]: d["default"] for d in DIMENSIONS}
ALLOWED_AA = set("ACDEFGHIKLMNPQRSTVWYBXZ")


def install(base):
    s = next(sys.modules[cls.__module__] for cls in base.__mro__ if hasattr(sys.modules[cls.__module__], 'conn'))

    def rows(sql, args=()):
        return s.rows(sql, args)

    def one(sql, args=()):
        return s.one(sql, args)

    def dumps(value):
        return json.dumps(value, ensure_ascii=False)

    def init_schema():
        with s.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS epitope_proteins(
                id TEXT PRIMARY KEY, project_id TEXT, name TEXT, accession TEXT, organism TEXT,
                sequence TEXT, length INTEGER, notes TEXT, created_at TEXT, updated_at TEXT,
                dataset_id TEXT, record_id TEXT, source_id TEXT
            );
            CREATE TABLE IF NOT EXISTS epitope_runs(
                id TEXT PRIMARY KEY, project_id TEXT, protein_id TEXT, protein_name TEXT,
                accession TEXT, organism TEXT, sequence TEXT, tools TEXT, weights TEXT,
                status TEXT, tool_logs TEXT, candidate_count INTEGER, elapsed_ms INTEGER,
                parameters TEXT, created_at TEXT, completed_at TEXT,
                dataset_id TEXT, record_id TEXT, source_id TEXT
            );
            CREATE TABLE IF NOT EXISTS epitope_candidates(
                id TEXT PRIMARY KEY, run_id TEXT, rank INTEGER, start_pos INTEGER, end_pos INTEGER,
                sequence TEXT, score REAL, coverage REAL, strength REAL, evidence REAL,
                consistency REAL, support_count INTEGER, total_tools INTEGER,
                support_tools TEXT, tool_scores TEXT, factors TEXT, selected INTEGER DEFAULT 0,
                created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS epitope_rankings(
                id TEXT PRIMARY KEY, run_id TEXT, weights TEXT, ranking TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS epitope_evidence(
                id TEXT PRIMARY KEY, protein_pattern TEXT, title TEXT, evidence_type TEXT,
                relation TEXT, source TEXT, url TEXT, pmid TEXT, summary TEXT,
                confidence REAL, status TEXT, sequence TEXT, created_at TEXT,
                source_id TEXT, linked_evidence_id TEXT
            );
            CREATE TABLE IF NOT EXISTS epitope_output_evidence(
                id TEXT PRIMARY KEY, run_id TEXT, evidence_id TEXT, record_id TEXT, created_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_epitope_proteins_project ON epitope_proteins(project_id);
            CREATE INDEX IF NOT EXISTS idx_epitope_runs_project ON epitope_runs(project_id);
            CREATE INDEX IF NOT EXISTS idx_epitope_candidates_run ON epitope_candidates(run_id);
            """)
            for table, cols in {
                "epitope_proteins": [("dataset_id", "TEXT DEFAULT ''"), ("record_id", "TEXT DEFAULT ''"), ("source_id", "TEXT DEFAULT ''")],
                "epitope_runs": [("dataset_id", "TEXT DEFAULT ''"), ("record_id", "TEXT DEFAULT ''"), ("source_id", "TEXT DEFAULT ''")],
                "epitope_evidence": [("source_id", "TEXT DEFAULT ''"), ("linked_evidence_id", "TEXT DEFAULT ''")]
            }.items():
                existing = {r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}
                for column, definition in cols:
                    if column not in existing:
                        c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def seed_evidence():
        samples = [
            {
                "id": "文献-BP26-42092575", "protein_pattern": "BP26|bp26|Q6YA76|Q7WSA2|Q7WYQ3",
                "title": "A novel indirect ELISA based on BP26 mAb to differentiate Brucella melitensis M5-90BPΔ26 vaccine immunization",
                "evidence_type": "诊断抗原研究", "relation": "支持蛋白层面的免疫原性/诊断价值",
                "source": "Europe PMC / PubMed", "url": "https://europepmc.org/article/MED/42092575",
                "pmid": "42092575", "summary": "BP26 被用于建立间接 ELISA，说明该蛋白具有血清学检测研究基础。此证据支持蛋白候选，不直接证明本条线性表位有效。",
                "confidence": 0.78, "status": "已核验", "sequence": ""
            },
            {
                "id": "文献-OMP25-42645810", "protein_pattern": "OMP25|Omp25|omp25",
                "title": "Application of Outer Membrane Protein Omp25 in Serological Diagnosis of Brucellosis",
                "evidence_type": "诊断抗原研究", "relation": "支持蛋白层面的血清学诊断价值",
                "source": "Europe PMC / PubMed", "url": "https://europepmc.org/article/MED/42645810",
                "pmid": "42645810", "summary": "研究评估 Omp25 在布鲁氏菌病血清学诊断中的应用。该证据只提高同源蛋白候选的先验证据分，不替代表位级验证。",
                "confidence": 0.72, "status": "已核验", "sequence": ""
            },
            {
                "id": "文献-OMP19-L7L12-41218729", "protein_pattern": "OMP19|Omp19|omp19|L7/L12|bL12|P0A470|B2S688|Q2YM14",
                "title": "Successful prophylactic against Brucella melitensis using a vaccine candidate consisting of recombinant antigens OMP19 and L7/L12",
                "evidence_type": "疫苗免疫原性研究", "relation": "支持蛋白层面的免疫原性",
                "source": "Europe PMC / PubMed", "url": "https://europepmc.org/article/MED/41218729",
                "pmid": "41218729", "summary": "重组 OMP19 与 L7/L12 联合纳米脂质体佐剂在小鼠模型中开展疫苗候选研究。属于蛋白级证据，不等同于线性 B 细胞表位证据。",
                "confidence": 0.70, "status": "已核验", "sequence": ""
            },
            {
                "id": "文献-OMP16-42916073", "protein_pattern": "OMP16|Omp16|omp16",
                "title": "The BP26-OMP16Es Nanoparticle Vaccine Elicits Protective Immunity against Brucella",
                "evidence_type": "疫苗免疫原性研究", "relation": "支持蛋白层面的免疫原性",
                "source": "Europe PMC / PubMed", "url": "https://europepmc.org/article/MED/42916073",
                "pmid": "42916073", "summary": "BP26-OMP16 纳米颗粒疫苗研究提示 OMP16 具有免疫原性研究价值；仍需表位级和实验级确认。",
                "confidence": 0.68, "status": "已核验", "sequence": ""
            }
        ]
        with s.conn() as c:
            source_id = "来源-EuropePMC"
            c.execute("INSERT OR IGNORE INTO sources VALUES(?,?,?,?,?,?)", (
                source_id, "Europe PMC / PubMed", "公开文献数据库", "https://europepmc.org/",
                "EpiWork 公开证据库同步来源", s.now()
            ))
            for e in samples:
                linked_id = "证据-" + e["id"].replace("文献-", "")
                c.execute("INSERT OR IGNORE INTO evidence(id,source_id,title,identifier,url,evidence_type,status,content,notes,created_at,publication_date,source_identifier,tags,conflict_group,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    linked_id, source_id, e["title"], e["pmid"], e["url"], e["evidence_type"], e["status"],
                    e["summary"], "由 EpiWork 3.1 公开证据库同步登记；蛋白级证据不等同于表位级验证。",
                    s.now(), "", e["pmid"], "EpiWork;抗原证据;公开文献", "", s.now()
                ))
                payload = c.execute("SELECT * FROM evidence WHERE id=?", (linked_id,)).fetchone()
                if not c.execute("SELECT 1 FROM evidence_versions WHERE evidence_id=? LIMIT 1", (linked_id,)).fetchone():
                    c.execute("INSERT INTO evidence_versions VALUES(?,?,?,?,?,?)", (
                        s.ident("证据版本"), linked_id, 1, dumps(dict(payload)), "EpiWork 公开证据库首次同步", s.now()
                    ))
                c.execute("INSERT OR IGNORE INTO epitope_evidence(id,protein_pattern,title,evidence_type,relation,source,url,pmid,summary,confidence,status,sequence,created_at,source_id,linked_evidence_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    e["id"], e["protein_pattern"], e["title"], e["evidence_type"], e["relation"],
                    e["source"], e["url"], e["pmid"], e["summary"], e["confidence"], e["status"],
                    e["sequence"], s.now(), source_id, linked_id
                ))
                c.execute("UPDATE epitope_evidence SET source_id=?, linked_evidence_id=? WHERE id=?", (source_id, linked_id, e["id"]))

    init_schema()
    seed_evidence()

    def normalize_sequence(raw):
        text = str(raw or "").strip()
        lines = text.splitlines()
        header = ""
        if lines and lines[0].startswith(">"):
            header = lines[0][1:].strip()
            text = "".join(lines[1:])
        seq = re.sub(r"\s+", "", text).upper().rstrip("*")
        if not seq:
            raise ValueError("蛋白质序列不能为空")
        if len(seq) < 20:
            raise ValueError("蛋白质序列至少需要 20 个氨基酸")
        if len(seq) > 5000:
            raise ValueError("单次分析序列最长 5000 aa")
        bad = sorted(set(seq) - ALLOWED_AA)
        if bad:
            raise ValueError("序列包含非法字符：" + "、".join(bad[:10]))
        return seq, header

    def normalize_weights(raw):
        raw = raw if isinstance(raw, dict) else {}
        weights = {}
        for d in DIMENSIONS:
            try:
                value = float(raw.get(d["id"], DEFAULT_WEIGHTS[d["id"]]))
            except Exception:
                value = DEFAULT_WEIGHTS[d["id"]]
            if not math.isfinite(value) or value < 0 or value > 100:
                raise ValueError(f"{d['name']}权重必须在 0 到 100 之间")
            weights[d["id"]] = round(value, 2)
        if sum(weights.values()) <= 0:
            raise ValueError("至少一个评分维度权重大于 0")
        return weights

    def score_candidate(factors, weights):
        total = sum(weights.values())
        return round(100.0 * sum(factors.get(k, 0.0) * weights[k] for k in weights) / total, 2)

    def rank_candidates(cands, weights):
        ranked = []
        for c in cands:
            item = dict(c)
            item["score"] = score_candidate(item.get("factors", {}), weights)
            item["selected"] = bool(item.get("selected"))
            ranked.append(item)
        ranked.sort(key=lambda x: (-x["score"], x["start"], -(x.get("support_count") or 0)))
        for idx, item in enumerate(ranked, 1):
            item["rank"] = idx
        return ranked

    def sliding_regions(seq, scale, window, threshold_quantile=0.76):
        n = len(seq)
        if n < window:
            return []
        values = [float(scale.get(aa, 0.0)) for aa in seq]
        raw_windows = []
        for start in range(0, n - window + 1):
            raw = sum(values[start:start + window]) / window
            raw_windows.append({"start": start, "end": start + window, "raw": raw})
        lo = min(x["raw"] for x in raw_windows)
        hi = max(x["raw"] for x in raw_windows)
        for x in raw_windows:
            x["score"] = 0.5 if hi - lo < 1e-12 else (x["raw"] - lo) / (hi - lo)
        ordered = sorted(x["score"] for x in raw_windows)
        cutoff = ordered[min(len(ordered) - 1, int(len(ordered) * threshold_quantile))]
        hits = [x for x in raw_windows if x["score"] >= cutoff]
        merged = []
        for h in hits:
            if not merged or h["start"] > merged[-1]["end"]:
                merged.append({"start": h["start"], "end": h["end"], "scores": [h["score"]]})
            else:
                merged[-1]["end"] = max(merged[-1]["end"], h["end"])
                merged[-1]["scores"].append(h["score"])
        regions = []
        for m in merged:
            regions.append({
                "start": m["start"], "end": m["end"],
                "score": round(max(m["scores"]), 4),
                "mean_score": round(statistics.mean(m["scores"]), 4),
                "window_count": len(m["scores"])
            })
        regions.sort(key=lambda x: (-x["score"], x["start"]))
        return regions[:16]

    def _multipart(fields):
        boundary = "----EpiWorkBoundary" + s.ident("").replace("-", "")[:16]
        chunks = []
        for key, value in fields.items():
            chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n{value}\r\n")
        chunks.append(f"--{boundary}--\r\n")
        return "".join(chunks).encode("utf-8"), "multipart/form-data; boundary=" + boundary

    def _strip_html(value):
        return html_lib.unescape(re.sub(r"<[^>]+>", " ", value or "")).strip()

    def _parse_iedb_regions(page):
        regions = []
        residue_scores = {}
        cursor_peptides = page.find("Predicted peptides")
        cursor_residue = page.find("Predicted residue scores")
        end = cursor_residue if cursor_residue >= 0 else min(len(page), cursor_peptides + 12000)
        segment = page[cursor_peptides:end] if cursor_peptides >= 0 else ""
        for row in re.split(r"<tr[^>]*>", segment, flags=re.I)[1:]:
            cells = [_strip_html(x) for x in re.split(r"<td[^>]*>", row, flags=re.I)[1:]]
            if len(cells) >= 5 and cells[0].isdigit() and cells[1].isdigit() and cells[2].isdigit():
                try:
                    start, finish = int(cells[1]), int(cells[2])
                    peptide = cells[3].replace(" ", "").upper()
                    regions.append({"start": start - 1, "end": finish, "score": 0.5,
                                    "mean_score": 0.5, "window_count": 1, "peptide": peptide})
                except Exception:
                    continue
        if cursor_residue >= 0:
            residue_segment = page[cursor_residue:cursor_residue + 120000]
            for row in re.findall(r"<tr[^>]*>(.*?)</tr>", residue_segment, re.I | re.S):
                cells = [_strip_html(x) for x in re.split(r"<td[^>]*>", row, flags=re.I)[1:]]
                if len(cells) >= 4 and cells[0].isdigit():
                    try:
                        residue_scores[int(cells[0])] = (float(cells[2]), cells[3])
                    except Exception:
                        continue
            for region in regions:
                values = [residue_scores[p][0] for p in range(region["start"], region["end"] + 1) if p in residue_scores]
                if values:
                    region["score"] = round(max(values), 4)
                    region["mean_score"] = round(sum(values) / len(values), 4)
                    region["window_count"] = len(values)
            if not regions:
                positions = [p for p, (_, assignment) in residue_scores.items() if assignment.upper().startswith("E")]
                if positions:
                    start = prev = positions[0]
                    for pos in positions[1:] + [None]:
                        if pos is None or pos > prev + 1:
                            values = [residue_scores[p][0] for p in range(start, prev + 1) if p in residue_scores]
                            regions.append({"start": start, "end": prev + 1,
                                            "score": round(max(values or [0.5]), 4),
                                            "mean_score": round(sum(values) / len(values), 4) if values else 0.5,
                                            "window_count": len(values)})
                            if pos is None:
                                break
                            start = pos
                        prev = pos
        regions.sort(key=lambda x: (-x["score"], x["start"]))
        return regions[:20]

    def _run_iedb_web(seq, method, timeout_seconds):
        base = "https://tools.iedb.org/bcell/"
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        opener.addheaders = [("User-Agent", "Mozilla/5.0 EpiWork/3.2"), ("Referer", base)]
        page = opener.open(base, timeout=max(10, min(60, timeout_seconds))).read().decode("utf-8", "replace")
        token_match = re.search(r'name="csrfmiddlewaretoken" value="([^"]+)"', page)
        if not token_match:
            raise RuntimeError("IEDB 页面未返回 CSRF token")
        fields = {
            "csrfmiddlewaretoken": token_match.group(1), "pred_tool": "bcell", "source": "html",
            "form_name": "submission_form", "swissprot": "", "sequence_text": seq,
            "method": method, "email_address": "", "submit": "Submit"
        }
        raw, content_type = _multipart(fields)
        request = urllib.request.Request(base, data=raw, headers={"Content-Type": content_type, "Referer": base})
        response = opener.open(request, timeout=max(20, min(120, timeout_seconds)))
        status_page = response.read().decode("utf-8", "replace")
        if "/result/" in response.geturl() or "B Cell Result" in status_page:
            regions = _parse_iedb_regions(status_page)
            return regions, {"service_url": base, "service_job_id": "", "request_method": method,
                             "response_mode": "synchronous"}
        job_match = re.search(r"/status/([a-f0-9-]+)/", response.geturl(), re.I) or re.search(r'jobId\s*=\s*"([a-f0-9-]+)"', status_page, re.I)
        if not job_match:
            raise RuntimeError("IEDB 未返回作业编号")
        job_id = job_match.group(1)
        deadline = time.monotonic() + timeout_seconds
        status = "running"
        while time.monotonic() < deadline:
            time.sleep(2.0)
            status_url = base + "check_status/" + job_id + "/"
            status_data = json.loads(opener.open(status_url, timeout=30).read().decode("utf-8", "replace"))
            status = str(status_data.get("status") or "").lower()
            if status == "completed":
                break
            if status == "failed":
                raise RuntimeError(status_data.get("error_message") or "IEDB 预测作业失败")
        if status != "completed":
            raise TimeoutError("IEDB 外部服务等待超时")
        result_page = opener.open(base + "result/" + job_id + "/", timeout=60).read().decode("utf-8", "replace")
        regions = _parse_iedb_regions(result_page)
        return regions, {"service_url": base, "service_job_id": job_id, "request_method": method}

    def _run_abcpred_web(seq, timeout_seconds):
        base = "https://webs.iiitd.edu.in/cgibin/abcpred/test1_main.pl"
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        opener.addheaders = [("User-Agent", "Mozilla/5.0 EpiWork/3.2")]
        raw, content_type = _multipart({"SEQNAME": "EpiWork", "SEQ": seq, "Threshold": "0.51", "window": "16", "filter": "on"})
        request = urllib.request.Request(base, data=raw, headers={"Content-Type": content_type,
                                                                   "Referer": "https://webs.iiitd.edu.in/raghava/abcpred/ABC_submission.html"})
        page = opener.open(request, timeout=max(30, min(180, timeout_seconds))).read().decode("utf-8", "replace")
        start = page.find("TABULAR RESULT")
        end = page.find("OVERLAP DISPLAY")
        segment = page[start:end if end > start else len(page)]
        regions = []
        for row in re.split(r"<tr[^>]*>", segment, flags=re.I)[1:]:
            cells = [_strip_html(x) for x in re.split(r"<td[^>]*>", row, flags=re.I)[1:]]
            if len(cells) >= 4 and cells[2].isdigit():
                try:
                    peptide = cells[1].replace(" ", "").upper()
                    start_pos = int(cells[2])
                    score = float(cells[3])
                    regions.append({"start": start_pos - 1, "end": start_pos - 1 + len(peptide),
                                    "score": round(score, 4), "mean_score": round(score, 4),
                                    "window_count": 1, "peptide": peptide})
                except Exception:
                    continue
        regions.sort(key=lambda x: (-x["score"], x["start"]))
        return regions[:20], {"service_url": "https://webs.iiitd.edu.in/raghava/abcpred/",
                              "service_job_id": "", "request_method": "window=16;threshold=0.51"}
    def execute_tool(tool_id, seq, simulate_failure="", external_timeout=240):
        started = time.perf_counter()
        config = TOOL_CATALOG[tool_id]
        if simulate_failure == tool_id:
            raise TimeoutError("演示故障：适配器超时，工作流已降级")
        metadata = {}
        if tool_id == "hydrophilicity":
            regions = sliding_regions(seq, {k: -v for k, v in KD.items()}, 9)
        elif tool_id == "flexibility":
            regions = sliding_regions(seq, FLEX, 9)
        elif tool_id == "accessibility":
            regions = sliding_regions(seq, SURFACE, 9)
        elif tool_id == "turn":
            regions = sliding_regions(seq, TURN, 7)
        elif tool_id == "iedb":
            regions, metadata = _run_iedb_web(seq, "Kolaskar-Tongaonkar", external_timeout)
        elif tool_id == "bepipred":
            if len(seq) > 250:
                raise ValueError("BepiPred 2.0 外部服务单序列最长支持 250 aa")
            regions, metadata = _run_iedb_web(seq, "Bepipred2", external_timeout)
        elif tool_id == "abcpred":
            regions, metadata = _run_abcpred_web(seq, external_timeout)
        else:
            raise ValueError("未知工具")
        if config["mode"] == "external" and regions:
            max_raw = max(float(r.get("score") or 0) for r in regions)
            if max_raw > 1:
                for r in regions:
                    r["raw_score"] = round(float(r.get("score") or 0), 4)
                    r["score"] = round(float(r.get("score") or 0) / max_raw, 4)
                    r["mean_score"] = round(float(r.get("mean_score") or 0) / max_raw, 4)
        elapsed = round((time.perf_counter() - started) * 1000, 2)
        warnings = []
        if not regions:
            warnings.append("外部服务未返回超过阈值的候选区域，结果为空。" if config["mode"] == "external" else "序列长度不足或未产生超过阈值的区域，结果为空。")
        warnings.append(config["warning"])
        if metadata.get("service_url"):
            warnings.append("外部服务：" + metadata["service_url"])
        return {
            "id": tool_id, "name": config["name"], "version": config["version"], "mode": config["mode"],
            "status": "SUCCESS" if regions else "EMPTY", "duration_ms": elapsed,
            "regions": regions, "warnings": warnings, "error": "", "service": metadata
        }

    def overlap(a_start, a_end, b_start, b_end):
        return max(0, min(a_end, b_end) - max(a_start, b_start))

    def evidence_for(protein_name, accession, candidate_seq, evidence_rows):
        haystack = f"{protein_name or ''} {accession or ''}".lower()
        matched = []
        best = 0.0
        for e in evidence_rows:
            pattern = str(e.get("protein_pattern") or "").strip()
            protein_match = False
            if pattern:
                for token in re.split(r"[|,;\s]+", pattern):
                    if token and token.lower() in haystack:
                        protein_match = True
                        break
            sequence_match = bool(e.get("sequence") and str(e["sequence"]).upper() in candidate_seq.upper())
            if not protein_match and not sequence_match:
                continue
            confidence = max(0.0, min(1.0, float(e.get("confidence") or 0)))
            level = "表位序列匹配" if sequence_match else "蛋白级证据"
            value = min(1.0, confidence + (0.12 if sequence_match else 0.0))
            best = max(best, value)
            matched.append({"id": e["id"], "title": e["title"], "relation": e["relation"], "level": level,
                            "confidence": round(value, 3), "url": e.get("url") or "", "pmid": e.get("pmid") or ""})
        matched.sort(key=lambda x: -x["confidence"])
        return round(best, 4), matched

    def build_candidates(run_id, seq, tools, evidence_rows):
        regions = []
        for tool in tools:
            if tool["status"] not in ("SUCCESS", "EMPTY"):
                continue
            for r in tool.get("regions", []):
                regions.append({"tool": tool["id"], "start": r["start"], "end": r["end"],
                                "score": float(r["score"]), "mean_score": float(r["mean_score"])})
        if not regions:
            return []
        regions.sort(key=lambda x: (x["start"], x["end"], -x["score"]))
        clusters = []
        for r in regions:
            if not clusters or r["start"] >= clusters[-1]["end"]:
                clusters.append({"start": r["start"], "end": r["end"], "regions": [r]})
            else:
                clusters[-1]["end"] = max(clusters[-1]["end"], r["end"])
                clusters[-1]["regions"].append(r)
        segments = []
        for cluster in clusters:
            cstart, cend = cluster["start"], cluster["end"]
            length = cend - cstart
            if length <= 24:
                segments.append((cstart, cend))
                continue
            # 将跨工具重叠形成的大区间拆成最多 24 aa 的候选窗口，便于直接用于融合蛋白设计。
            for st in range(cstart, cend, 14):
                en = min(st + 24, cend)
                if en - st >= 8:
                    segments.append((st, en))
                if en >= cend:
                    break
        candidates = []
        for start, end in segments:
            if end - start < 5:
                continue
            candidate_seq = seq[start:end]
            support = {}
            for tool in tools:
                if tool["status"] not in ("SUCCESS", "EMPTY"):
                    continue
                overlaps = []
                for r in tool.get("regions", []):
                    ov = overlap(start, end, r["start"], r["end"])
                    if ov >= max(3, int(min(end - start, r["end"] - r["start"]) * 0.30)):
                        overlaps.append((ov, float(r["score"])))
                if overlaps:
                    best_overlap = max(overlaps, key=lambda x: (x[0], x[1]))
                    support[tool["id"]] = {
                        "name": tool["name"], "color": TOOL_CATALOG[tool["id"]]["color"],
                        "score": round(best_overlap[1], 4), "overlap": best_overlap[0]
                    }
            if not support:
                continue
            scores = [v["score"] for v in support.values()]
            coverage = len(support) / max(1, len(tools))
            strength = statistics.mean(scores)
            consistency = 0.45 if len(scores) == 1 else max(0.0, 1.0 - (max(scores) - min(scores)))
            evidence_score, matched_evidence = evidence_for("", "", candidate_seq, evidence_rows)
            factors = {
                "coverage": round(coverage, 4), "strength": round(strength, 4),
                "evidence": round(evidence_score, 4), "consistency": round(consistency, 4)
            }
            support_names = [v["name"] for v in support.values()]
            candidates.append({
                "id": s.ident("候选"), "run_id": run_id, "rank": 0,
                "start": start + 1, "end": end, "sequence": candidate_seq,
                "length": len(candidate_seq), "score": 0,
                "coverage": factors["coverage"], "strength": factors["strength"],
                "evidence": factors["evidence"], "consistency": factors["consistency"],
                "support_count": len(support), "total_tools": len(tools),
                "support_tools": support_names, "tool_scores": support,
                "factors": factors, "evidence_items": matched_evidence,
                "selected": False,
                "note": f"{len(support)}/{len(tools)} 个工具支持；" + ("存在跨工具得分分歧。" if consistency < 0.55 and len(scores) > 1 else "工具间无明显方向冲突。")
            })
        if not candidates and len(seq) >= 5:
            factors = {"coverage": 0.0, "strength": 0.0, "evidence": 0.0, "consistency": 0.0}
            candidates.append({
                "id": s.ident("候选"), "run_id": run_id, "rank": 0, "start": 1, "end": len(seq),
                "sequence": seq, "length": len(seq), "score": 0,
                "coverage": 0.0, "strength": 0.0, "evidence": 0.0, "consistency": 0.0,
                "support_count": 0, "total_tools": len(tools), "support_tools": [],
                "tool_scores": {}, "factors": factors, "evidence_items": [], "selected": False,
                "note": "工具未产生可用区域，系统保留整段序列供人工核查（降级结果）。"
            })
        return candidates

    def run_detail(run_id):
        run = one("SELECT * FROM epitope_runs WHERE id=?", (run_id,))
        if not run:
            raise ValueError("分析运行不存在")
        provenance = one("""SELECT d.name dataset_name,r.record_key,s.name source_name
                            FROM epitope_runs er
                            LEFT JOIN datasets d ON d.id=er.dataset_id
                            LEFT JOIN records r ON r.id=er.record_id
                            LEFT JOIN sources s ON s.id=er.source_id
                            WHERE er.id=?""", (run_id,)) or {}
        run.update(provenance)
        output = one("SELECT evidence_id FROM epitope_output_evidence WHERE run_id=? ORDER BY created_at DESC LIMIT 1", (run_id,))
        run["output_evidence_id"] = output["evidence_id"] if output else ""
        run["tools"] = json.loads(run.get("tools") or "[]")
        run["weights"] = json.loads(run.get("weights") or "{}")
        run["tool_logs"] = json.loads(run.get("tool_logs") or "[]")
        run["parameters"] = json.loads(run.get("parameters") or "{}")
        cands = rows("SELECT * FROM epitope_candidates WHERE run_id=? ORDER BY rank,start_pos", (run_id,))
        evidence_rows = rows("""SELECT ee.*,e.title evidence_center_title,e.status evidence_center_status,src.name source_name FROM epitope_evidence ee JOIN evidence e ON e.id=ee.linked_evidence_id LEFT JOIN sources src ON src.id=ee.source_id ORDER BY ee.confidence DESC""")
        for c in cands:
            c["support_tools"] = json.loads(c.get("support_tools") or "[]")
            c["tool_scores"] = json.loads(c.get("tool_scores") or "{}")
            c["factors"] = json.loads(c.get("factors") or "{}")
            c["selected"] = bool(c.get("selected"))
            c["length"] = (c.get("end_pos") or 0) - (c.get("start_pos") or 0) + 1
            c["start"], c["end"] = c.get("start_pos"), c.get("end_pos")
            _, ev_items = evidence_for(run.get("protein_name"), run.get("accession"), c.get("sequence", ""), evidence_rows)
            c["evidence_items"] = ev_items
        run["candidates"] = cands
        run["run_id"] = run["id"]
        return run

    def report_sections(run, candidates):
        weights_text = "；".join(f"{d['name']}={run['weights'].get(d['id'], 0)}" for d in DIMENSIONS)
        tool_text = "\n".join(
            f"{x['name']} {x['version']}：{x['status']}，区域 {len(x.get('regions', []))} 个，耗时 {x['duration_ms']} ms"
            + (f"，错误：{x['error']}" if x.get("error") else "")
            for x in run["tool_logs"]
        )
        candidate_text = "\n\n".join(
            f"{i}. {c['start']}-{c['end']} | {c['sequence']}\n"
            f"   共识分 {c['score']:.2f}；覆盖 {c['support_count']}/{c['total_tools']}；"
            f"强度 {c['strength']:.3f}；证据 {c['evidence']:.3f}；一致性 {c['consistency']:.3f}\n"
            f"   支持工具：{'、'.join(c['support_tools']) or '无'}"
            for i, c in enumerate(candidates, 1)
        )
        return {
            "1. 项目与蛋白": f"项目编号：{run['project_id']}\n蛋白名称：{run['protein_name']}\n"
                         f"Accession：{run.get('accession') or '未填写'}\n物种：{run.get('organism') or '未填写'}\n"
                         f"序列长度：{len(run['sequence'])} aa\n运行编号：{run['id']}\n生成时间：{s.now()}",
            "2. 决策任务": "本报告用于比较多个计算证据源产生的候选区域，辅助决定优先合成与验证的表位候选；不预测实验必然成功。",
            "3. 工具编排与容错": tool_text,
            "4. 评分参数": weights_text + "\n评分公式：100 × Σ(维度值 × 权重) / Σ权重。各维度均归一化到 0–1。",
            "5. 候选清单": candidate_text or "本次未产生候选。",
            "6. 证据说明": "证据线索来自证据中心，主要提供蛋白级研究线索；蛋白级证据不能替代表位级免疫学验证。",
            "7. 方法与边界": "内部工具为透明启发式滑窗适配器，不是 ABCpred、BepiPred 等训练模型的复刻，也不输出校准概率。外部工具接口保留标准化接入位点，未配置时不伪造结果。",
            "8. 局限性声明": "本报告是计算决策辅助材料，不产生新的湿实验数据，不构成诊断、疫苗设计或保护性结论。最终候选须经合成、免疫原性、交叉反应与临床/动物实验验证。"
        }

    def save_export(run, candidates, fmt):
        base = f"EpiWork候选报告_{run['protein_name'].replace('/', '_')}_{run['id']}"
        if fmt == "csv":
            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow(["run_id", "rank", "candidate_id", "protein", "accession", "start", "end", "sequence",
                        "length", "consensus_score", "coverage", "strength", "evidence", "consistency",
                        "support_count", "total_tools", "support_tools", "weights", "created_at"])
            for c in candidates:
                w.writerow([run["id"], c["rank"], c["id"], run["protein_name"], run.get("accession") or "",
                            c["start"], c["end"], c["sequence"], c["length"], c["score"], c["coverage"],
                            c["strength"], c["evidence"], c["consistency"], c["support_count"],
                            c["total_tools"], "|".join(c["support_tools"]), dumps(run["weights"]), s.now()])
            data = ("﻿" + buf.getvalue()).encode("utf-8")
            filename = base + ".csv"
        elif fmt == "fasta":
            lines = []
            for c in candidates:
                header = (f">EpiWork|{c['id']}|{run['protein_name']}|{run.get('accession') or 'NA'}|"
                          f"pos={c['start']}-{c['end']}|score={c['score']:.2f}|tools={len(c['support_tools'])}")
                lines.extend([header, c["sequence"]])
            data = ("\n".join(lines) + "\n").encode("utf-8")
            filename = base + ".fasta"
        elif fmt == "json":
            payload = {"run": {k: v for k, v in run.items() if k != "candidates"}, "candidates": candidates}
            data = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
            filename = base + ".json"
        elif fmt == "pdf":
            data = build_pdf("布病多表位抗原候选决策报告", report_sections(run, candidates))
            filename = base + ".pdf"
        else:
            raise ValueError("导出格式仅支持 csv、fasta、json、pdf")
        path = s.REPORT / filename
        path.write_bytes(data)
        rid = s.ident("报告")
        with s.conn() as c:
            c.execute("INSERT INTO reports VALUES(?,?,?,?,?,?)", (rid, run["project_id"], path.stem, fmt, str(path.relative_to(s.BASE)), s.now()))
        return {"id": rid, "filename": filename, "download": "/download/" + urllib.parse.quote(filename), "format": fmt}

    def resolve_provenance(d, project_id):
        dataset_id = str(d.get("dataset_id") or "").strip()
        record_id = str(d.get("record_id") or "").strip()
        source_id = str(d.get("source_id") or "").strip()
        dataset = None
        record = None
        if record_id:
            record = one("""SELECT r.id,r.record_key,r.dataset_id,d.name dataset_name,d.source_id,d.project_id
                            FROM records r JOIN datasets d ON d.id=r.dataset_id WHERE r.id=?""", (record_id,))
            if not record or record["project_id"] != project_id:
                raise ValueError("关联数据记录不存在或不属于当前项目")
            dataset_id = record["dataset_id"]
            if not source_id:
                source_id = record.get("source_id") or ""
        if dataset_id:
            dataset = one("SELECT * FROM datasets WHERE id=?", (dataset_id,))
            if not dataset or dataset["project_id"] != project_id:
                raise ValueError("关联数据集不存在或不属于当前项目")
            if not source_id:
                source_id = dataset.get("source_id") or ""
        if source_id and not one("SELECT id FROM sources WHERE id=?", (source_id,)):
            raise ValueError("关联数据来源不存在")
        return {"dataset_id": dataset_id, "record_id": record_id, "source_id": source_id,
                "dataset_name": dataset["name"] if dataset else "", "record_key": record["record_key"] if record else ""}

    def publish_result_evidence(run_id, user):
        run = one("SELECT * FROM epitope_runs WHERE id=?", (run_id,))
        if not run:
            return ""
        top = one("SELECT * FROM epitope_candidates WHERE run_id=? ORDER BY rank,start_pos LIMIT 1", (run_id,))
        selected = one("SELECT COUNT(*) n FROM epitope_candidates WHERE run_id=? AND selected=1", (run_id,))["n"]
        evidence_id = s.ident("证据")
        summary = (f"EpiWork 抗原候选计算结果。蛋白：{run['protein_name']}；运行：{run_id}；"
                   f"候选 {run['candidate_count']} 条；已选择 {selected} 条；状态 {run['status']}。")
        if top:
            summary += f" 当前首位候选 {top['start_pos']}-{top['end_pos']}，共识分 {float(top['score']):.2f}。"
        notes = "由抗原决策台自动生成并关联原始数据记录；属于计算决策辅助证据，须经实验复核。"
        with s.conn() as c:
            c.execute("""INSERT INTO evidence(id,source_id,title,identifier,url,evidence_type,status,content,notes,created_at,publication_date,source_identifier,tags,conflict_group,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                evidence_id, run.get("source_id") or None, f"EpiWork 抗原候选分析：{run['protein_name']}",
                run_id, "", "计算结果", "待复核", summary, notes, s.now(), "", run_id,
                "EpiWork;抗原候选;计算决策", "", s.now()
            ))
            payload = c.execute("SELECT * FROM evidence WHERE id=?", (evidence_id,)).fetchone()
            c.execute("INSERT INTO evidence_versions VALUES(?,?,?,?,?,?)", (
                s.ident("证据版本"), evidence_id, 1, dumps(dict(payload)), "抗原决策台首次生成", s.now()
            ))
            c.execute("INSERT INTO epitope_output_evidence VALUES(?,?,?,?,?)", (
                s.ident("结果证据"), run_id, evidence_id, run.get("record_id") or "", s.now()
            ))
            if run.get("record_id"):
                c.execute("INSERT INTO evidence_links VALUES(?,?,?,?,?)", (
                    s.ident("关联"), evidence_id, run["record_id"], "计算结果", s.now()
                ))
        s.audit(user, "生成抗原决策结果证据", run_id, evidence_id)
        return evidence_id

    def create_protein(d):
        name = str(d.get("name") or "").strip()
        if not name:
            raise ValueError("蛋白名称不能为空")
        seq, header = normalize_sequence(d.get("sequence"))
        project_id = str(d.get("project_id") or "").strip()
        if not project_id or not one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("请选择有效项目")
        provenance = resolve_provenance(d, project_id)
        existing = one("SELECT * FROM epitope_proteins WHERE project_id=? AND name=? AND sequence=?", (project_id, name, seq))
        if existing:
            if provenance["dataset_id"] or provenance["record_id"] or provenance["source_id"]:
                with s.conn() as c:
                    c.execute("UPDATE epitope_proteins SET dataset_id=?,record_id=?,source_id=?,updated_at=? WHERE id=?", (
                        provenance["dataset_id"] or existing.get("dataset_id") or "",
                        provenance["record_id"] or existing.get("record_id") or "",
                        provenance["source_id"] or existing.get("source_id") or "",
                        s.now(), existing["id"]
                    ))
                existing = one("SELECT * FROM epitope_proteins WHERE id=?", (existing["id"],))
            return existing
        pid = s.ident("蛋白")
        with s.conn() as c:
            c.execute("""INSERT INTO epitope_proteins(id,project_id,name,accession,organism,sequence,length,notes,created_at,updated_at,dataset_id,record_id,source_id)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                pid, project_id, name, str(d.get("accession") or "").strip(), str(d.get("organism") or "").strip(),
                seq, len(seq), str(d.get("notes") or "").strip(), s.now(), s.now(),
                provenance["dataset_id"], provenance["record_id"], provenance["source_id"]
            ))
        return one("SELECT * FROM epitope_proteins WHERE id=?", (pid,))

    def analyze(d, user):
        project_id = str(d.get("project_id") or "").strip()
        if not project_id or not one("SELECT id FROM projects WHERE id=?", (project_id,)):
            raise ValueError("请选择有效项目")
        name = str(d.get("protein_name") or d.get("name") or "").strip()
        seq, header = normalize_sequence(d.get("sequence"))
        if not name:
            name = header.split()[0] if header else "未命名蛋白"
        accession = str(d.get("accession") or "").strip()
        organism = str(d.get("organism") or "Brucella spp.").strip()
        tool_ids = d.get("tools") or [k for k, v in TOOL_CATALOG.items() if v["mode"] == "internal"]
        if not isinstance(tool_ids, list) or not tool_ids:
            raise ValueError("至少选择一个可用工具")
        unknown = [x for x in tool_ids if x not in TOOL_CATALOG]
        if unknown:
            raise ValueError("包含未知或未配置工具：" + "、".join(unknown))
        weights = normalize_weights(d.get("weights"))
        try:
            external_timeout = float(d.get("external_timeout_seconds", 240))
        except Exception:
            external_timeout = 240
        external_timeout = max(30, min(600, external_timeout))
        simulate_failure = str(d.get("simulate_failure") or "").strip()
        if simulate_failure and simulate_failure not in tool_ids:
            simulate_failure = ""
        provenance = resolve_provenance(d, project_id)
        if not provenance["record_id"]:
            raise ValueError("请从数据中心选择一条序列记录后再运行分析")
        if not provenance["source_id"]:
            raise ValueError("该数据集尚未关联数据来源，请先在数据中心或证据中心完成来源关联")
        protein = create_protein({"project_id": project_id, "name": name, "accession": accession,
                                  "organism": organism, "sequence": seq, "notes": "EpiWork 抗原决策台",
                                  "dataset_id": provenance["dataset_id"], "record_id": provenance["record_id"],
                                  "source_id": provenance["source_id"]})
        run_id = s.ident("运行")
        started = time.perf_counter()
        with s.conn() as c:
            c.execute("""INSERT INTO epitope_runs(id,project_id,protein_id,protein_name,accession,organism,sequence,tools,weights,status,tool_logs,candidate_count,elapsed_ms,parameters,created_at,completed_at,dataset_id,record_id,source_id)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                run_id, project_id, protein["id"], name, accession, organism, seq,
                dumps(tool_ids), dumps(weights), "RUNNING", "[]", 0, 0,
                dumps({"simulate_failure": simulate_failure, "engine": "internal+external-adapters-v1", "external_timeout_seconds": external_timeout}), s.now(), None,
                provenance["dataset_id"], provenance["record_id"], provenance["source_id"]
            ))
        tool_logs = []
        try:
            def work(tid):
                try:
                    return execute_tool(tid, seq, simulate_failure, external_timeout)
                except Exception as exc:
                    return {"id": tid, "name": TOOL_CATALOG[tid]["name"], "version": TOOL_CATALOG[tid]["version"],
                            "mode": TOOL_CATALOG[tid]["mode"], "status": "FAILED", "duration_ms": 0,
                            "regions": [], "warnings": ["该适配器异常，主工作流继续执行。"], "error": str(exc)}
            with ThreadPoolExecutor(max_workers=min(4, len(tool_ids))) as pool:
                futures = {pool.submit(work, tid): tid for tid in tool_ids}
                for fut in as_completed(futures):
                    tool_logs.append(fut.result())
            order = {tid: i for i, tid in enumerate(tool_ids)}
            tool_logs.sort(key=lambda x: order[x["id"]])
            if all(x["status"] == "FAILED" for x in tool_logs):
                raise RuntimeError("全部预测适配器失败，无法生成候选")
            evidence_rows = rows("""SELECT ee.*,e.title evidence_center_title,e.status evidence_center_status,src.name source_name FROM epitope_evidence ee JOIN evidence e ON e.id=ee.linked_evidence_id LEFT JOIN sources src ON src.id=ee.source_id ORDER BY ee.confidence DESC""")
            candidates = build_candidates(run_id, seq, tool_logs, evidence_rows)
            for c in candidates:
                ev, items = evidence_for(name, accession, c["sequence"], evidence_rows)
                c["evidence_items"] = items
                c["factors"]["evidence"] = round(ev, 4)
                c["evidence"] = round(ev, 4)
            ranked = rank_candidates(candidates, weights)
            elapsed = round((time.perf_counter() - started) * 1000, 1)
            with s.conn() as c:
                for cand in ranked:
                    c.execute("INSERT INTO epitope_candidates VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                        cand["id"], run_id, cand["rank"], cand["start"], cand["end"], cand["sequence"],
                        cand["score"], cand["coverage"], cand["strength"], cand["evidence"], cand["consistency"],
                        cand["support_count"], cand["total_tools"], dumps(cand["support_tools"]),
                        dumps(cand["tool_scores"]), dumps(cand["factors"]), 0, s.now()
                    ))
                c.execute("UPDATE epitope_runs SET status=?,tool_logs=?,candidate_count=?,elapsed_ms=?,completed_at=? WHERE id=?",
                          ("SUCCESS" if all(x["status"] != "FAILED" for x in tool_logs) else "PARTIAL",
                           dumps(tool_logs), len(ranked), elapsed, s.now(), run_id))
                c.execute("INSERT INTO epitope_rankings VALUES(?,?,?,?,?)", (
                    s.ident("排序"), run_id, dumps(weights),
                    dumps([{"id": x["id"], "rank": x["rank"], "score": x["score"]} for x in ranked]), s.now()
                ))
            publish_result_evidence(run_id, user)
            s.audit(user, "运行表位候选分析", run_id, f"{name}；工具 {len(tool_ids)}；候选 {len(ranked)}")
            return run_detail(run_id)
        except Exception:
            with s.conn() as c:
                c.execute("UPDATE epitope_runs SET status='FAILED',tool_logs=?,completed_at=? WHERE id=?",
                          (dumps(tool_logs), s.now(), run_id))
            raise

    class Handler(base):
        def path_parts(self):
            u = urllib.parse.urlparse(self.path)
            return urllib.parse.unquote(u.path), urllib.parse.parse_qs(u.query)

        def do_GET(self):
            path, q = self.path_parts()
            if not path.startswith("/api/epitope/"):
                return super().do_GET()
            if not self.auth():
                return
            try:
                if path == "/api/epitope/meta":
                    return self.send_json({
                        "version": APP_VERSION,
                        "tools": [dict(id=k, **v) for k, v in TOOL_CATALOG.items()],
                        "external_adapters": EXTERNAL_ADAPTERS,
                        "dimensions": DIMENSIONS,
                        "presets": PRESETS,
                        "evidence_count": one("SELECT COUNT(*) n FROM evidence")["n"],
                        "method_note": "本地适配器为透明启发式基线；外部结果来自公开 IEDB、BepiPred 和 ABCpred 服务。评分仅用于候选优先级辅助。"
                    })
                if path == "/api/epitope/proteins":
                    project_id = q.get("project_id", [""])[0]
                    sql = """SELECT p.*,d.name dataset_name,r.record_key,s.name source_name
                             FROM epitope_proteins p
                             LEFT JOIN datasets d ON d.id=p.dataset_id
                             LEFT JOIN records r ON r.id=p.record_id
                             LEFT JOIN sources s ON s.id=p.source_id"""
                    if project_id:
                        return self.send_json(rows(sql + " WHERE p.project_id=? ORDER BY p.updated_at DESC", (project_id,)))
                    return self.send_json(rows(sql + " ORDER BY p.updated_at DESC"))
                if path == "/api/epitope/runs":
                    project_id = q.get("project_id", [""])[0]
                    sql = """SELECT er.id,er.project_id,er.protein_name,er.accession,er.status,er.candidate_count,er.elapsed_ms,er.created_at,
                                    er.weights,er.dataset_id,er.record_id,er.source_id,d.name dataset_name,r.record_key,s.name source_name
                             FROM epitope_runs er
                             LEFT JOIN datasets d ON d.id=er.dataset_id
                             LEFT JOIN records r ON r.id=er.record_id
                             LEFT JOIN sources s ON s.id=er.source_id"""
                    if project_id:
                        return self.send_json(rows(sql + " WHERE er.project_id=? ORDER BY er.created_at DESC", (project_id,)))
                    return self.send_json(rows(sql + " ORDER BY er.created_at DESC"))
                if path == "/api/epitope/evidence":
                    term = q.get("q", [""])[0].strip().lower()
                    data = rows("""SELECT ee.*,s.name source_name,s.source_url source_url_center
                                   FROM epitope_evidence ee LEFT JOIN sources s ON s.id=ee.source_id
                                   ORDER BY ee.confidence DESC,ee.created_at DESC""")
                    if term:
                        data = [x for x in data if term in json.dumps(x, ensure_ascii=False).lower()]
                    return self.send_json(data)
                if path == "/api/epitope/visualization/summary":
                    project_id = q.get("project_id", [""])[0]
                    where = " WHERE er.project_id=?" if project_id else ""
                    args = (project_id,) if project_id else ()
                    runs = rows("""SELECT er.id,er.project_id,er.protein_name,er.accession,er.status,er.candidate_count,er.elapsed_ms,er.created_at,er.weights,
                                          d.name dataset_name,r.record_key,s.name source_name
                                   FROM epitope_runs er LEFT JOIN datasets d ON d.id=er.dataset_id
                                   LEFT JOIN records r ON r.id=er.record_id LEFT JOIN sources s ON s.id=er.source_id""" + where + " ORDER BY er.created_at DESC", args)
                    candidates = rows("""SELECT c.id,c.run_id,c.rank,c.start_pos,c.end_pos,c.sequence,c.score,c.coverage,c.strength,c.evidence,c.consistency,
                                                c.support_count,c.total_tools,c.support_tools,c.selected,er.protein_name,er.created_at
                                         FROM epitope_candidates c JOIN epitope_runs er ON er.id=c.run_id""" + where + " ORDER BY c.score DESC,c.rank LIMIT 100", args)
                    for c in candidates:
                        c["support_tools"] = json.loads(c.get("support_tools") or "[]")
                        c["selected"] = bool(c.get("selected"))
                    status_counts = rows("""SELECT er.status name,COUNT(*) count FROM epitope_runs er""" + where + " GROUP BY er.status", args)
                    coverage_counts = rows("""SELECT c.support_count name,COUNT(*) count FROM epitope_candidates c JOIN epitope_runs er ON er.id=c.run_id""" + where + " GROUP BY c.support_count ORDER BY c.support_count", args)
                    source_counts = rows("""SELECT COALESCE(s.name,'未关联来源') name,COUNT(*) count FROM epitope_runs er
                                            LEFT JOIN sources s ON s.id=er.source_id""" + where + " GROUP BY s.name ORDER BY count DESC", args)
                    score_counts = [{"name": "0-20", "count": 0}, {"name": "20-40", "count": 0}, {"name": "40-60", "count": 0}, {"name": "60-80", "count": 0}, {"name": "80-100", "count": 0}]
                    for c in candidates:
                        idx = min(4, max(0, int(float(c.get("score") or 0) // 20)))
                        score_counts[idx]["count"] += 1
                    proteins = one("SELECT COUNT(*) n FROM epitope_proteins" + (" WHERE project_id=?" if project_id else ""), args)["n"]
                    evidence = one("SELECT COUNT(*) n FROM epitope_evidence")["n"]
                    selected = one("""SELECT COUNT(*) n FROM epitope_candidates c JOIN epitope_runs er ON er.id=c.run_id
                                      WHERE c.selected=1""" + (" AND er.project_id=?" if project_id else ""), args)["n"]
                    total_candidates = one("""SELECT COUNT(*) n FROM epitope_candidates c JOIN epitope_runs er ON er.id=c.run_id""" + where, args)["n"]
                    top_score = max([float(c["score"]) for c in candidates], default=0)
                    return self.send_json({"kpis": {"runs": len(runs), "proteins": proteins, "candidates": total_candidates,
                                                     "selected": selected, "evidence": evidence, "top_score": round(top_score, 2)},
                                           "runs": runs, "top_candidates": candidates[:20], "status_counts": status_counts,
                                           "coverage_counts": coverage_counts, "source_counts": source_counts,
                                           "score_counts": score_counts})
                m = re.match(r"^/api/epitope/runs/([^/]+)$", path)
                if m:
                    return self.send_json(run_detail(m.group(1)))
                return self.send_json({"错误": "表位接口不存在"}, 404)
            except Exception as exc:
                return self.send_json({"错误": str(exc)}, 400)

        def do_POST(self):
            path, _ = self.path_parts()
            if not path.startswith("/api/epitope/"):
                return super().do_POST()
            if not self.auth():
                return
            try:
                raw = self.body()
                d = json.loads(raw or b"{}")
                if not isinstance(d, dict):
                    raise ValueError("请求必须是 JSON 对象")
                if path == "/api/epitope/analyze":
                    return self.send_json(analyze(d, self.user))
                if path == "/api/epitope/proteins":
                    return self.send_json(create_protein(d))
                m = re.match(r"^/api/epitope/runs/([^/]+)/rerank$", path)
                if m:
                    run_id = m.group(1)
                    run = run_detail(run_id)
                    weights = normalize_weights(d.get("weights"))
                    ranked = rank_candidates(run["candidates"], weights)
                    with s.conn() as c:
                        for item in ranked:
                            c.execute("UPDATE epitope_candidates SET rank=?,score=? WHERE id=? AND run_id=?", (item["rank"], item["score"], item["id"], run_id))
                        c.execute("UPDATE epitope_runs SET weights=? WHERE id=?", (dumps(weights), run_id))
                        c.execute("INSERT INTO epitope_rankings VALUES(?,?,?,?,?)", (
                            s.ident("排序"), run_id, dumps(weights),
                            dumps([{"id": x["id"], "rank": x["rank"], "score": x["score"]} for x in ranked]), s.now()
                        ))
                    s.audit(self.user, "保存候选权重重排", run_id, dumps(weights))
                    return self.send_json({"run_id": run_id, "weights": weights, "candidates": ranked})
                if path == "/api/epitope/select":
                    run_id = str(d.get("run_id") or "")
                    ids = d.get("candidate_ids") or []
                    if not isinstance(ids, list):
                        raise ValueError("候选编号必须为数组")
                    valid = {x["id"] for x in rows("SELECT id FROM epitope_candidates WHERE run_id=?", (run_id,))}
                    ids = [x for x in ids if x in valid]
                    with s.conn() as c:
                        c.execute("UPDATE epitope_candidates SET selected=0 WHERE run_id=?", (run_id,))
                        for cid in ids:
                            c.execute("UPDATE epitope_candidates SET selected=1 WHERE id=? AND run_id=?", (cid, run_id))
                    s.audit(self.user, "保存候选选择", run_id, f"选中 {len(ids)} 条")
                    return self.send_json({"ok": True, "selected_count": len(ids)})
                if path == "/api/epitope/export":
                    run = run_detail(str(d.get("run_id") or ""))
                    ids = d.get("candidate_ids") or []
                    if ids:
                        wanted = set(ids)
                        candidates = [x for x in run["candidates"] if x["id"] in wanted]
                    else:
                        candidates = [x for x in run["candidates"] if x.get("selected")]
                    if not candidates:
                        candidates = run["candidates"][:5]
                    fmt = str(d.get("format") or "csv").lower()
                    result = save_export(run, candidates, fmt)
                    s.audit(self.user, "导出候选决策文件", run["id"], f"{fmt}；{len(candidates)} 条")
                    return self.send_json(result)
                if path == "/api/epitope/evidence":
                    title = str(d.get("title") or "").strip()
                    if not title:
                        raise ValueError("证据标题不能为空")
                    eid = s.ident("证据")
                    linked_id = s.ident("证据")
                    source_id = str(d.get("source_id") or "").strip()
                    source_row = one("SELECT * FROM sources WHERE id=?", (source_id,)) if source_id else None
                    if source_id and not source_row:
                        raise ValueError("关联来源不存在")
                    source_name = (source_row["name"] if source_row else str(d.get("source") or "人工登记").strip())
                    try:
                        conf = max(0.0, min(1.0, float(d.get("confidence", 0.6))))
                    except Exception:
                        conf = 0.6
                    summary = str(d.get("summary") or "").strip()
                    url = str(d.get("url") or "").strip()
                    pmid = str(d.get("pmid") or "").strip()
                    evidence_type = str(d.get("evidence_type") or "公开文献").strip()
                    relation = str(d.get("relation") or "待评估").strip()
                    status = str(d.get("status") or "待核验").strip()
                    with s.conn() as c:
                        c.execute("""INSERT INTO evidence(id,source_id,title,identifier,url,evidence_type,status,content,notes,created_at,publication_date,source_identifier,tags,conflict_group,updated_at)
                                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                            linked_id, source_id or None, title, pmid, url, evidence_type, status, summary,
                            "由抗原决策台登记并与公开证据库同步。", s.now(), "", pmid,
                            "EpiWork;抗原证据", "", s.now()
                        ))
                        payload = c.execute("SELECT * FROM evidence WHERE id=?", (linked_id,)).fetchone()
                        c.execute("INSERT INTO evidence_versions VALUES(?,?,?,?,?,?)", (
                            s.ident("证据版本"), linked_id, 1, dumps(dict(payload)), "抗原决策台登记", s.now()
                        ))
                        c.execute("""INSERT INTO epitope_evidence(id,protein_pattern,title,evidence_type,relation,source,url,pmid,summary,confidence,status,sequence,created_at,source_id,linked_evidence_id)
                                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                            eid, str(d.get("protein_pattern") or "").strip(), title, evidence_type, relation,
                            source_name, url, pmid, summary, conf, status,
                            str(d.get("sequence") or "").strip().upper(), s.now(), source_id, linked_id
                        ))
                    s.audit(self.user, "登记表位公开证据", eid, title)
                    return self.send_json({"id": eid, "linked_evidence_id": linked_id})
                return self.send_json({"错误": "表位接口不存在"}, 404)
            except Exception as exc:
                return self.send_json({"错误": str(exc)}, 400)

    return Handler




















